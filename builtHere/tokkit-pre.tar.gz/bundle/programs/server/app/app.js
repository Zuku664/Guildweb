var require = meteorInstall({"lib":{"db.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/db.js                                                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
posts = new Mongo.Collection('posts');                                                                               // 1
userCount = new Mongo.Collection('userCount');                                                                       // 2
siteDetails = new Mongo.Collection('siteDetails'); //denys anyone access to these (unless the above allow is met)    // 3
                                                                                                                     //
posts.deny({                                                                                                         // 6
  update: function () {                                                                                              // 7
    return true;                                                                                                     // 8
  },                                                                                                                 // 9
  insert: function () {                                                                                              // 11
    return true;                                                                                                     // 12
  }                                                                                                                  // 13
});                                                                                                                  // 6
Meteor.users.deny({                                                                                                  // 16
  update: function () {                                                                                              // 17
    return true;                                                                                                     // 18
  }                                                                                                                  // 19
});                                                                                                                  // 16
userCount.deny({                                                                                                     // 22
  update: function () {                                                                                              // 23
    return true;                                                                                                     // 24
  },                                                                                                                 // 25
  insert: function () {                                                                                              // 27
    return true;                                                                                                     // 28
  }                                                                                                                  // 29
});                                                                                                                  // 22
siteDetails.deny({                                                                                                   // 32
  update: function () {                                                                                              // 33
    return true;                                                                                                     // 34
  },                                                                                                                 // 35
  insert: function () {                                                                                              // 37
    return true;                                                                                                     // 38
  }                                                                                                                  // 39
});                                                                                                                  // 32
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"globals.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/globals.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
//defaults to feed (home)                                                                                            // 1
currentPage = new ReactiveVar("feed"); //gets currentPost                                                            // 2
                                                                                                                     //
currentPost = new ReactiveVar(); //admin page location                                                               // 5
                                                                                                                     //
adminLoc = new ReactiveVar("dash"); //the news filter                                                                // 8
                                                                                                                     //
newsFilter = new ReactiveVar('news');                                                                                // 11
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/routes.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
FlowRouter.route('/', {                                                                                              // 1
  name: 'home',                                                                                                      // 2
  subscriptions: function (params, queryParams) {                                                                    // 3
    // using Fast Render                                                                                             // 4
    this.register('posts', Meteor.subscribe('posts'));                                                               // 5
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                   // 6
  },                                                                                                                 // 7
  action: function () {                                                                                              // 8
    BlazeLayout.render('index');                                                                                     // 9
  },                                                                                                                 // 10
  fastRender: true                                                                                                   // 11
});                                                                                                                  // 1
FlowRouter.route('/admin', {                                                                                         // 14
  name: "admin",                                                                                                     // 15
  action: function () {                                                                                              // 16
    BlazeLayout.render('admin');                                                                                     // 17
  }                                                                                                                  // 18
});                                                                                                                  // 14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fileserver.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/fileserver.js                                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var fs = Npm.require('fs');                                                                                          // 1
                                                                                                                     //
WebApp.connectHandlers.use(function (req, res, next) {                                                               // 2
    var re = /^\/files\/(.*)$/.exec(req.url);                                                                        // 3
                                                                                                                     //
    if (re !== null) {                                                                                               // 4
        // Only handle URLs that start with /uploads_url_prefix/*                                                    // 4
        var filePath = process.env.PWD + '/.static~/' + re[1];                                                       // 5
        var data = fs.readFileSync(filePath);                                                                        // 6
        res.writeHead(200, {                                                                                         // 7
            'Content-Type': 'image'                                                                                  // 8
        });                                                                                                          // 7
        res.write(data);                                                                                             // 10
        res.end();                                                                                                   // 11
    } else {                                                                                                         // 12
        // Other urls will have default behaviors                                                                    // 12
        next();                                                                                                      // 13
    }                                                                                                                // 14
});                                                                                                                  // 15
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publish.js                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.publish("posts", function () {                                                                                // 1
  return posts.find({});                                                                                             // 2
});                                                                                                                  // 3
Meteor.publish("siteDetails", function () {                                                                          // 5
  return siteDetails.find({});                                                                                       // 6
});                                                                                                                  // 7
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/server.js                                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.startup(function () {                                                                                         // 1
  fs = Npm.require('fs');                                                                                            // 2
}); //checks to see if default site values are set, creates template for later                                       // 3
                                                                                                                     //
var needed = ['title', 'about', 'tabard', 'background', 'favicon', 'recruiting'];                                    // 7
var firstTime = 0;                                                                                                   // 8
                                                                                                                     //
for (var i = 0; i < needed.length; i++) {                                                                            // 9
  if (siteDetails.findOne({                                                                                          // 10
    _id: needed[i]                                                                                                   // 10
  })) {//horray!!                                                                                                    // 10
  } else {                                                                                                           // 12
    //lets create em                                                                                                 // 13
    siteDetails.insert({                                                                                             // 14
      _id: needed[i]                                                                                                 // 14
    });                                                                                                              // 14
    firstTime = 1;                                                                                                   // 15
  }                                                                                                                  // 16
}                                                                                                                    // 17
                                                                                                                     //
if (firstTime == 1) {                                                                                                // 18
  //wow                                                                                                              // 19
  siteDetails.update({                                                                                               // 20
    _id: 'recruiting'                                                                                                // 20
  }, {                                                                                                               // 20
    $set: {                                                                                                          // 20
      dnB: 'checked',                                                                                                // 20
      dnU: 'checked',                                                                                                // 20
      dnF: 'checked',                                                                                                // 20
      dhH: 'checked',                                                                                                // 20
      dhV: 'checked',                                                                                                // 20
      drB: 'checked',                                                                                                // 20
      drF: 'checked',                                                                                                // 20
      drR: 'checked',                                                                                                // 20
      drG: 'checked',                                                                                                // 20
      huM: 'checked',                                                                                                // 20
      huS: 'checked',                                                                                                // 20
      huB: 'checked',                                                                                                // 20
      maF: 'checked',                                                                                                // 20
      maFr: 'checked',                                                                                               // 20
      maA: 'checked',                                                                                                // 20
      moM: 'checked',                                                                                                // 20
      moW: 'checked',                                                                                                // 20
      moB: 'checked',                                                                                                // 20
      paH: 'checked',                                                                                                // 20
      paR: 'checked',                                                                                                // 20
      paP: 'checked',                                                                                                // 20
      prS: 'checked',                                                                                                // 20
      prD: 'checked',                                                                                                // 20
      prH: 'checked',                                                                                                // 20
      roA: 'checked',                                                                                                // 20
      roS: 'checked',                                                                                                // 20
      roC: 'checked',                                                                                                // 20
      shE: 'checked',                                                                                                // 20
      shR: 'checked',                                                                                                // 20
      shEn: 'checked',                                                                                               // 20
      waA: 'checked',                                                                                                // 20
      waD: 'checked',                                                                                                // 20
      waDe: 'checked',                                                                                               // 20
      warA: 'checked',                                                                                               // 20
      warF: 'checked',                                                                                               // 20
      warP: 'checked'                                                                                                // 20
    }                                                                                                                // 20
  });                                                                                                                // 20
  console.log('hi');                                                                                                 // 21
  firstTime = 0;                                                                                                     // 22
} //creates initial account                                                                                          // 23
                                                                                                                     //
                                                                                                                     //
Meteor.methods({                                                                                                     // 27
  'accountCheck': function () {                                                                                      // 28
    if (userCount.findOne({                                                                                          // 29
      count: 0                                                                                                       // 29
    })) {                                                                                                            // 29
      return true;                                                                                                   // 30
    } else {                                                                                                         // 31
      return false;                                                                                                  // 32
    }                                                                                                                // 33
  },                                                                                                                 // 34
  'phraseCheck': function (secret) {                                                                                 // 35
    if (secret == "SnowyTableSanDiegoFifteenTwelve") {                                                               // 36
      return true;                                                                                                   // 37
    }                                                                                                                // 38
  },                                                                                                                 // 39
  'createAcc': function (usm, psw) {                                                                                 // 40
    Accounts.createUser({                                                                                            // 41
      username: usm,                                                                                                 // 42
      password: psw                                                                                                  // 43
    });                                                                                                              // 41
    userCount.insert({                                                                                               // 45
      count: 1                                                                                                       // 45
    });                                                                                                              // 45
    userCount.remove({                                                                                               // 46
      count: 0                                                                                                       // 46
    });                                                                                                              // 46
  }                                                                                                                  // 47
});                                                                                                                  // 27
Meteor.methods({                                                                                                     // 50
  'post': function (imageData, title, content) {                                                                     // 51
    // our data URL string from canvas.toDataUrl();                                                                  // 52
    var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                       // 53
                                                                                                                     //
    var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp            // 55
                                                                                                                     //
    var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                     //
    var imageBuffer = new Buffer(base64Data, "base64");                                                              // 59
    var id = ShortId.generate();                                                                                     // 60
    var isoDate = new Date();                                                                                        // 61
    var res = isoDate.toString().split(" ");                                                                         // 62
    var date = res[1] + " " + res[2] + " " + res[3];                                                                 // 63
    var path = process.env["PWD"] + '/.static~/';                                                                    // 64
    posts.insert({                                                                                                   // 66
      _id: id,                                                                                                       // 66
      title: title,                                                                                                  // 66
      content: content,                                                                                              // 66
      imgPath: '/files/' + id + ".jpeg",                                                                             // 66
      date: date                                                                                                     // 66
    });                                                                                                              // 66
    fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 67
      if (err) throw err;                                                                                            // 69
      console.log('Done!');                                                                                          // 70
    });                                                                                                              // 71
  }                                                                                                                  // 72
});                                                                                                                  // 50
Meteor.methods({                                                                                                     // 75
  'updateSite': function (specStatus, title, about) {                                                                // 76
    var spec = ['dnB', 'dnU', 'dnF', 'dhH', 'dhV', 'drB', 'drF', 'drR', 'drG', 'huM', 'huS', 'huB', 'maF', 'maFr', 'maA', 'moM', 'moW', 'moB', 'paH', 'paR', 'paP', 'prS', 'prD', 'prH', 'roA', 'roS', 'roC', 'shE', 'shR', 'shEn', 'waA', 'waD', 'waDe', 'warA', 'warF', 'warP']; //for loop wont work, as I can only assign the value and not the property
                                                                                                                     //
    siteDetails.update({                                                                                             // 80
      _id: 'recruiting'                                                                                              // 80
    }, {                                                                                                             // 80
      $set: {                                                                                                        // 80
        dnB: specStatus[0],                                                                                          // 80
        dnU: specStatus[1],                                                                                          // 80
        dnF: specStatus[2],                                                                                          // 80
        dhH: specStatus[3],                                                                                          // 80
        dhV: specStatus[4],                                                                                          // 80
        drB: specStatus[5],                                                                                          // 80
        drF: specStatus[6],                                                                                          // 80
        drR: specStatus[7],                                                                                          // 80
        drG: specStatus[8],                                                                                          // 80
        huM: specStatus[9],                                                                                          // 80
        huS: specStatus[10],                                                                                         // 80
        huB: specStatus[11],                                                                                         // 80
        maF: specStatus[12],                                                                                         // 80
        maFr: specStatus[13],                                                                                        // 80
        maA: specStatus[14],                                                                                         // 80
        moM: specStatus[15],                                                                                         // 80
        moW: specStatus[16],                                                                                         // 80
        moB: specStatus[17],                                                                                         // 80
        paH: specStatus[18],                                                                                         // 80
        paR: specStatus[19],                                                                                         // 80
        paP: specStatus[20],                                                                                         // 80
        prS: specStatus[21],                                                                                         // 80
        prD: specStatus[22],                                                                                         // 80
        prH: specStatus[23],                                                                                         // 80
        roA: specStatus[24],                                                                                         // 80
        roS: specStatus[25],                                                                                         // 80
        roC: specStatus[26],                                                                                         // 80
        shE: specStatus[27],                                                                                         // 80
        shR: specStatus[28],                                                                                         // 80
        shEn: specStatus[29],                                                                                        // 80
        waA: specStatus[30],                                                                                         // 80
        waD: specStatus[31],                                                                                         // 80
        waDe: specStatus[32],                                                                                        // 80
        warA: specStatus[33],                                                                                        // 80
        warF: specStatus[34],                                                                                        // 80
        warP: specStatus[35]                                                                                         // 80
      }                                                                                                              // 80
    });                                                                                                              // 80
                                                                                                                     //
    if (title != "" && title != undefined && title != null) {                                                        // 83
      siteDetails.update({                                                                                           // 84
        _id: 'title'                                                                                                 // 84
      }, {                                                                                                           // 84
        $set: {                                                                                                      // 84
          title: title                                                                                               // 84
        }                                                                                                            // 84
      });                                                                                                            // 84
    }                                                                                                                // 85
                                                                                                                     //
    if (about != "" && about != undefined && about != null) {                                                        // 86
      siteDetails.update({                                                                                           // 87
        _id: 'about'                                                                                                 // 87
      }, {                                                                                                           // 87
        $set: {                                                                                                      // 87
          about: about                                                                                               // 87
        }                                                                                                            // 87
      });                                                                                                            // 87
    }                                                                                                                // 88
  }                                                                                                                  // 89
});                                                                                                                  // 75
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/db.js");
require("./lib/globals.js");
require("./lib/routes.js");
require("./server/fileserver.js");
require("./server/publish.js");
require("./server/server.js");
//# sourceMappingURL=app.js.map
