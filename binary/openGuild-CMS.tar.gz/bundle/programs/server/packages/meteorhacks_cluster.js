(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var _ = Package.underscore._;

/* Package-scope variables */
var Cluster, ConnectionWatcher, MongoDiscoveryStore, MongoClient, MongoDiscovery, OverShadowServerEvent, WorkerPool, Balancer;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////
//                                                                                       //
// packages/meteorhacks_cluster/packages/meteorhacks_cluster.js                          //
//                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////
                                                                                         //
(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/namespace.js                                  //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
Cluster = {};                                                                     // 1
////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/connection_watcher.js                         //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
ConnectionWatcher = function ConnectionWatcher(discovery, serviceName, options) { // 1
  options = options || {};                                                        // 2
                                                                                  // 3
  this._discovery = discovery;                                                    // 4
  this._serviceName = serviceName;                                                // 5
  this._query = options.query || {};                                              // 6
  this._ddpOptions = options.ddpOptions;                                          // 7
  this._watchTimeout = options.watchTimeout || 5 * 1000;                          // 8
                                                                                  // 9
  this._currUrl = null;                                                           // 10
  this._ddpUrls = {};                                                             // 11
                                                                                  // 12
  this._connection = DDP.connect(this._getDefaultURL(), this._ddpOptions);        // 13
  this._connection.disconnect();                                                  // 14
  this._newConnectionWatcher = this._watchForNewConnections();                    // 15
};                                                                                // 16
                                                                                  // 17
ConnectionWatcher.prototype.getConnection = function() {                          // 18
  return this._connection;                                                        // 19
};                                                                                // 20
                                                                                  // 21
ConnectionWatcher.prototype._getDefaultURL = function() {                         // 22
  if(Meteor.isServer) {                                                           // 23
    return "";                                                                    // 24
  } else {                                                                        // 25
    return location.origin;                                                       // 26
  }                                                                               // 27
};                                                                                // 28
                                                                                  // 29
ConnectionWatcher.prototype._watchForNewConnections = function() {                // 30
  var self = this;                                                                // 31
  var connectInitially = false;                                                   // 32
                                                                                  // 33
  setConnectionIfNeeded();                                                        // 34
  // to make sure, we are connecting again                                        // 35
  var timeoutHandler =                                                            // 36
    Meteor.setInterval(setConnectionIfNeeded, self._watchTimeout);                // 37
                                                                                  // 38
  function setConnectionIfNeeded() {                                              // 39
    var status = self._connection.status();                                       // 40
    // do not reconnect again, if disconnected manually                           // 41
    // but not at the first time since we do it manually                          // 42
    // until we pick an endpoint                                                  // 43
    var isOffline = connectInitially && status.status == "offline";               // 44
    if(!status.connected && !isOffline) {                                         // 45
      var url = self._discovery.pickEndpoint(self._serviceName);                  // 46
      if(url) {                                                                   // 47
        self._connection.reconnect({url: url});                                   // 48
        connectInitially = true;                                                  // 49
      }                                                                           // 50
    }                                                                             // 51
  }                                                                               // 52
                                                                                  // 53
  var returnContext = {                                                           // 54
    stop: function() {                                                            // 55
      Meteor.clearTimeout(timeoutHandler);                                        // 56
    }                                                                             // 57
  };                                                                              // 58
                                                                                  // 59
  return returnContext;                                                           // 60
};                                                                                // 61
////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/server/api.js                                 //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
Cluster._publicServices = {};                                                     // 1
Cluster._registeredServices = {};                                                 // 2
Cluster._discoveryBackends = {};                                                  // 3
                                                                                  // 4
Cluster.connect = function(connUrl, options) {                                    // 5
  var matched = connUrl.match(/(\w+):\/\//);                                      // 6
  if(matched) {                                                                   // 7
    var backendName = matched[1];                                                 // 8
    var backend = this._discoveryBackends[backendName];                           // 9
    if(!backend) {                                                                // 10
      throw new Error("Cluster: no discovery backend named " + backendName);      // 11
    }                                                                             // 12
                                                                                  // 13
    this.discovery = backend;                                                     // 14
    console.info("Cluster: connecting to '%s' discovery backend", backendName);   // 15
    console.info("Cluster: with options: ", JSON.stringify(options));             // 16
    this.discovery.connect(connUrl, this, options);                               // 17
                                                                                  // 18
    var warnMessage = "trying to connect, but already connected";                 // 19
    Cluster.connect = Cluster._blockCallAgain(warnMessage);                       // 20
  } else {                                                                        // 21
    throw new Error("Cluster: connect url should an url");                        // 22
  }                                                                               // 23
};                                                                                // 24
                                                                                  // 25
Cluster.allowPublicAccess = function allowPublicAccess(serviceList) {             // 26
  if(process.env['CLUSTER_WORKER_ID']) {                                          // 27
    return false;                                                                 // 28
  }                                                                               // 29
                                                                                  // 30
  var self = this;                                                                // 31
  if(!(serviceList instanceof Array)) {                                           // 32
    serviceList = _.toArray(arguments);                                           // 33
  }                                                                               // 34
                                                                                  // 35
  var message = "Cluster: allow public access for '%s' service(s)";               // 36
  console.info(message, serviceList.join(", "));                                  // 37
                                                                                  // 38
  serviceList.forEach(function(service) {                                         // 39
    self._publicServices[service] = true;                                         // 40
  });                                                                             // 41
};                                                                                // 42
                                                                                  // 43
Cluster.discoverConnection = function discoverConnection(name, ddpOptions) {      // 44
  var options = {                                                                 // 45
    ddpOptions: ddpOptions                                                        // 46
  };                                                                              // 47
                                                                                  // 48
  var watcher = new ConnectionWatcher(this.discovery, name, options);             // 49
  return watcher.getConnection();                                                 // 50
};                                                                                // 51
                                                                                  // 52
Cluster.register = function register(name, options) {                             // 53
  if(process.env['CLUSTER_WORKER_ID']) {                                          // 54
    return false;                                                                 // 55
  }                                                                               // 56
                                                                                  // 57
  options = options || {};                                                        // 58
  options.balancer = options.balancer || process.env.CLUSTER_BALANCER_URL;        // 59
  options.endpoint = options.endpoint || process.env.CLUSTER_ENDPOINT_URL;        // 60
                                                                                  // 61
  if(!options.endpoint) {                                                         // 62
    console.info("Cluster: using ROOT_URL as the cluster endpoint");              // 63
    options.endpoint = process.env.ROOT_URL;                                      // 64
  }                                                                               // 65
                                                                                  // 66
  this._endpoint = options.endpoint;                                              // 67
  this._balancer = options.balancer;                                              // 68
                                                                                  // 69
  // This is the registered service where this service expose APIs                // 70
  this._registeredService = name;                                                 // 71
                                                                                  // 72
  // This is the UI service. If this app directly get's traffic                   // 73
  // This is the service where it should proxy the UI stuff and static files      // 74
  this._uiService =                                                               // 75
    options.uiService ||                                                          // 76
    process.env.CLUSTER_UI_SERVICE ||                                             // 77
    name;                                                                         // 78
                                                                                  // 79
  console.info("Cluster: registering this node as service '%s'", name);           // 80
  console.info("Cluster:    endpoint url =", options.endpoint);                   // 81
  console.info("Cluster:    balancer url =", options.balancer);                   // 82
  this.discovery.register(name, options);                                         // 83
                                                                                  // 84
  Cluster.register = Cluster._blockCallAgain("already registered as - " + name);  // 85
};                                                                                // 86
                                                                                  // 87
Cluster._isPublicService = function _isPublicService(serviceName) {               // 88
  return this._publicServices[serviceName];                                       // 89
};                                                                                // 90
                                                                                  // 91
Cluster.registerDiscoveryBackend =                                                // 92
function registerDiscoveryBackend(name, backend) {                                // 93
  this._discoveryBackends[name] = backend;                                        // 94
};                                                                                // 95
                                                                                  // 96
Cluster._blockCallAgain = function(message) {                                     // 97
  return function() {                                                             // 98
    throw new Error("Cluster: " + message);                                       // 99
  };                                                                              // 100
};                                                                                // 101
////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/server/discovery_backends/mongo/store.js      //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
MongoDiscoveryStore = function MongoDiscoveryStore() {                            // 1
  this._endpointListsByService = {};                                              // 2
  this._endpointMapsByService = {};                                               // 3
  this._allEndpoints = {};                                                        // 4
  this._allEndpointsByEndpointHash = {};                                          // 5
  this._allEndpointsByBalancer = {};                                              // 6
};                                                                                // 7
                                                                                  // 8
MongoDiscoveryStore.prototype.set = function set(id, service) {                   // 9
  service._id = id;                                                               // 10
  var serviceName = service.serviceName                                           // 11
  this._ensureStore(serviceName);                                                 // 12
                                                                                  // 13
  var currDocument = this._allEndpoints[id];                                      // 14
  if(currDocument) {                                                              // 15
    // remove the current document in the array                                   // 16
    this.remove(currDocument._id);                                                // 17
  }                                                                               // 18
                                                                                  // 19
  this._allEndpoints[id] = service;                                               // 20
  this._endpointMapsByService[serviceName][id] = service;                         // 21
  this._allEndpointsByEndpointHash[service.endpointHash] = service;               // 22
  if(service.balancer) {                                                          // 23
    this._allEndpointsByBalancer[service.balancer] = service;                     // 24
  }                                                                               // 25
  this._endpointListsByService[serviceName].push(service);                        // 26
};                                                                                // 27
                                                                                  // 28
MongoDiscoveryStore.prototype.get = function get(id) {                            // 29
  return this._allEndpoints[id];                                                  // 30
};                                                                                // 31
                                                                                  // 32
MongoDiscoveryStore.prototype.remove = function remove(id) {                      // 33
  var service = this._allEndpoints[id];                                           // 34
  if(!service) {                                                                  // 35
    // simply ignore                                                              // 36
    return;                                                                       // 37
  }                                                                               // 38
                                                                                  // 39
  delete this._allEndpoints[id];                                                  // 40
  delete this._endpointMapsByService[service.serviceName][id];                    // 41
  delete this._allEndpointsByEndpointHash[service.endpointHash];                  // 42
  if(service.balancer) {                                                          // 43
    delete this._allEndpointsByBalancer[service.balancer];                        // 44
  }                                                                               // 45
                                                                                  // 46
  var index = this._endpointListsByService[service.serviceName].indexOf(service); // 47
  this._endpointListsByService[service.serviceName].splice(index, 1);             // 48
};                                                                                // 49
                                                                                  // 50
MongoDiscoveryStore.prototype.getAll = function getAll(serviceName) {             // 51
  this._ensureStore(serviceName);                                                 // 52
  if(serviceName) {                                                               // 53
    return this._endpointListsByService[serviceName];                             // 54
  } else {                                                                        // 55
    return _.values(this._allEndpoints);                                          // 56
  }                                                                               // 57
};                                                                                // 58
                                                                                  // 59
MongoDiscoveryStore.prototype.getRandom = function getRandom(serviceName) {       // 60
  var all = this.getAll(serviceName);                                             // 61
  var index = Math.floor(all.length * Math.random());                             // 62
  return all[index];                                                              // 63
};                                                                                // 64
                                                                                  // 65
// If the given endpoint selected, then choose it with the given weight           // 66
// weight should be 0-1                                                           // 67
MongoDiscoveryStore.prototype.getRandomWeighted =                                 // 68
function getRandomWeighted(serviceName, endpointHash, weight) {                   // 69
  // no need to do this, if we've only one endpoint                               // 70
  if(this.getAll(serviceName).length === 1) {                                     // 71
    return this.getRandom(serviceName);                                           // 72
  }                                                                               // 73
                                                                                  // 74
  var randomValue = Math.random();                                                // 75
  if(randomValue < weight) {                                                      // 76
    // satisfied for the wieght, go with the normal random selection              // 77
    return this.getRandom(serviceName);                                           // 78
  } else {                                                                        // 79
    var removedService = this.byEndpointHash(endpointHash);                       // 80
    if(!removedService) {                                                         // 81
      return this.getRandom(serviceName);                                         // 82
    }                                                                             // 83
                                                                                  // 84
    this.remove(removedService._id);                                              // 85
    var randomService = this.getRandom(serviceName);                              // 86
    this.set(removedService._id, removedService);                                 // 87
                                                                                  // 88
    return randomService;                                                         // 89
  }                                                                               // 90
};                                                                                // 91
                                                                                  // 92
MongoDiscoveryStore.prototype.byEndpointHash = function byEndpointHash(hash) {    // 93
  return this._allEndpointsByEndpointHash[hash];                                  // 94
};                                                                                // 95
                                                                                  // 96
MongoDiscoveryStore.prototype.byBalancer = function(balancer) {                   // 97
  return this._allEndpointsByBalancer[balancer];                                  // 98
};                                                                                // 99
                                                                                  // 100
MongoDiscoveryStore.prototype._ensureStore =                                      // 101
function _ensureStore(serviceName) {                                              // 102
  if(!this._endpointListsByService[serviceName]) {                                // 103
    this._endpointListsByService[serviceName] = [];                               // 104
  }                                                                               // 105
                                                                                  // 106
  if(!this._endpointMapsByService[serviceName]) {                                 // 107
    this._endpointMapsByService[serviceName] = {};                                // 108
  }                                                                               // 109
};                                                                                // 110
////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/server/discovery_backends/mongo/discovery.js  //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
MongoClient = Npm.require("mongodb").MongoClient;                                 // 1
MongoDiscovery = {};                                                              // 2
Cluster.registerDiscoveryBackend("mongodb", MongoDiscovery);                      // 3
                                                                                  // 4
MongoDiscovery.connect = function connect(mongoUrl, clusterInstance, options) {   // 5
  if(this._conn) {                                                                // 6
    throw new Error("MongoDiscovery is already connected!");                      // 7
  }                                                                               // 8
                                                                                  // 9
  options = options || {};                                                        // 10
  this._selfWeight = options.selfWeight;                                          // 11
  this._clusterInstance = clusterInstance;                                        // 12
  this._dataFetchInterval = options.dataFetchInterval || 5 * 1000;                // 13
                                                                                  // 14
  var collName = options.collName || "clusterEndpoints";                          // 15
  // connect and watch for balancers and endpoints                                // 16
  this._connUrl = mongoUrl;                                                       // 17
  this._conn = Meteor.wrapAsync(MongoClient.connect)(mongoUrl, {                  // 18
    server: {poolSize: 1},                                                        // 19
    replSet: {poolSize: 1}                                                        // 20
  });                                                                             // 21
  this._endpointsColl = this._createCollection(collName);                         // 22
                                                                                  // 23
  // maintains a list of most recent endoints in the cluster                      // 24
  this._currentEndpoints = new MongoDiscoveryStore();                             // 25
  // maintains a list of most recent balancers in the cluster                     // 26
  this._currentBalancers = new MongoDiscoveryStore();                             // 27
                                                                                  // 28
  this._watchHander = this._startWatching();                                      // 29
};                                                                                // 30
                                                                                  // 31
MongoDiscovery._createCollection = function(collName) {                           // 32
  var coll = this._conn.collection(collName);                                     // 33
                                                                                  // 34
  coll.update = Meteor.wrapAsync(coll.update, coll);                              // 35
  coll.insert = Meteor.wrapAsync(coll.insert, coll);                              // 36
  coll.findOne = Meteor.wrapAsync(coll.findOne, coll);                            // 37
                                                                                  // 38
  var originalFind = coll.find;                                                   // 39
  coll.find = function() {                                                        // 40
    var cursor = originalFind.apply(coll, arguments);                             // 41
    cursor.fetch = function() {                                                   // 42
      cursor.rewind();                                                            // 43
      return Meteor.wrapAsync(cursor.toArray, cursor)();                          // 44
    };                                                                            // 45
    return cursor;                                                                // 46
  };                                                                              // 47
                                                                                  // 48
  return coll;                                                                    // 49
};                                                                                // 50
                                                                                  // 51
MongoDiscovery.disconnect = function disconnect() {                               // 52
  var self = this;                                                                // 53
  this._watchHander.stop();                                                       // 54
  this._watchHander = null;                                                       // 55
                                                                                  // 56
  this._conn.close();                                                             // 57
  this._conn = null;                                                              // 58
                                                                                  // 59
  if(this._pingHandler) {                                                         // 60
    Meteor.clearTimeout(this._pingHandler);                                       // 61
  }                                                                               // 62
                                                                                  // 63
  [                                                                               // 64
    '_connUrl', '_conn', '_endpointsColl', '_currentEndpoints',                   // 65
    '_currentBalancers', '_watchHander', '_serviceName', '_balancer',             // 66
    '_endpoint', '_endpointHash', '_pingHandler', '_pingInterval'                 // 67
  ].forEach(function(field) {                                                     // 68
    self[field] = null;                                                           // 69
  });                                                                             // 70
};                                                                                // 71
                                                                                  // 72
MongoDiscovery.register = function register(serviceName, options) {               // 73
  if(this._pingHandler) {                                                         // 74
    throw new Error("this endpoint is already registered!");                      // 75
  }                                                                               // 76
                                                                                  // 77
  options = options || {};                                                        // 78
  this._pingInterval = options.pingInterval || 5 * 1000;                          // 79
                                                                                  // 80
  var balancer = options.balancer;                                                // 81
  var endpoint = options.endpoint || balancer;                                    // 82
                                                                                  // 83
  if(!endpoint) {                                                                 // 84
    console.warn("cluster: no endpoint url. cannot register with the cluster");   // 85
    return;                                                                       // 86
  }                                                                               // 87
                                                                                  // 88
  this._serviceName = serviceName;                                                // 89
  this._balancer = balancer;                                                      // 90
  this._endpoint = endpoint;                                                      // 91
  this._endpointHash = this._hash(endpoint);                                      // 92
                                                                                  // 93
  // pinging logic                                                                // 94
  this._ping({sendAllInfo: true});                                                // 95
  this._pingHandler =                                                             // 96
    Meteor.setInterval(this._ping.bind(this), this._pingInterval);                // 97
};                                                                                // 98
                                                                                  // 99
MongoDiscovery.pickEndpoint = function pickEndpoint(serviceName) {                // 100
  // check heathly when picking                                                   // 101
  var service = this._getEndpoint(serviceName);                                   // 102
  if(service) {                                                                   // 103
    return service.endpoint;                                                      // 104
  }                                                                               // 105
};                                                                                // 106
                                                                                  // 107
MongoDiscovery.pickEndpointHash = function pickEndpointHash(serviceName) {        // 108
  var service = this._getEndpoint(serviceName);                                   // 109
  if(service) {                                                                   // 110
    return service.endpointHash;                                                  // 111
  }                                                                               // 112
};                                                                                // 113
                                                                                  // 114
MongoDiscovery._getEndpoint = function(serviceName) {                             // 115
  if(this._selfWeight >= 0) {                                                     // 116
    var endpointHash = this._hash(this._clusterInstance._endpoint);               // 117
    var service = this._currentEndpoints.                                         // 118
      getRandomWeighted(serviceName, endpointHash, this._selfWeight);             // 119
    return service;                                                               // 120
  } else {                                                                        // 121
    var service = this._currentEndpoints.getRandom(serviceName);                  // 122
    return service;                                                               // 123
  }                                                                               // 124
};                                                                                // 125
                                                                                  // 126
MongoDiscovery.hashToEndpoint = function hashToEndpoint(hash) {                   // 127
  var service = this._currentEndpoints.byEndpointHash(hash);                      // 128
  if(service) {                                                                   // 129
    return service.endpoint;                                                      // 130
  }                                                                               // 131
};                                                                                // 132
                                                                                  // 133
MongoDiscovery.endpointToHash = function endpointToHash(endpoint) {               // 134
  return this._hash(endpoint);                                                    // 135
}                                                                                 // 136
                                                                                  // 137
// balancer's serviceName is optional                                             // 138
// It doesn't need to be a service                                                // 139
MongoDiscovery.pickBalancer = function pickBalancer(endpointHash) {               // 140
  if(endpointHash) {                                                              // 141
    var endpointService = this._currentEndpoints.byEndpointHash(endpointHash);    // 142
    if(endpointService && endpointService.balancer) {                             // 143
      return endpointService.balancer;                                            // 144
    }                                                                             // 145
  }                                                                               // 146
                                                                                  // 147
  var balancerService = this._currentBalancers.getRandom();                       // 148
  if(balancerService) {                                                           // 149
    return balancerService.balancer;                                              // 150
  }                                                                               // 151
                                                                                  // 152
  return null;                                                                    // 153
};                                                                                // 154
                                                                                  // 155
MongoDiscovery.hasBalancer = function(balancer) {                                 // 156
  return !!this._currentBalancers.byBalancer(balancer);                           // 157
};                                                                                // 158
                                                                                  // 159
MongoDiscovery._hash = function _hash(endpoint) {                                 // 160
  var crypto = Npm.require('crypto');                                             // 161
  var algo = crypto.createHash('sha1');                                           // 162
  algo.update(endpoint);                                                          // 163
  return algo.digest('hex');                                                      // 164
};                                                                                // 165
                                                                                  // 166
MongoDiscovery._ping = function _ping(options) {                                  // 167
  options = options || {};                                                        // 168
  var sendAllInfo = options.sendAllInfo || false;                                 // 169
                                                                                  // 170
  var selector = {                                                                // 171
    serviceName: this._serviceName,                                               // 172
    endpoint: this._endpoint,                                                     // 173
  };                                                                              // 174
                                                                                  // 175
  var payload = {                                                                 // 176
    timestamp: new Date(),                                                        // 177
    pingInterval: this._pingInterval                                              // 178
  };                                                                              // 179
                                                                                  // 180
  if(sendAllInfo) {                                                               // 181
    payload.endpointHash = this._endpointHash;                                    // 182
    payload.balancer = this._balancer;                                            // 183
  }                                                                               // 184
                                                                                  // 185
  this._endpointsColl.update(selector, {$set: payload}, {upsert: true});          // 186
};                                                                                // 187
                                                                                  // 188
MongoDiscovery._startWatching = function _startWatching() {                       // 189
  var endpointCursor = this._endpointsColl.find({}, {                             // 190
    sort: {timestamp: -1},                                                        // 191
    limit: 100                                                                    // 192
  });                                                                             // 193
                                                                                  // 194
  var balancerSelector = {balancer: {$ne: null}};                                 // 195
  var balancerCursor = this._endpointsColl.find(balancerSelector, {               // 196
    sort: {timestamp: -1},                                                        // 197
    limit: 100                                                                    // 198
  });                                                                             // 199
                                                                                  // 200
  var endpointHandler =                                                           // 201
    this._observerAndStore(endpointCursor, this._currentEndpoints);               // 202
  var balancerHandler =                                                           // 203
    this._observerAndStore(balancerCursor, this._currentBalancers);               // 204
                                                                                  // 205
  var returnPayload = {                                                           // 206
    stop: function() {                                                            // 207
      endpointHandler.stop();                                                     // 208
      balancerHandler.stop();                                                     // 209
    }                                                                             // 210
  };                                                                              // 211
                                                                                  // 212
  return returnPayload;                                                           // 213
};                                                                                // 214
                                                                                  // 215
MongoDiscovery._observerAndStore =                                                // 216
function _observerAndStore(cursor, store, options) {                              // 217
  var self = this;                                                                // 218
  var existingServices = {};                                                      // 219
  var stopped = false;                                                            // 220
                                                                                  // 221
  fecthAndWatch();                                                                // 222
                                                                                  // 223
  function fecthAndWatch() {                                                      // 224
    if(stopped) {                                                                 // 225
      return false;                                                               // 226
    }                                                                             // 227
                                                                                  // 228
    var newServices = cursor.fetch().filter(MongoDiscovery._isHealthy);           // 229
                                                                                  // 230
    var existingServiceIds = _.keys(existingServices);                            // 231
    var newServiceIds = newServices.map(function(service) {                       // 232
      return service._id;                                                         // 233
    });                                                                           // 234
                                                                                  // 235
    var removedServices = _.difference(existingServiceIds, newServiceIds);        // 236
    removedServices.forEach(function(id) {                                        // 237
      delete existingServices[id];                                                // 238
      store.remove(id);                                                           // 239
    });                                                                           // 240
                                                                                  // 241
    newServices.forEach(function(service) {                                       // 242
      existingServices[service._id] = true;                                       // 243
      store.set(service._id, service);                                            // 244
    });                                                                           // 245
                                                                                  // 246
    // Check whether existing services are updated or not                         // 247
    store.getAll().forEach(function(service) {                                    // 248
      if(!MongoDiscovery._isHealthy(service)) {                                   // 249
        store.remove(service._id);                                                // 250
      }                                                                           // 251
    });                                                                           // 252
                                                                                  // 253
    Meteor.setTimeout(fecthAndWatch, self._dataFetchInterval);                    // 254
  }                                                                               // 255
                                                                                  // 256
  var returnPayload = {                                                           // 257
    stop: function() {                                                            // 258
      stopped = true;                                                             // 259
    }                                                                             // 260
  };                                                                              // 261
                                                                                  // 262
  return returnPayload;                                                           // 263
};                                                                                // 264
                                                                                  // 265
MongoDiscovery._isHealthy = function _isHealthy(service) {                        // 266
  var diff = Date.now() - service.timestamp.getTime();                            // 267
  // We need to add this 15 seconds padding because of Meteor polls               // 268
  // for every 10 secs.                                                           // 269
  // We are adding 15 secs just for make sure everything is fine                  // 270
  return diff < (service.pingInterval + 15 * 1000);                               // 271
};                                                                                // 272
////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/server/utils.js                               //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
OverShadowServerEvent = function OverShadowServerEvent(event, handler) {          // 1
  var httpServer = Package.webapp.WebApp.httpServer;                              // 2
  var oldHttpServerListeners = httpServer.listeners(event).slice(0);              // 3
  httpServer.removeAllListeners(event);                                           // 4
                                                                                  // 5
  var newListener = function(request /*, moreArguments */) {                      // 6
    // Store arguments for use within the closure below                           // 7
    var args = arguments;                                                         // 8
    if(handler.apply(httpServer, args) !== true) {                                // 9
      _.each(oldHttpServerListeners, function(oldListener) {                      // 10
        oldListener.apply(httpServer, args);                                      // 11
      });                                                                         // 12
    };                                                                            // 13
  };                                                                              // 14
  httpServer.addListener(event, newListener);                                     // 15
}                                                                                 // 16
////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/server/worker_pool.js                         //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
var child_process = Npm.require('child_process');                                 // 1
var portscanner = Npm.require('portscanner');                                     // 2
                                                                                  // 3
if(process.env['CLUSTER_WORKER_ID']) {                                            // 4
  // If this is a worker, notify the master that I'm ready to                     // 5
  // Accept requests                                                              // 6
  WebApp.onListening(function() {                                                 // 7
    process.send({                                                                // 8
      type: "ready"                                                               // 9
    });                                                                           // 10
  });                                                                             // 11
}                                                                                 // 12
                                                                                  // 13
WorkerPool = function WorkerPool(size) {                                          // 14
  if(process.env['CLUSTER_WORKER_ID']) {                                          // 15
    return;                                                                       // 16
  }                                                                               // 17
                                                                                  // 18
  var self = this;                                                                // 19
  this._exec = process.argv[1];                                                   // 20
  this._args = process.argv.slice(2);                                             // 21
                                                                                  // 22
  this._workers = [];                                                             // 23
  this._workersMap = {};                                                          // 24
                                                                                  // 25
  this._ids = 0;                                                                  // 26
  this._closed = false;                                                           // 27
                                                                                  // 28
  for(var lc=0; lc<size; lc++) {                                                  // 29
    this._createWorker();                                                         // 30
  }                                                                               // 31
                                                                                  // 32
  this._recentReconnects = 0;                                                     // 33
  this._lastReconnectAt = 0;                                                      // 34
                                                                                  // 35
  _.each(['SIGINT', 'SIGHUP', 'SIGTERM'], function (sig) {                        // 36
    process.once(sig, self._cleanup.bind(self));                                  // 37
  });                                                                             // 38
}                                                                                 // 39
                                                                                  // 40
WorkerPool.prototype.pickWorker = function() {                                    // 41
  var workerCount = this._workers.length;                                         // 42
  if(!workerCount) return null;                                                   // 43
                                                                                  // 44
  var index = Math.floor(workerCount * Math.random());                            // 45
  var worker = _.pick(this._workers[index], "id", "port", "process");             // 46
  return worker;                                                                  // 47
};                                                                                // 48
                                                                                  // 49
WorkerPool.prototype.hasWorker = function(id) {                                   // 50
  return !!this._workersMap[id];                                                  // 51
};                                                                                // 52
                                                                                  // 53
WorkerPool.prototype._fork = function _fork(callback) {                           // 54
  var self = this;                                                                // 55
  var id = ++self._ids;                                                           // 56
                                                                                  // 57
  // We need to give some random range like this                                  // 58
  // Othewise, it'll select some the same port since                              // 59
  // It takes some time to bind to a port                                         // 60
  var firstPort = Math.ceil(Math.random() * 20000) + 2000;                        // 61
  var secondPort = firstPort + 1;                                                 // 62
  portscanner.findAPortNotInUse(firstPort, secondPort, '127.0.0.1', withPort);    // 63
                                                                                  // 64
  function withPort(error, port) {                                                // 65
    if(error) throw error;                                                        // 66
                                                                                  // 67
    var env = _.extend(_.clone(process.env), {                                    // 68
      'PORT': port,                                                               // 69
      'CLUSTER_WORKER_ID': id                                                     // 70
    });                                                                           // 71
                                                                                  // 72
    var _process = child_process.fork(self._exec, self._args, {                   // 73
      env: env,                                                                   // 74
      silent: false                                                               // 75
    });                                                                           // 76
                                                                                  // 77
    var worker = {                                                                // 78
      process: _process,                                                          // 79
      id: id,                                                                     // 80
      port: port                                                                  // 81
    };                                                                            // 82
                                                                                  // 83
    callback(worker);                                                             // 84
  }                                                                               // 85
};                                                                                // 86
                                                                                  // 87
WorkerPool.prototype._createWorker = function() {                                 // 88
  var self = this;                                                                // 89
                                                                                  // 90
  self._fork(function(worker) {                                                   // 91
    var message = "Cluster: Initializing worker %s on port %s";                   // 92
    console.info(message, worker.id, worker.port);                                // 93
                                                                                  // 94
    worker.process.on('message', registerWorker);                                 // 95
                                                                                  // 96
    // TODO: learn a bit about exitCode and signalCode                            // 97
    worker.process.once('exit', function(exitCode, signalCode) {                  // 98
      var message = "Cluster: Exiting worker %s with exitCode=%s signalCode=%s";  // 99
      console.info(message, worker.id, exitCode, signalCode);                     // 100
                                                                                  // 101
      // Sometimes, It's possible to exit the worker                              // 102
      // even before it became ready                                              // 103
      var index = self._workers.indexOf(worker);                                  // 104
      if(index >= 0) {                                                            // 105
        self._workers.splice(index, 1);                                           // 106
        delete self._workersMap[worker.id];                                       // 107
      }                                                                           // 108
                                                                                  // 109
      if(!self._closed) {                                                         // 110
        var reconnectTimeout = self._getReconnectTimeout();                       // 111
        if(reconnectTimeout === 0) {                                              // 112
          self._createWorker();                                                   // 113
        } else {                                                                  // 114
          setTimeout(self._createWorker.bind(self), reconnectTimeout);            // 115
        }                                                                         // 116
      }                                                                           // 117
    });                                                                           // 118
                                                                                  // 119
    function registerWorker(message) {                                            // 120
      if(message && message.type === "ready") {                                   // 121
        self._workers.push(worker);                                               // 122
        self._workersMap[worker.id] = worker;                                     // 123
                                                                                  // 124
        // remove this worker                                                     // 125
        process.removeListener('message', registerWorker);                        // 126
      }                                                                           // 127
    }                                                                             // 128
  });                                                                             // 129
};                                                                                // 130
                                                                                  // 131
WorkerPool.prototype._cleanup = function(sig) {                                   // 132
  this._closed = true;                                                            // 133
  this._workers.forEach(function(worker) {                                        // 134
    worker.process.kill(sig);                                                     // 135
  });                                                                             // 136
  process.kill(process.pid, sig);                                                 // 137
};                                                                                // 138
                                                                                  // 139
WorkerPool.prototype._getReconnectTimeout = function() {                          // 140
  var timeDiff = Date.now() - this._lastReconnectAt;                              // 141
  var oneMinTime = 1000 * 60;                                                     // 142
  if(timeDiff > oneMinTime) {                                                     // 143
    this._recentReconnects = 0;                                                   // 144
  }                                                                               // 145
                                                                                  // 146
  var reconnectTime = this._recentReconnects * 500;                               // 147
                                                                                  // 148
  this._recentReconnects++;                                                       // 149
  this._lastReconnectAt = Date.now();                                             // 150
                                                                                  // 151
  return reconnectTime;                                                           // 152
};                                                                                // 153
////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/server/balancer/namespace.js                  //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
var HttpProxy = Npm.require('http-proxy');                                        // 1
var http = Npm.require('http');                                                   // 2
http.globalAgent.maxSockets = 99999;                                              // 3
                                                                                  // 4
Balancer = {};                                                                    // 5
Balancer.proxy = HttpProxy.createProxyServer({                                    // 6
  xfwd: true                                                                      // 7
});                                                                               // 8
////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/server/balancer/utils.js                      //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
var urlParse = Npm.require('url').parse;                                          // 1
var urlResolve = Npm.require('url').resolve;                                      // 2
                                                                                  // 3
Balancer._buildCookie = function _buildCookie(name, service) {                    // 4
  return name + "::" + service;                                                   // 5
};                                                                                // 6
                                                                                  // 7
Balancer._urlToTarget = function _urlToTarget(url) {                              // 8
  var parsedUrl = urlParse(url);                                                  // 9
  var target = {                                                                  // 10
    host: parsedUrl.hostname,                                                     // 11
    port: parsedUrl.port                                                          // 12
  };                                                                              // 13
                                                                                  // 14
  return target;                                                                  // 15
};                                                                                // 16
                                                                                  // 17
Balancer._pickAndSetEndpointHash =                                                // 18
function _pickAndSetEndpointHash(cookies) {                                       // 19
  var service = Cluster._uiService;                                               // 20
  var endpointHash = Cluster.discovery.pickEndpointHash(service);                 // 21
  if(endpointHash) {                                                              // 22
    var cookieOptions = {                                                         // 23
      httpOnly: true                                                              // 24
    };                                                                            // 25
    var cookieName = Balancer._buildCookie('cluster-endpoint', service);          // 26
    cookies.set(cookieName, endpointHash, cookieOptions);                         // 27
    return endpointHash;                                                          // 28
  } else {                                                                        // 29
    // no endpoint point, simply process the request here                         // 30
    return false;                                                                 // 31
  }                                                                               // 32
};                                                                                // 33
                                                                                  // 34
Balancer._pickEndpoint =                                                          // 35
function _pickEndpoint(endpointHash, cookies, retries) {                          // 36
  retries = retries || 0;                                                         // 37
  if(retries > 1) return false;                                                   // 38
                                                                                  // 39
  if(!endpointHash) {                                                             // 40
    endpointHash = Balancer._pickAndSetEndpointHash(cookies);                     // 41
    if(!endpointHash) {                                                           // 42
      // no endpoint, simply process the request here                             // 43
      return false;                                                               // 44
    }                                                                             // 45
  }                                                                               // 46
                                                                                  // 47
  var endpoint = Cluster.discovery.hashToEndpoint(endpointHash);                  // 48
  if(!endpoint) {                                                                 // 49
    // oops, no such endpoint. Let's get a new one.                               // 50
    return Balancer._pickEndpoint(null, cookies, ++retries);                      // 51
  }                                                                               // 52
                                                                                  // 53
  return endpoint;                                                                // 54
};                                                                                // 55
                                                                                  // 56
Balancer._pickJustEndpoint = function _pickJustEndpoint(endpointHash, service) {  // 57
  if(!service) throw new Error("service name is required");                       // 58
                                                                                  // 59
  if(!endpointHash) {                                                             // 60
    // no hash, pick a new endpoint                                               // 61
    return Cluster.discovery.pickEndpoint(service);                               // 62
  }                                                                               // 63
                                                                                  // 64
  var endpoint = Cluster.discovery.hashToEndpoint(endpointHash);                  // 65
  if(!endpoint) {                                                                 // 66
    // oops, no such endpoint for this hash                                       // 67
    // pick a new endpoint                                                        // 68
    return Cluster.discovery.pickEndpoint(service);                               // 69
  }                                                                               // 70
                                                                                  // 71
  return endpoint;                                                                // 72
};                                                                                // 73
                                                                                  // 74
Balancer._setFromBalanceUrlHeader =                                               // 75
function _setFromBalanceUrlHeader(req, balancerUrl) {                             // 76
  req.headers['from-balancer'] = "YES";                                           // 77
};                                                                                // 78
                                                                                  // 79
Balancer._sendSockJsInfo =                                                        // 80
function _sendSockJsInfo(req, res, cookies) {                                     // 81
  var urlParsed = req.url.match(/(\w+)\/sockjs\/info/);                           // 82
  var serviceName = urlParsed && urlParsed[1];                                    // 83
                                                                                  // 84
  if(!serviceName) {                                                              // 85
    serviceName = Cluster._uiService;                                             // 86
  }                                                                               // 87
                                                                                  // 88
  if(serviceName === Cluster._uiService) {                                        // 89
    var cookieName = Balancer._buildCookie('cluster-endpoint', serviceName);      // 90
    var endpointHash = cookies.get(cookieName);                                   // 91
    var endpoint = Balancer._pickJustEndpoint(endpointHash, serviceName);         // 92
  } else if(Cluster._isPublicService(serviceName)) {                              // 93
    var endpoint = Balancer._pickJustEndpoint(null, serviceName);                 // 94
  }                                                                               // 95
                                                                                  // 96
  if(!endpoint) {                                                                 // 97
    // we can't process this here.                                                // 98
    // TODO: better error handling                                                // 99
    console.error("Cluster: no such endpoint for service:" + serviceName);        // 100
    res.writeHead(404);                                                           // 101
    return res.end("no such endpoint for service: " + serviceName);               // 102
  }                                                                               // 103
                                                                                  // 104
  var endpointHash = Cluster.discovery.endpointToHash(endpoint);                  // 105
  // when no balancer url is provided,                                            // 106
  // using ROOT_URL instead of relative path                                      // 107
  var balancer =                                                                  // 108
    Cluster.discovery.pickBalancer(endpointHash) ||                               // 109
    process.env.ROOT_URL;                                                         // 110
  // add tail backslash if path not end with it                                   // 111
  balancer = (/\/$/).test(balancer)? balancer : balancer + '/';                   // 112
                                                                                  // 113
  var base_url =                                                                  // 114
    urlResolve(balancer, "cluster-ddp/" + endpointHash + "/" + serviceName);      // 115
                                                                                  // 116
  var info = {                                                                    // 117
    websocket: !process.env['DISABLE_WEBSOCKETS'],                                // 118
    origins: ["*:*"],                                                             // 119
    cookie_needed: false,                                                         // 120
    entropy: Math.ceil(Math.random() * 9999999999),                               // 121
    base_url: base_url                                                            // 122
  };                                                                              // 123
                                                                                  // 124
  res.writeHead(200, {                                                            // 125
    'content-type': 'application/json',                                           // 126
    'access-control-allow-origin': '*'                                            // 127
  });                                                                             // 128
  res.end(JSON.stringify(info));                                                  // 129
}                                                                                 // 130
                                                                                  // 131
Balancer._rewriteDdpUrl = function _rewriteDdpUrl(req) {                          // 132
  var regExp = /cluster-ddp\/(\w+)\/(\w+)/;                                       // 133
  var parsedUrl = req.url.match(regExp);                                          // 134
  if(parsedUrl) {                                                                 // 135
    req.url = req.url.replace(regExp, "sockjs/").replace(/[\/]+/g, "/");          // 136
    var endpointHash = {                                                          // 137
      hash: parsedUrl[1],                                                         // 138
      service: parsedUrl[2] || Cluster._uiService                                 // 139
    };                                                                            // 140
    return endpointHash;                                                          // 141
  }                                                                               // 142
};                                                                                // 143
                                                                                  // 144
Balancer._proxyWeb = function _proxyWeb(req, res, endpoint, cookies, retries) {   // 145
  // give support for sockjs long polling                                         // 146
  // otherwise meteor kill the connection after 5 secs by default                 // 147
  if(/sockjs/.test(req.url)) {                                                    // 148
    res.setTimeout(2 * 60 * 1000);                                                // 149
  }                                                                               // 150
                                                                                  // 151
  retries = retries || 0;                                                         // 152
  var target = Balancer._urlToTarget(endpoint);                                   // 153
                                                                                  // 154
  Balancer.proxy.web(req, res, {target: target}, function(error) {                // 155
    // It's pretty hard to do re-trying ourselves,                                // 156
    // because of the SOCKJS protocol                                             // 157
    // And it's possible to have we've already send headers and data              // 158
    // So, we don't simply retry here. Let it handle by the client                // 159
    // We can't also send 500 error because of the above issue                    // 160
    printError("Connection droped", true);                                        // 161
                                                                                  // 162
    function printError(message, dontSendHeaders) {                               // 163
      message = message || error.message;                                         // 164
      console.error("Cluster: web proxy error: ", message);                       // 165
      if(!dontSendHeaders) {                                                      // 166
        res.writeHead(500);                                                       // 167
        res.end("Internal Error: Please reload.");                                // 168
      }                                                                           // 169
    }                                                                             // 170
  });                                                                             // 171
};                                                                                // 172
                                                                                  // 173
Balancer._proxyWs = function proxyWs(req, socket, head, endpoint) {               // 174
  var target = Balancer._urlToTarget(endpoint);                                   // 175
  Balancer.proxy.ws(req, socket, head, {target: target}, function(error) {        // 176
    // not sure we can re-try websockets, simply log it                           // 177
    console.error("WS proxying failed! to: ", endpoint, "err:", error.message);   // 178
  });                                                                             // 179
};                                                                                // 180
////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/server/balancer/workers.js                    //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
var os = Npm.require('os');                                                       // 1
                                                                                  // 2
var workerMapping = {};                                                           // 3
var workers = null;                                                               // 4
                                                                                  // 5
process.on("message", function(message, socket) {                                 // 6
  if(message.type === "proxy-ws") {                                               // 7
    var httpServer = Package.webapp.WebApp.httpServer;                            // 8
    var head = new Buffer(message.head);                                          // 9
    httpServer.emit("upgrade", message.req, socket, head);                        // 10
  }                                                                               // 11
});                                                                               // 12
                                                                                  // 13
// We need to start the worker pool after the server binded                       // 14
// This allow use to play nicely with tools like userdown                         // 15
WebApp.onListening(function() {                                                   // 16
  var workersCount = Balancer._getWorkersCount();                                 // 17
  workers = new WorkerPool(workersCount);                                         // 18
});                                                                               // 19
                                                                                  // 20
Balancer._getWorkersCount = function() {                                          // 21
  var workersCount = process.env['CLUSTER_WORKERS_COUNT'];                        // 22
  if(("" + workersCount).toLowerCase() === "auto") {                              // 23
    workersCount = os.cpus().length;                                              // 24
    // We don't need to start a worker in this case                               // 25
    if(workersCount == 1) {                                                       // 26
      workersCount = 0;                                                           // 27
    }                                                                             // 28
  }                                                                               // 29
                                                                                  // 30
  // Make sure it's a number                                                      // 31
  workersCount = parseInt(workersCount) || 0;                                     // 32
                                                                                  // 33
  return workersCount;                                                            // 34
};                                                                                // 35
                                                                                  // 36
Balancer._pickWorker = function() {                                               // 37
  return workers && workers.pickWorker();                                         // 38
};                                                                                // 39
                                                                                  // 40
Balancer._processHereWS = function _processHereWS(req, socket, head) {            // 41
  if(process.env['CLUSTER_WORKER_ID']) return false;                              // 42
                                                                                  // 43
  var worker = Balancer._pickWorker();                                            // 44
  // No worker, can't proxy. So process here.                                     // 45
  if(!worker) return false;                                                       // 46
                                                                                  // 47
  var keys = [                                                                    // 48
    "readable","domain","httpVersion","complete","headers",                       // 49
    "trailers","_pendings","_pendingIndex","url","method",                        // 50
    "statusCode", "_consuming","_dumped","httpVersionMajor",                      // 51
    "httpVersionMinor","upgrade"                                                  // 52
  ];                                                                              // 53
                                                                                  // 54
  worker.process.send({                                                           // 55
    type: "proxy-ws",                                                             // 56
    req: _.pick(req, keys),                                                       // 57
    head: head.toString("utf8")                                                   // 58
  }, socket);                                                                     // 59
  return true;                                                                    // 60
};                                                                                // 61
                                                                                  // 62
Balancer._processHereHTTP = function _processHereHTTP(req, res) {                 // 63
  if(process.env['CLUSTER_WORKER_ID']) return false;                              // 64
                                                                                  // 65
  var longPollingMatcher =  /^\/sockjs\/([0-9]+)\/(\w+)\/xhr/;                    // 66
  var match = req.url.match(longPollingMatcher);                                  // 67
  if(match) {                                                                     // 68
    var id = match[1] + match[2];                                                 // 69
    if(!workerMapping[id]) {                                                      // 70
      var worker = Balancer._pickWorker();                                        // 71
      if(worker) {                                                                // 72
        workerMapping[id] = {worker: worker, lastUpdate: Date.now()}              // 73
      }                                                                           // 74
    }                                                                             // 75
                                                                                  // 76
    if(workerMapping[id]) {                                                       // 77
      workerMapping[id].lastUpdate = Date.now();                                  // 78
      var target = {host: "127.0.0.1", port: workerMapping[id].worker.port}       // 79
      // Make sure we support long polling                                        // 80
      res.setTimeout(2 * 60 * 1000);                                              // 81
      Balancer.proxy.web(req, res, {target: target}, function(err) {              // 82
        // res.end();                                                             // 83
        // Since this is long polling, error can happen even if user close the    // 84
        // session. That's why we don't print the message.                        // 85
                                                                                  // 86
        // Now we also delete the mapping. Then we don't have a leak on           // 87
        // workerMapping.                                                         // 88
        // XXX come up with a better plan to clean up workerMapping               // 89
        delete workerMapping[id];                                                 // 90
      });                                                                         // 91
      return true;                                                                // 92
    } else {                                                                      // 93
      // Do not proxy, if we can't find out a worker                              // 94
      return false;                                                               // 95
    }                                                                             // 96
  } else {                                                                        // 97
    // Do not proxy for other files                                               // 98
    return false;                                                                 // 99
  }                                                                               // 100
}                                                                                 // 101
////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/server/balancer/route.js                      //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
var Cookies = Npm.require('cookies');                                             // 1
                                                                                  // 2
Balancer.handleHttp = function handleHttp(req, res) {                             // 3
  if(process.env['CLUSTER_WORKER_ID']) {                                          // 4
    return false;                                                                 // 5
  }                                                                               // 6
                                                                                  // 7
  if(!Cluster.discovery) return Balancer._processHereHTTP(req, res);              // 8
                                                                                  // 9
  // if this is from a balance, we don't need to proxy it                         // 10
  if(req.headers['from-balancer']) {                                              // 11
    return Balancer._processHereHTTP(req, res);                                   // 12
  }                                                                               // 13
                                                                                  // 14
  var cookies = new Cookies(req, res);                                            // 15
                                                                                  // 16
  if(/\/sockjs\/info/.test(req.url)) {                                            // 17
    Balancer._sendSockJsInfo(req, res, cookies);                                  // 18
    return true;                                                                  // 19
  }                                                                               // 20
                                                                                  // 21
  // try to get endpointHash from the our cluster-ddp url                         // 22
  // this is for sockjs long polling requets                                      // 23
  var endpointInfo = Balancer._rewriteDdpUrl(req);                                // 24
  if(endpointInfo) {                                                              // 25
    var endpoint =                                                                // 26
      Balancer._pickJustEndpoint(endpointInfo.hash, endpointInfo.service);        // 27
                                                                                  // 28
    if(!endpoint) {                                                               // 29
      // seems like sockjs connection is not there yet!                           // 30
      // let's end it here.                                                       // 31
      var message = "Cluster: there is no endpoint but we've a hash: ";           // 32
      console.error(message + endpointInfo.hash);                                 // 33
      res.writeHead(500);                                                         // 34
      res.end();                                                                  // 35
      return true;                                                                // 36
    }                                                                             // 37
  }                                                                               // 38
                                                                                  // 39
  if(!endpointInfo) {                                                             // 40
    // seems like this is just static resources                                   // 41
    // we can get the endpointHash from the cookie                                // 42
    var endpointHash = cookies.get('cluster-endpoint');                           // 43
    var endpoint = Balancer._pickEndpoint(endpointHash, cookies);                 // 44
    if(!endpoint) return Balancer._processHereHTTP(req, res);                     // 45
  }                                                                               // 46
                                                                                  // 47
  if(endpoint === Cluster._endpoint) {                                            // 48
    return Balancer._processHereHTTP(req, res);                                   // 49
  }                                                                               // 50
                                                                                  // 51
  Balancer._setFromBalanceUrlHeader(req);                                         // 52
  Balancer._proxyWeb(req, res, endpoint, cookies);                                // 53
  return true;                                                                    // 54
};                                                                                // 55
                                                                                  // 56
Balancer.handleWs = function handleWs(req, socket, head) {                        // 57
  if(process.env['CLUSTER_WORKER_ID']) {                                          // 58
    return false;                                                                 // 59
  }                                                                               // 60
                                                                                  // 61
  if(!Cluster.discovery) return Balancer._processHereWS(req, socket, head);       // 62
                                                                                  // 63
  if(req.headers['from-balancer']) {                                              // 64
    // if this is from a balance, we don't need to proxy it                       // 65
    return Balancer._processHereWS(req, socket, head)                             // 66
  }                                                                               // 67
                                                                                  // 68
  // try to get endpointHash from the our cluster-ddp url                         // 69
  var endpointInfo = Balancer._rewriteDdpUrl(req);                                // 70
  if(endpointInfo) {                                                              // 71
    var endpoint =                                                                // 72
      Balancer._pickJustEndpoint(endpointInfo.hash, endpointInfo.service);        // 73
  }                                                                               // 74
                                                                                  // 75
  // try to get the endpointHash from the cookie                                  // 76
  // this is when there is no balancer url                                        // 77
  if(!endpointInfo) {                                                             // 78
    var cookies = new Cookies(req);                                               // 79
    var endpointHash = cookies.get('cluster-endpoint');                           // 80
    if(endpointHash) {                                                            // 81
      var endpoint = Balancer._pickJustEndpoint(endpointHash);                    // 82
    } else {                                                                      // 83
      // seems like a direct connection                                           // 84
      // just process here. We don't need to route it to a random web service     // 85
      // because, it is possible that this endpoint is for some other service     // 86
      // than web.                                                                // 87
      return Balancer._processHereWS(req, socket, head);                          // 88
    }                                                                             // 89
  }                                                                               // 90
                                                                                  // 91
  if(!endpoint) {                                                                 // 92
    return Balancer._processHereWS(req, socket, head);                            // 93
  }                                                                               // 94
                                                                                  // 95
  if(endpoint === Cluster._endpoint) {                                            // 96
    return Balancer._processHereWS(req, socket, head);                            // 97
  }                                                                               // 98
                                                                                  // 99
  Balancer._setFromBalanceUrlHeader(req);                                         // 100
  Balancer._proxyWs(req, socket, head, endpoint);                                 // 101
  return true;                                                                    // 102
};                                                                                // 103
                                                                                  // 104
OverShadowServerEvent('request', Balancer.handleHttp);                            // 105
OverShadowServerEvent('upgrade', Balancer.handleWs);                              // 106
////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
// packages/meteorhacks:cluster/lib/server/auto_connect.js                        //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
                                                                                  //
var discoveryUrl = process.env['CLUSTER_DISCOVERY_URL'];                          // 1
if(discoveryUrl) {                                                                // 2
  var options = {};                                                               // 3
  var selfWeight = parseFloat(process.env['CLUSTER_SELF_WEIGHT']);                // 4
  if(selfWeight >= 0) {                                                           // 5
    options.selfWeight = selfWeight;                                              // 6
  }                                                                               // 7
                                                                                  // 8
  Cluster.connect(discoveryUrl, options);                                         // 9
}                                                                                 // 10
                                                                                  // 11
var serviceName = process.env['CLUSTER_SERVICE'];                                 // 12
if(serviceName) {                                                                 // 13
  Cluster.register(serviceName);                                                  // 14
}                                                                                 // 15
                                                                                  // 16
var publicServices = process.env['CLUSTER_PUBLIC_SERVICES'];                      // 17
if(publicServices) {                                                              // 18
  publicServices = publicServices.split(',').map(function(service) {              // 19
    return service.trim();                                                        // 20
  });                                                                             // 21
  Cluster.allowPublicAccess(publicServices);                                      // 22
}                                                                                 // 23
////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['meteorhacks:cluster'] = {}, {
  Cluster: Cluster
});

})();
