var require = meteorInstall({"lib":{"db.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/db.js                                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
posts = new Mongo.Collection('posts');                                                                                 // 1
raids = new Mongo.Collection('raids');                                                                                 // 2
questions = new Mongo.Collection('questions');                                                                         // 3
apps = new Mongo.Collection('apps');                                                                                   // 4
userCount = new Mongo.Collection('userCount');                                                                         // 5
siteDetails = new Mongo.Collection('siteDetails');                                                                     // 6
twitch = new Mongo.Collection('twitch');                                                                               // 7
counts = new Mongo.Collection('counts');                                                                               // 9
images = new Mongo.Collection('images'); //denys anyone access to these (unless the above allow is met)                // 11
                                                                                                                       //
posts.deny({                                                                                                           // 14
  update: function () {                                                                                                // 15
    return true;                                                                                                       // 16
  },                                                                                                                   // 17
  insert: function () {                                                                                                // 19
    return true;                                                                                                       // 20
  }                                                                                                                    // 21
});                                                                                                                    // 14
twitch.deny({                                                                                                          // 24
  update: function () {                                                                                                // 25
    return true;                                                                                                       // 26
  },                                                                                                                   // 27
  insert: function () {                                                                                                // 29
    return true;                                                                                                       // 30
  }                                                                                                                    // 31
});                                                                                                                    // 24
images.deny({                                                                                                          // 34
  update: function () {                                                                                                // 35
    return true;                                                                                                       // 36
  },                                                                                                                   // 37
  insert: function () {                                                                                                // 39
    return true;                                                                                                       // 40
  }                                                                                                                    // 41
});                                                                                                                    // 34
apps.deny({                                                                                                            // 44
  update: function () {                                                                                                // 45
    return true;                                                                                                       // 46
  },                                                                                                                   // 47
  insert: function () {                                                                                                // 49
    return true;                                                                                                       // 50
  }                                                                                                                    // 51
});                                                                                                                    // 44
questions.deny({                                                                                                       // 54
  update: function () {                                                                                                // 55
    return true;                                                                                                       // 56
  },                                                                                                                   // 57
  insert: function () {                                                                                                // 59
    return true;                                                                                                       // 60
  }                                                                                                                    // 61
});                                                                                                                    // 54
raids.deny({                                                                                                           // 64
  update: function () {                                                                                                // 65
    return true;                                                                                                       // 66
  },                                                                                                                   // 67
  insert: function () {                                                                                                // 69
    return true;                                                                                                       // 70
  }                                                                                                                    // 71
});                                                                                                                    // 64
Meteor.users.deny({                                                                                                    // 74
  update: function () {                                                                                                // 75
    return true;                                                                                                       // 76
  }                                                                                                                    // 77
});                                                                                                                    // 74
userCount.deny({                                                                                                       // 80
  update: function () {                                                                                                // 81
    return true;                                                                                                       // 82
  },                                                                                                                   // 83
  insert: function () {                                                                                                // 85
    return true;                                                                                                       // 86
  }                                                                                                                    // 87
});                                                                                                                    // 80
siteDetails.deny({                                                                                                     // 90
  update: function () {                                                                                                // 91
    return true;                                                                                                       // 92
  },                                                                                                                   // 93
  insert: function () {                                                                                                // 95
    return true;                                                                                                       // 96
  }                                                                                                                    // 97
});                                                                                                                    // 90
counts.deny({                                                                                                          // 101
  update: function () {                                                                                                // 102
    return true;                                                                                                       // 103
  },                                                                                                                   // 104
  insert: function () {                                                                                                // 106
    return true;                                                                                                       // 107
  }                                                                                                                    // 108
});                                                                                                                    // 101
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"globals.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/globals.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//defaults to feed (home)                                                                                              // 1
currentPage = new ReactiveVar("feed"); //gets currentPost                                                              // 2
                                                                                                                       //
currentPost = new ReactiveVar(); //admin page location                                                                 // 5
                                                                                                                       //
adminLoc = new ReactiveVar("dash"); //the news filter                                                                  // 8
                                                                                                                       //
newsFilter = new ReactiveVar('news'); //for application viewing                                                        // 11
                                                                                                                       //
currentApp = new ReactiveVar('currentApp'); //for viewing existing raid                                                // 14
                                                                                                                       //
currentRaid = new ReactiveVar('currentRaid'); //for deleting stuff                                                     // 17
                                                                                                                       //
deleting = new ReactiveVar(''); //for loading image in carousel                                                        // 20
                                                                                                                       //
currentImage = new ReactiveVar(''); //for lazy loading                                                                 // 23
                                                                                                                       //
postLimitServer = new ReactiveVar(7); //test                                                                           // 26
                                                                                                                       //
imageTest = new ReactiveVar(); //get post ID from slug, load                                                           // 29
                                                                                                                       //
postFromSlug = new ReactiveVar(); //set app sorting                                                                    // 32
                                                                                                                       //
appSort = new ReactiveVar('');                                                                                         // 35
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routes.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
FlowRouter.route('/', {                                                                                                // 1
  name: 'home',                                                                                                        // 2
  subscriptions: function (params, queryParams) {                                                                      // 3
    // using Fast Render                                                                                               // 4
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 5
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 6
  },                                                                                                                   // 7
  action: function () {                                                                                                // 8
    BlazeLayout.render('index');                                                                                       // 9
  },                                                                                                                   // 10
  fastRender: true                                                                                                     // 11
});                                                                                                                    // 1
FlowRouter.route('/admin', {                                                                                           // 14
  name: "admin",                                                                                                       // 15
  action: function () {                                                                                                // 16
    if (Meteor.userId()) {                                                                                             // 17
      currentPage.set('admin');                                                                                        // 18
      BlazeLayout.render('admin');                                                                                     // 19
    } else {                                                                                                           // 20
      BlazeLayout.render('signin');                                                                                    // 21
    }                                                                                                                  // 22
  }                                                                                                                    // 23
});                                                                                                                    // 14
FlowRouter.route('/admin/:_id', {                                                                                      // 26
  name: 'adminRoute',                                                                                                  // 27
  action: function (params, queryParams) {                                                                             // 28
    BlazeLayout.render('admin');                                                                                       // 29
    var theseParms = params._id;                                                                                       // 30
    currentPage.set('admin');                                                                                          // 31
    var context = ['post', 'apps', 'settings', 'raids', 'twitch'];                                                     // 32
    var bttns = ['.new', '.fa-file', '.fa-cog', '.fa-trophy', '.fa-twitch'];                                           // 33
    adminLoc.set(theseParms);                                                                                          // 34
  }                                                                                                                    // 35
});                                                                                                                    // 26
FlowRouter.route('/admin-login', {                                                                                     // 39
  name: "login",                                                                                                       // 40
  action: function () {                                                                                                // 41
    BlazeLayout.render('signin');                                                                                      // 42
  }                                                                                                                    // 43
});                                                                                                                    // 39
FlowRouter.route('/p/:_id', {                                                                                          // 46
  name: 'post',                                                                                                        // 47
  subscriptions: function (params, queryParams) {                                                                      // 48
    // using Fast Render                                                                                               // 49
    this.register('posts2', Meteor.subscribe('posts2'));                                                               // 50
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 51
  },                                                                                                                   // 52
  action: function (params, queryParams) {                                                                             // 53
    BlazeLayout.render('index');                                                                                       // 54
    var theseParms = params._id;                                                                                       // 55
    currentPage.set('article');                                                                                        // 56
    currentPost.set(theseParms);                                                                                       // 57
    postFromSlug.set(params._id);                                                                                      // 58
  }                                                                                                                    // 59
});                                                                                                                    // 46
FlowRouter.route('/feed', {                                                                                            // 62
  name: 'home2',                                                                                                       // 63
  subscriptions: function (params, queryParams) {                                                                      // 64
    // using Fast Render                                                                                               // 65
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 66
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 67
  },                                                                                                                   // 68
  action: function (params, queryParams) {                                                                             // 69
    BlazeLayout.render('index');                                                                                       // 70
    currentPage.set('feed');                                                                                           // 71
  }                                                                                                                    // 72
});                                                                                                                    // 62
FlowRouter.route('/about', {                                                                                           // 75
  name: 'about',                                                                                                       // 76
  subscriptions: function (params, queryParams) {                                                                      // 77
    // using Fast Render                                                                                               // 78
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 79
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 80
  },                                                                                                                   // 81
  action: function (params, queryParams) {                                                                             // 82
    BlazeLayout.render('index');                                                                                       // 83
    currentPage.set('about');                                                                                          // 84
  }                                                                                                                    // 85
});                                                                                                                    // 75
FlowRouter.route('/apply', {                                                                                           // 88
  name: 'apply',                                                                                                       // 89
  subscriptions: function (params, queryParams) {                                                                      // 90
    // using Fast Render                                                                                               // 91
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 92
  },                                                                                                                   // 93
  action: function (params, queryParams) {                                                                             // 94
    BlazeLayout.render('index');                                                                                       // 95
    currentPage.set('apply');                                                                                          // 96
  }                                                                                                                    // 97
});                                                                                                                    // 88
FlowRouter.route('/streams', {                                                                                         // 100
  name: 'streams',                                                                                                     // 101
  subscriptions: function (params, queryParams) {                                                                      // 102
    // using Fast Render                                                                                               // 103
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 104
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 105
  },                                                                                                                   // 106
  action: function (params, queryParams) {                                                                             // 107
    BlazeLayout.render('index');                                                                                       // 108
    currentPage.set('streams');                                                                                        // 109
  }                                                                                                                    // 110
});                                                                                                                    // 100
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fileserver.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/fileserver.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var fs = Npm.require('fs');                                                                                            // 1
                                                                                                                       //
WebApp.connectHandlers.use(function (req, res, next) {                                                                 // 2
    var re = /^\/files\/(.*)$/.exec(req.url);                                                                          // 3
                                                                                                                       //
    if (re !== null) {                                                                                                 // 4
        // Only handle URLs that start with /uploads_url_prefix/*                                                      // 4
        var filePath = process.env.PWD + '/.static~/' + re[1];                                                         // 5
        var data = fs.readFileSync(filePath);                                                                          // 6
        res.writeHead(200, {                                                                                           // 7
            'Content-Type': 'image'                                                                                    // 8
        });                                                                                                            // 7
        res.write(data);                                                                                               // 10
        res.end();                                                                                                     // 11
    } else {                                                                                                           // 12
        // Other urls will have default behaviors                                                                      // 12
        next();                                                                                                        // 13
    }                                                                                                                  // 14
});                                                                                                                    // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publish.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publish("posts", function (limit) {                                                                             // 1
  var dl = limit || 7; //send data newest first to the client                                                          // 2
                                                                                                                       //
  return posts.find({}, {                                                                                              // 4
    sort: {                                                                                                            // 4
      date_created: -1                                                                                                 // 4
    },                                                                                                                 // 4
    limit: dl                                                                                                          // 4
  });                                                                                                                  // 4
});                                                                                                                    // 5
Meteor.publish("posts2", function (target) {                                                                           // 7
  return posts.find({                                                                                                  // 8
    _id: target                                                                                                        // 8
  });                                                                                                                  // 8
});                                                                                                                    // 9
Meteor.publish("raids", function () {                                                                                  // 11
  return raids.find({}, {                                                                                              // 12
    sort: {                                                                                                            // 12
      date: -1                                                                                                         // 12
    }                                                                                                                  // 12
  });                                                                                                                  // 12
});                                                                                                                    // 13
Meteor.publish("twitch", function () {                                                                                 // 15
  return twitch.find({});                                                                                              // 16
});                                                                                                                    // 17
Meteor.publish("questions", function () {                                                                              // 19
  return questions.find({});                                                                                           // 20
});                                                                                                                    // 21
Meteor.publish("siteDetails", function () {                                                                            // 23
  return siteDetails.find({});                                                                                         // 24
});                                                                                                                    // 25
Meteor.publish("counts", function () {                                                                                 // 27
  return counts.find({});                                                                                              // 28
});                                                                                                                    // 29
Meteor.publish("apps", function () {                                                                                   // 31
  return apps.find({}, {                                                                                               // 32
    sort: {                                                                                                            // 32
      date_created: -1                                                                                                 // 32
    }                                                                                                                  // 32
  });                                                                                                                  // 32
});                                                                                                                    // 33
Meteor.publish('images', function (search, post) {                                                                     // 36
  return images.find({}, {                                                                                             // 37
    sort: {                                                                                                            // 37
      date_created: -1                                                                                                 // 37
    },                                                                                                                 // 37
    limit: 7                                                                                                           // 37
  });                                                                                                                  // 37
});                                                                                                                    // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/server.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 1
  fs = Npm.require('fs'); // converts old app dates to new format                                                      // 2
                                                                                                                       //
  var testingsometing = apps.find({}).fetch();                                                                         // 5
                                                                                                                       //
  for (var i = 0; i < testingsometing.length; i++) {                                                                   // 6
    if (!testingsometing[i].date_created) {                                                                            // 7
      var id = testingsometing[i]._id;                                                                                 // 8
      var date = testingsometing[i].date;                                                                              // 9
      var date_created = date;                                                                                         // 10
      var res = date.toString().split(" ");                                                                            // 11
      date = res[1] + " " + res[2] + " " + res[3];                                                                     // 12
      apps.update({                                                                                                    // 13
        _id: id                                                                                                        // 13
      }, {                                                                                                             // 13
        $set: {                                                                                                        // 13
          date: date,                                                                                                  // 13
          date_created: date_created                                                                                   // 13
        }                                                                                                              // 13
      });                                                                                                              // 13
    }                                                                                                                  // 14
  }                                                                                                                    // 15
}); //checks to see if default site values are set, creates template for later                                         // 16
                                                                                                                       //
var needed = ['title', 'about', 'tabard', 'background', 'favicon', 'recruiting'];                                      // 19
var firstTime = 0;                                                                                                     // 20
                                                                                                                       //
for (var i = 0; i < needed.length; i++) {                                                                              // 21
  if (siteDetails.findOne({                                                                                            // 22
    _id: needed[i]                                                                                                     // 22
  })) {//horray!!                                                                                                      // 22
  } else {                                                                                                             // 24
    //lets create em                                                                                                   // 25
    siteDetails.insert({                                                                                               // 26
      _id: needed[i]                                                                                                   // 26
    });                                                                                                                // 26
    firstTime = 1;                                                                                                     // 27
  }                                                                                                                    // 28
}                                                                                                                      // 29
                                                                                                                       //
if (firstTime == 1) {                                                                                                  // 30
  //wow                                                                                                                // 31
  siteDetails.update({                                                                                                 // 32
    _id: 'recruiting'                                                                                                  // 32
  }, {                                                                                                                 // 32
    $set: {                                                                                                            // 32
      dnB: 'checked',                                                                                                  // 32
      dnU: 'checked',                                                                                                  // 32
      dnF: 'checked',                                                                                                  // 32
      dhH: 'checked',                                                                                                  // 32
      dhV: 'checked',                                                                                                  // 32
      drB: 'checked',                                                                                                  // 32
      drF: 'checked',                                                                                                  // 32
      drR: 'checked',                                                                                                  // 32
      drG: 'checked',                                                                                                  // 32
      huM: 'checked',                                                                                                  // 32
      huS: 'checked',                                                                                                  // 32
      huB: 'checked',                                                                                                  // 32
      maF: 'checked',                                                                                                  // 32
      maFr: 'checked',                                                                                                 // 32
      maA: 'checked',                                                                                                  // 32
      moM: 'checked',                                                                                                  // 32
      moW: 'checked',                                                                                                  // 32
      moB: 'checked',                                                                                                  // 32
      paH: 'checked',                                                                                                  // 32
      paR: 'checked',                                                                                                  // 32
      paP: 'checked',                                                                                                  // 32
      prS: 'checked',                                                                                                  // 32
      prD: 'checked',                                                                                                  // 32
      prH: 'checked',                                                                                                  // 32
      roA: 'checked',                                                                                                  // 32
      roS: 'checked',                                                                                                  // 32
      roC: 'checked',                                                                                                  // 32
      shE: 'checked',                                                                                                  // 32
      shR: 'checked',                                                                                                  // 32
      shEn: 'checked',                                                                                                 // 32
      waA: 'checked',                                                                                                  // 32
      waD: 'checked',                                                                                                  // 32
      waDe: 'checked',                                                                                                 // 32
      warA: 'checked',                                                                                                 // 32
      warF: 'checked',                                                                                                 // 32
      warP: 'checked'                                                                                                  // 32
    }                                                                                                                  // 32
  });                                                                                                                  // 32
  userCount.insert({                                                                                                   // 33
    count: 0                                                                                                           // 33
  });                                                                                                                  // 33
  counts.insert({                                                                                                      // 34
    _id: "data",                                                                                                       // 34
    postCount: 0,                                                                                                      // 34
    appCount: 0,                                                                                                       // 34
    raidCount: 0                                                                                                       // 34
  });                                                                                                                  // 34
  firstTime = 0;                                                                                                       // 35
} //creates initial account                                                                                            // 36
                                                                                                                       //
                                                                                                                       //
Meteor.methods({                                                                                                       // 40
  'accountCheck': function () {                                                                                        // 41
    if (userCount.findOne({                                                                                            // 42
      count: 0                                                                                                         // 42
    })) {                                                                                                              // 42
      return true;                                                                                                     // 43
    } else {                                                                                                           // 44
      return false;                                                                                                    // 45
    }                                                                                                                  // 46
  },                                                                                                                   // 47
  'phraseCheck': function (secret) {                                                                                   // 48
    if (secret == "SnowyTableSanDiegoFifteenTwelve") {                                                                 // 49
      return true;                                                                                                     // 50
    }                                                                                                                  // 51
  },                                                                                                                   // 52
  'createAcc': function (usm, psw) {                                                                                   // 53
    if (userCount.findOne({                                                                                            // 54
      count: 0                                                                                                         // 54
    })) {                                                                                                              // 54
      Accounts.createUser({                                                                                            // 55
        username: usm,                                                                                                 // 56
        password: psw                                                                                                  // 57
      });                                                                                                              // 55
    }                                                                                                                  // 59
                                                                                                                       //
    userCount.insert({                                                                                                 // 60
      count: 1                                                                                                         // 60
    });                                                                                                                // 60
    userCount.remove({                                                                                                 // 61
      count: 0                                                                                                         // 61
    });                                                                                                                // 61
  }                                                                                                                    // 62
});                                                                                                                    // 40
Meteor.methods({                                                                                                       // 65
  'post': function (imageData, title, content, cata) {                                                                 // 66
    if (Meteor.user()) {                                                                                               // 67
      // our data URL string from canvas.toDataUrl();                                                                  // 68
      var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                       // 69
                                                                                                                       //
      var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp            // 71
                                                                                                                       //
      var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
      var imageBuffer = new Buffer(base64Data, "base64");                                                              // 75
      var id = ShortId.generate();                                                                                     // 76
      var isoDate = new Date();                                                                                        // 77
      var res = isoDate.toString().split(" ");                                                                         // 78
      var date = res[1] + " " + res[2] + " " + res[3];                                                                 // 79
      var path = process.env["PWD"] + '/.static~/';                                                                    // 80
      var cata = cata;                                                                                                 // 82
                                                                                                                       //
      if (cata.includes("News")) {                                                                                     // 83
        cata = "News";                                                                                                 // 84
      } else if (cata.includes("Boss")) {                                                                              // 85
        cata = "Boss";                                                                                                 // 86
      } else {                                                                                                         // 87
        //if no catagory is supplied, assume it's just news                                                            // 88
        cata = "News";                                                                                                 // 89
      }                                                                                                                // 90
                                                                                                                       //
      posts.insert({                                                                                                   // 91
        _id: id,                                                                                                       // 91
        title: title,                                                                                                  // 91
        content: content,                                                                                              // 91
        imgPath: '/files/' + id + ".jpeg",                                                                             // 91
        date: date,                                                                                                    // 91
        cataSux: cata,                                                                                                 // 91
        date_created: new Date()                                                                                       // 91
      });                                                                                                              // 91
      counts.update({                                                                                                  // 92
        _id: "data"                                                                                                    // 92
      }, {                                                                                                             // 92
        $inc: {                                                                                                        // 92
          postCount: 1                                                                                                 // 92
        }                                                                                                              // 92
      });                                                                                                              // 92
                                                                                                                       //
      if (cata == "Boss") {                                                                                            // 93
        images.insert({                                                                                                // 94
          _id: id,                                                                                                     // 94
          title: title,                                                                                                // 94
          imgPath: '/files/' + id + ".jpeg",                                                                           // 94
          date_created: new Date()                                                                                     // 94
        });                                                                                                            // 94
      }                                                                                                                // 95
                                                                                                                       //
      if (imageData == '') {                                                                                           // 96
        var rand = Math.floor(Math.random() * 3) + 1;                                                                  // 97
        var img = '';                                                                                                  // 98
                                                                                                                       //
        if (rand == 1) {                                                                                               // 99
          img = 'default1.jpg';                                                                                        // 100
        } else if (rand == 2) {                                                                                        // 101
          img = 'default2.jpg';                                                                                        // 102
        } else {                                                                                                       // 103
          img = 'default3.jpg';                                                                                        // 104
        }                                                                                                              // 105
                                                                                                                       //
        posts.update({                                                                                                 // 106
          _id: id                                                                                                      // 106
        }, {                                                                                                           // 106
          $set: {                                                                                                      // 106
            imgPath: '/' + img                                                                                         // 106
          }                                                                                                            // 106
        });                                                                                                            // 106
                                                                                                                       //
        if (cata == "Boss") {                                                                                          // 107
          images.update({                                                                                              // 108
            _id: id                                                                                                    // 108
          }, {                                                                                                         // 108
            $set: {                                                                                                    // 108
              imgPath: '/' + img                                                                                       // 108
            }                                                                                                          // 108
          });                                                                                                          // 108
        }                                                                                                              // 109
      }                                                                                                                // 110
                                                                                                                       //
      var canReload = false;                                                                                           // 111
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 112
        if (err) throw err;                                                                                            // 114
        console.log('Done!');                                                                                          // 115
        canReload = true;                                                                                              // 116
      });                                                                                                              // 117
                                                                                                                       //
      if (canReload == true) {                                                                                         // 118
        return true;                                                                                                   // 119
      }                                                                                                                // 120
    }                                                                                                                  // 121
  },                                                                                                                   // 122
  'addRaid': function (title, bossName, bossStatN, bossStatH, bossStatM, addCC) {                                      // 123
    if (Meteor.user()) {                                                                                               // 124
      //okay, I'm posting each boss and it's stats in an array. I need to break it up to show it, but I'm sure I can do that Client side.
      raids.insert({                                                                                                   // 126
        title: title,                                                                                                  // 126
        bossName: bossName,                                                                                            // 126
        bossStatN: bossStatN,                                                                                          // 126
        bossStatH: bossStatH,                                                                                          // 126
        bossStatM: bossStatM,                                                                                          // 126
        length: addCC,                                                                                                 // 126
        date: new Date()                                                                                               // 126
      });                                                                                                              // 126
      counts.update({                                                                                                  // 127
        _id: "data"                                                                                                    // 127
      }, {                                                                                                             // 127
        $inc: {                                                                                                        // 127
          raidCount: 1                                                                                                 // 127
        }                                                                                                              // 127
      });                                                                                                              // 127
    }                                                                                                                  // 128
  },                                                                                                                   // 129
  'addQues': function (ques, quesCount) {                                                                              // 130
    if (Meteor.user()) {                                                                                               // 131
      questions.remove({});                                                                                            // 132
      questions.insert({                                                                                               // 133
        ques: ques,                                                                                                    // 133
        quesCount: quesCount                                                                                           // 133
      });                                                                                                              // 133
    }                                                                                                                  // 134
  }                                                                                                                    // 135
});                                                                                                                    // 65
Meteor.methods({                                                                                                       // 138
  'updateSite': function (specStatus, title, about, tabard, background, favicon) {                                     // 139
    if (Meteor.user()) {                                                                                               // 140
      var spec = ['dnB', 'dnU', 'dnF', 'dhH', 'dhV', 'drB', 'drF', 'drR', 'drG', 'huM', 'huS', 'huB', 'maF', 'maFr', 'maA', 'moM', 'moW', 'moB', 'paH', 'paR', 'paP', 'prS', 'prD', 'prH', 'roA', 'roS', 'roC', 'shE', 'shR', 'shEn', 'waA', 'waD', 'waDe', 'warA', 'warF', 'warP'];
      var images = [];                                                                                                 // 142
      var canReload = [];                                                                                              // 143
                                                                                                                       //
      if (tabard != '') {                                                                                              // 144
        images.push('tabard');                                                                                         // 145
        canReload.push('0');                                                                                           // 146
      }                                                                                                                // 147
                                                                                                                       //
      if (background != '') {                                                                                          // 148
        images.push('background');                                                                                     // 149
        canReload.push('0');                                                                                           // 150
      }                                                                                                                // 151
                                                                                                                       //
      if (favicon != '') {                                                                                             // 152
        images.push('favicon');                                                                                        // 153
        canReload.push('0');                                                                                           // 154
      }                                                                                                                // 155
                                                                                                                       //
      var path = process.env["PWD"] + '/.static~/';                                                                    // 156
                                                                                                                       //
      for (var i = 0; i < images.length; i++) {                                                                        // 157
        console.log(images[i]); // our data URL string from canvas.toDataUrl();                                        // 158
                                                                                                                       //
        var imageDataUrl = eval(images[i]); // declare a regexp to match the non base64 first characters               // 160
                                                                                                                       //
        var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp          // 162
                                                                                                                       //
        var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
        var imageBuffer = new Buffer(base64Data, "base64");                                                            // 166
        var ext;                                                                                                       // 168
                                                                                                                       //
        if (images[i] != 'favicon') {                                                                                  // 170
          ext = '.png';                                                                                                // 171
        } else {                                                                                                       // 172
          ext = '.ico';                                                                                                // 173
        }                                                                                                              // 174
                                                                                                                       //
        fs.writeFile(path + images[i] + ext, imageBuffer, function (err) {                                             // 176
          if (err) throw err;                                                                                          // 178
          console.log('Done!');                                                                                        // 179
          canReload[i] = 1;                                                                                            // 180
        });                                                                                                            // 181
        siteDetails.update({                                                                                           // 182
          _id: images[i]                                                                                               // 182
        }, {                                                                                                           // 182
          $set: {                                                                                                      // 182
            path: '/files/' + images[i] + ext                                                                          // 182
          }                                                                                                            // 182
        });                                                                                                            // 182
      }                                                                                                                // 183
                                                                                                                       //
      var reloadLength = canReload.length;                                                                             // 185
                                                                                                                       //
      if (reloadLength == null) {                                                                                      // 186
        return true;                                                                                                   // 187
      } else if (reloadLength == 0 && canReload[0] == 1) {                                                             // 188
        return true;                                                                                                   // 189
      } else if (reloadLength == 1 && canReload[0] == 1 && canReload[1] == 1) {                                        // 190
        return true;                                                                                                   // 191
      }                                                                                                                // 192
                                                                                                                       //
      siteDetails.update({                                                                                             // 194
        _id: 'recruiting'                                                                                              // 194
      }, {                                                                                                             // 194
        $set: {                                                                                                        // 194
          dnB: specStatus[0],                                                                                          // 194
          dnU: specStatus[1],                                                                                          // 194
          dnF: specStatus[2],                                                                                          // 194
          dhH: specStatus[3],                                                                                          // 194
          dhV: specStatus[4],                                                                                          // 194
          drB: specStatus[5],                                                                                          // 194
          drF: specStatus[6],                                                                                          // 194
          drR: specStatus[7],                                                                                          // 194
          drG: specStatus[8],                                                                                          // 194
          huM: specStatus[9],                                                                                          // 194
          huS: specStatus[10],                                                                                         // 194
          huB: specStatus[11],                                                                                         // 194
          maF: specStatus[12],                                                                                         // 194
          maFr: specStatus[13],                                                                                        // 194
          maA: specStatus[14],                                                                                         // 194
          moM: specStatus[15],                                                                                         // 194
          moW: specStatus[16],                                                                                         // 194
          moB: specStatus[17],                                                                                         // 194
          paH: specStatus[18],                                                                                         // 194
          paR: specStatus[19],                                                                                         // 194
          paP: specStatus[20],                                                                                         // 194
          prS: specStatus[21],                                                                                         // 194
          prD: specStatus[22],                                                                                         // 194
          prH: specStatus[23],                                                                                         // 194
          roA: specStatus[24],                                                                                         // 194
          roS: specStatus[25],                                                                                         // 194
          roC: specStatus[26],                                                                                         // 194
          shE: specStatus[27],                                                                                         // 194
          shR: specStatus[28],                                                                                         // 194
          shEn: specStatus[29],                                                                                        // 194
          waA: specStatus[30],                                                                                         // 194
          waD: specStatus[31],                                                                                         // 194
          waDe: specStatus[32],                                                                                        // 194
          warA: specStatus[33],                                                                                        // 194
          warF: specStatus[34],                                                                                        // 194
          warP: specStatus[35]                                                                                         // 194
        }                                                                                                              // 194
      });                                                                                                              // 194
                                                                                                                       //
      if (title != "" && title != undefined && title != null) {                                                        // 196
        siteDetails.update({                                                                                           // 197
          _id: 'title'                                                                                                 // 197
        }, {                                                                                                           // 197
          $set: {                                                                                                      // 197
            title: title                                                                                               // 197
          }                                                                                                            // 197
        });                                                                                                            // 197
      }                                                                                                                // 198
                                                                                                                       //
      if (about != "" && about != undefined && about != null) {                                                        // 199
        siteDetails.update({                                                                                           // 200
          _id: 'about'                                                                                                 // 200
        }, {                                                                                                           // 200
          $set: {                                                                                                      // 200
            about: about                                                                                               // 200
          }                                                                                                            // 200
        });                                                                                                            // 200
      }                                                                                                                // 201
    }                                                                                                                  // 202
  },                                                                                                                   // 203
  'updateRaid': function (title, bossName, bossStatN, bossStatH, bossStatM, addCE, target) {                           // 204
    if (Meteor.user()) {                                                                                               // 205
      if (addCE < 0) {                                                                                                 // 206
        addCE = 0;                                                                                                     // 207
      }                                                                                                                // 208
                                                                                                                       //
      raids.update({                                                                                                   // 209
        _id: target                                                                                                    // 209
      }, {                                                                                                             // 209
        $set: {                                                                                                        // 209
          title: title,                                                                                                // 209
          bossName: bossName,                                                                                          // 209
          bossStatN: bossStatN,                                                                                        // 209
          bossStatH: bossStatH,                                                                                        // 209
          bossStatM: bossStatM,                                                                                        // 209
          length: addCE                                                                                                // 209
        }                                                                                                              // 209
      });                                                                                                              // 209
    }                                                                                                                  // 210
  },                                                                                                                   // 211
  'updatePost': function (title, content, id, imageData, cata) {                                                       // 212
    if (Meteor.user()) {                                                                                               // 213
      // our data URL string from canvas.toDataUrl();                                                                  // 214
      if (imageData != '') {                                                                                           // 215
        var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                     // 216
                                                                                                                       //
        var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp          // 218
                                                                                                                       //
        var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
        var imageBuffer = new Buffer(base64Data, "base64");                                                            // 222
        var path = process.env["PWD"] + '/.static~/';                                                                  // 223
        posts.update({                                                                                                 // 224
          _id: id                                                                                                      // 224
        }, {                                                                                                           // 224
          $set: {                                                                                                      // 224
            imgPath: '/files/' + id + ".jpeg"                                                                          // 224
          }                                                                                                            // 224
        }); //if we find an image with our ID                                                                          // 224
                                                                                                                       //
        if (images.findOne({                                                                                           // 226
          _id: id                                                                                                      // 226
        })) {                                                                                                          // 226
          //update it                                                                                                  // 227
          images.update({                                                                                              // 228
            _id: id                                                                                                    // 228
          }, {                                                                                                         // 228
            $set: {                                                                                                    // 228
              imgPath: '/files/' + id + ".jpeg"                                                                        // 228
            }                                                                                                          // 228
          });                                                                                                          // 228
        }                                                                                                              // 229
      }                                                                                                                // 230
                                                                                                                       //
      if (cata == 'Boss Fight') {                                                                                      // 231
        cata = "Boss";                                                                                                 // 232
      }                                                                                                                // 233
                                                                                                                       //
      if (cata == "News") {                                                                                            // 234
        images.remove({                                                                                                // 235
          _id: id                                                                                                      // 235
        });                                                                                                            // 235
      } else if (cata == "Boss") {                                                                                     // 236
        var thisDate = posts.findOne({                                                                                 // 237
          _id: id                                                                                                      // 237
        }).date_created;                                                                                               // 237
                                                                                                                       //
        if (images.findOne({                                                                                           // 238
          _id: id                                                                                                      // 238
        })) {//do something                                                                                            // 238
        } else {                                                                                                       // 240
          var imagePath = posts.findOne({                                                                              // 241
            _id: id                                                                                                    // 241
          }).imgPath;                                                                                                  // 241
          images.insert({                                                                                              // 242
            _id: id,                                                                                                   // 242
            date_created: thisDate,                                                                                    // 242
            imgPath: imagePath                                                                                         // 242
          });                                                                                                          // 242
        }                                                                                                              // 243
      }                                                                                                                // 244
                                                                                                                       //
      console.log(cata);                                                                                               // 245
                                                                                                                       //
      if (cata != null) {                                                                                              // 246
        posts.update({                                                                                                 // 247
          _id: id                                                                                                      // 247
        }, {                                                                                                           // 247
          $set: {                                                                                                      // 247
            title: title,                                                                                              // 247
            content: content,                                                                                          // 247
            cataSux: cata                                                                                              // 247
          }                                                                                                            // 247
        });                                                                                                            // 247
      } else {                                                                                                         // 248
        posts.update({                                                                                                 // 249
          _id: id                                                                                                      // 249
        }, {                                                                                                           // 249
          $set: {                                                                                                      // 249
            title: title,                                                                                              // 249
            content: content                                                                                           // 249
          }                                                                                                            // 249
        });                                                                                                            // 249
      }                                                                                                                // 250
                                                                                                                       //
      var canReload = false;                                                                                           // 251
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 252
        if (err) throw err;                                                                                            // 254
        console.log('Done!');                                                                                          // 255
        canReload = true;                                                                                              // 256
      });                                                                                                              // 257
                                                                                                                       //
      if (canReload == true) {                                                                                         // 258
        return true;                                                                                                   // 259
      }                                                                                                                // 260
    }                                                                                                                  // 261
  },                                                                                                                   // 262
  'updateTwitch': function (apiKey, names, counts) {                                                                   // 263
    if (Meteor.user()) {                                                                                               // 264
      if (counts < 0) {                                                                                                // 265
        counts = 0;                                                                                                    // 266
      }                                                                                                                // 267
                                                                                                                       //
      if (twitch.findOne({                                                                                             // 268
        _id: 'data'                                                                                                    // 268
      })) {                                                                                                            // 268
        twitch.update({                                                                                                // 269
          _id: 'data'                                                                                                  // 269
        }, {                                                                                                           // 269
          $set: {                                                                                                      // 269
            apiKey: apiKey,                                                                                            // 269
            names: names,                                                                                              // 269
            counts: counts                                                                                             // 269
          }                                                                                                            // 269
        });                                                                                                            // 269
        console.log('updating');                                                                                       // 270
      } else {                                                                                                         // 271
        twitch.insert({                                                                                                // 272
          _id: "data",                                                                                                 // 272
          apiKey: apiKey,                                                                                              // 272
          names: names,                                                                                                // 272
          counts: counts                                                                                               // 272
        });                                                                                                            // 272
        console.log('inserting');                                                                                      // 273
      }                                                                                                                // 274
    }                                                                                                                  // 275
  }                                                                                                                    // 276
});                                                                                                                    // 138
Meteor.methods({                                                                                                       // 279
  'sendApp': function (questions, resps, amt) {                                                                        // 280
    var isoDate = new Date();                                                                                          // 281
    var res = isoDate.toString().split(" ");                                                                           // 282
    var date = res[1] + " " + res[2] + " " + res[3];                                                                   // 283
    apps.insert({                                                                                                      // 284
      username: resps[0].replace("::", ""),                                                                            // 284
      questions: questions,                                                                                            // 284
      resps: resps,                                                                                                    // 284
      amt: amt,                                                                                                        // 284
      date: date,                                                                                                      // 284
      date_created: new Date(),                                                                                        // 284
      cataSux: 'Unviewed'                                                                                              // 284
    });                                                                                                                // 284
    counts.update({                                                                                                    // 285
      _id: "data"                                                                                                      // 285
    }, {                                                                                                               // 285
      $inc: {                                                                                                          // 285
        appCount: 1                                                                                                    // 285
      }                                                                                                                // 285
    });                                                                                                                // 285
    return 'success';                                                                                                  // 286
  },                                                                                                                   // 287
  'updateApp': function (id, cata) {                                                                                   // 288
    apps.update({                                                                                                      // 289
      _id: id                                                                                                          // 289
    }, {                                                                                                               // 289
      $set: {                                                                                                          // 289
        cataSux: cata                                                                                                  // 289
      }                                                                                                                // 289
    });                                                                                                                // 289
    return "done";                                                                                                     // 290
  }                                                                                                                    // 291
});                                                                                                                    // 279
Meteor.methods({                                                                                                       // 294
  'deletePost': function (post) {                                                                                      // 295
    if (Meteor.user()) {                                                                                               // 296
      var filePath = process.env["PWD"] + '/.static~/' + post + '.jpeg';                                               // 297
      fs.unlinkSync(filePath);                                                                                         // 298
      posts.remove({                                                                                                   // 299
        _id: post                                                                                                      // 299
      });                                                                                                              // 299
      images.remove({                                                                                                  // 300
        _id: post                                                                                                      // 300
      });                                                                                                              // 300
      counts.update({                                                                                                  // 301
        _id: "data"                                                                                                    // 301
      }, {                                                                                                             // 301
        $inc: {                                                                                                        // 301
          postCount: -1                                                                                                // 301
        }                                                                                                              // 301
      });                                                                                                              // 301
    }                                                                                                                  // 302
  },                                                                                                                   // 303
  'deleteApp': function (appId) {                                                                                      // 304
    if (Meteor.user()) {                                                                                               // 305
      apps.remove({                                                                                                    // 306
        _id: appId                                                                                                     // 306
      });                                                                                                              // 306
      counts.update({                                                                                                  // 307
        _id: "data"                                                                                                    // 307
      }, {                                                                                                             // 307
        $inc: {                                                                                                        // 307
          appCount: -1                                                                                                 // 307
        }                                                                                                              // 307
      });                                                                                                              // 307
    }                                                                                                                  // 308
  },                                                                                                                   // 309
  'deleteRaid': function (raidId) {                                                                                    // 310
    if (Meteor.user()) {                                                                                               // 311
      raids.remove({                                                                                                   // 312
        _id: raidId                                                                                                    // 312
      });                                                                                                              // 312
      counts.update({                                                                                                  // 313
        _id: "data"                                                                                                    // 313
      }, {                                                                                                             // 313
        $inc: {                                                                                                        // 313
          raidCount: -1                                                                                                // 313
        }                                                                                                              // 313
      });                                                                                                              // 313
    }                                                                                                                  // 314
  }                                                                                                                    // 315
}); // Makes you SEO friendly baby                                                                                     // 294
                                                                                                                       //
WebApp.rawConnectHandlers.use(Meteor.bindEnvironment(function (req, res, next) {                                       // 319
  var title = siteDetails.findOne({                                                                                    // 321
    _id: 'title'                                                                                                       // 321
  }).title;                                                                                                            // 321
  var about = siteDetails.findOne({                                                                                    // 322
    _id: 'about'                                                                                                       // 322
  }).about;                                                                                                            // 322
  var tabard = siteDetails.findOne({                                                                                   // 323
    _id: 'tabard'                                                                                                      // 323
  }).path;                                                                                                             // 323
                                                                                                                       //
  if (title == undefined || title == null || title == '') {                                                            // 324
    req.dynamicHead = (req.dynamicHead || "") + '<title>OpenGuild-CMS | FinchMFG</title>';                             // 325
  } else {                                                                                                             // 326
    req.dynamicHead = (req.dynamicHead || "") + '<title>' + title + '</title>';                                        // 327
  }                                                                                                                    // 328
                                                                                                                       //
  if (about == undefined || about == null || about == '') {                                                            // 330
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="description" content="Awesome open source Wow Raid software by FinchMFG" />';
  } else {                                                                                                             // 332
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="description" content="' + about + '"/>';                  // 333
  }                                                                                                                    // 334
                                                                                                                       //
  if (tabard == undefined || tabard == null || tabard == '') {                                                         // 336
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="tabard" content="blessed" />';                            // 337
  } else {                                                                                                             // 338
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="tabard" content="' + tabard + '" />';                     // 339
  }                                                                                                                    // 340
                                                                                                                       //
  next();                                                                                                              // 341
})); //Meteor SEO SSR for BOTS mang                                                                                    // 342
                                                                                                                       //
var SeoRouter = Picker.filter(function (request, response) {                                                           // 346
  var botAgents = [/^facebookexternalhit/i, // Facebook                                                                // 347
  /^linkedinbot/i, // LinkedIn                                                                                         // 349
  /^twitterbot/i, // Twitter                                                                                           // 350
  /^slackbot-linkexpanding/i, // Slack                                                                                 // 351
  /^googlebot/i];                                                                                                      // 352
  return (/_escaped_fragment_/.test(request.url) || botAgents.some(function (i) {                                      // 355
      return i.test(request.headers['user-agent']);                                                                    // 355
    })                                                                                                                 // 355
  );                                                                                                                   // 355
});                                                                                                                    // 356
SeoRouter.route('/', function (params, request, response) {                                                            // 358
  SSR.compileTemplate('index', Assets.getText('index.html'));                                                          // 359
  Template.index.helpers({                                                                                             // 360
    getDocType: function () {                                                                                          // 361
      return "<!DOCTYPE html>";                                                                                        // 362
    },                                                                                                                 // 363
    title: function () {                                                                                               // 364
      return siteDetails.findOne({                                                                                     // 365
        _id: "title"                                                                                                   // 365
      }).title;                                                                                                        // 365
    },                                                                                                                 // 366
    meta: function () {                                                                                                // 367
      return siteDetails.findOne({                                                                                     // 368
        _id: "about"                                                                                                   // 368
      }).about;                                                                                                        // 368
    },                                                                                                                 // 369
    tabard: function () {                                                                                              // 370
      try {                                                                                                            // 371
        return siteDetails.findOne({                                                                                   // 372
          _id: "tabard"                                                                                                // 372
        }).path;                                                                                                       // 372
      } catch (e) {                                                                                                    // 373
        return;                                                                                                        // 374
      }                                                                                                                // 375
    }                                                                                                                  // 376
  });                                                                                                                  // 360
  var html = SSR.render('index');                                                                                      // 379
  response.setHeader('Content-Type', 'text/html;charset=utf-8');                                                       // 381
  response.end(html);                                                                                                  // 382
}); //END                                                                                                              // 383
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/db.js");
require("./lib/globals.js");
require("./lib/routes.js");
require("./server/fileserver.js");
require("./server/publish.js");
require("./server/server.js");
//# sourceMappingURL=app.js.map
