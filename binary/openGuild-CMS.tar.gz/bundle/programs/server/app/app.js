var require = meteorInstall({"lib":{"db.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/db.js                                                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
posts = new Mongo.Collection('posts');                                                                               // 1
raids = new Mongo.Collection('raids');                                                                               // 2
questions = new Mongo.Collection('questions');                                                                       // 3
apps = new Mongo.Collection('apps');                                                                                 // 4
userCount = new Mongo.Collection('userCount');                                                                       // 5
siteDetails = new Mongo.Collection('siteDetails');                                                                   // 6
counts = new Mongo.Collection('counts'); //denys anyone access to these (unless the above allow is met)              // 8
                                                                                                                     //
posts.deny({                                                                                                         // 11
  update: function () {                                                                                              // 12
    return true;                                                                                                     // 13
  },                                                                                                                 // 14
  insert: function () {                                                                                              // 16
    return true;                                                                                                     // 17
  }                                                                                                                  // 18
});                                                                                                                  // 11
apps.deny({                                                                                                          // 21
  update: function () {                                                                                              // 22
    return true;                                                                                                     // 23
  },                                                                                                                 // 24
  insert: function () {                                                                                              // 26
    return true;                                                                                                     // 27
  }                                                                                                                  // 28
});                                                                                                                  // 21
questions.deny({                                                                                                     // 31
  update: function () {                                                                                              // 32
    return true;                                                                                                     // 33
  },                                                                                                                 // 34
  insert: function () {                                                                                              // 36
    return true;                                                                                                     // 37
  }                                                                                                                  // 38
});                                                                                                                  // 31
raids.deny({                                                                                                         // 41
  update: function () {                                                                                              // 42
    return true;                                                                                                     // 43
  },                                                                                                                 // 44
  insert: function () {                                                                                              // 46
    return true;                                                                                                     // 47
  }                                                                                                                  // 48
});                                                                                                                  // 41
Meteor.users.deny({                                                                                                  // 51
  update: function () {                                                                                              // 52
    return true;                                                                                                     // 53
  }                                                                                                                  // 54
});                                                                                                                  // 51
userCount.deny({                                                                                                     // 57
  update: function () {                                                                                              // 58
    return true;                                                                                                     // 59
  },                                                                                                                 // 60
  insert: function () {                                                                                              // 62
    return true;                                                                                                     // 63
  }                                                                                                                  // 64
});                                                                                                                  // 57
siteDetails.deny({                                                                                                   // 67
  update: function () {                                                                                              // 68
    return true;                                                                                                     // 69
  },                                                                                                                 // 70
  insert: function () {                                                                                              // 72
    return true;                                                                                                     // 73
  }                                                                                                                  // 74
});                                                                                                                  // 67
counts.deny({                                                                                                        // 78
  update: function () {                                                                                              // 79
    return true;                                                                                                     // 80
  },                                                                                                                 // 81
  insert: function () {                                                                                              // 83
    return true;                                                                                                     // 84
  }                                                                                                                  // 85
});                                                                                                                  // 78
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"globals.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/globals.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
//defaults to feed (home)                                                                                            // 1
currentPage = new ReactiveVar("feed"); //gets currentPost                                                            // 2
                                                                                                                     //
currentPost = new ReactiveVar(); //admin page location                                                               // 5
                                                                                                                     //
adminLoc = new ReactiveVar("dash"); //the news filter                                                                // 8
                                                                                                                     //
newsFilter = new ReactiveVar('news');                                                                                // 11
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/routes.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
FlowRouter.route('/', {                                                                                              // 1
  name: 'home',                                                                                                      // 2
  subscriptions: function (params, queryParams) {                                                                    // 3
    // using Fast Render                                                                                             // 4
    this.register('posts', Meteor.subscribe('posts'));                                                               // 5
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                   // 6
  },                                                                                                                 // 7
  action: function () {                                                                                              // 8
    BlazeLayout.render('index');                                                                                     // 9
  },                                                                                                                 // 10
  fastRender: true                                                                                                   // 11
});                                                                                                                  // 1
FlowRouter.route('/admin', {                                                                                         // 14
  name: "admin",                                                                                                     // 15
  action: function () {                                                                                              // 16
    BlazeLayout.render('admin');                                                                                     // 17
  }                                                                                                                  // 18
});                                                                                                                  // 14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fileserver.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/fileserver.js                                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var fs = Npm.require('fs');                                                                                          // 1
                                                                                                                     //
WebApp.connectHandlers.use(function (req, res, next) {                                                               // 2
    var re = /^\/files\/(.*)$/.exec(req.url);                                                                        // 3
                                                                                                                     //
    if (re !== null) {                                                                                               // 4
        // Only handle URLs that start with /uploads_url_prefix/*                                                    // 4
        var filePath = process.env.PWD + '/.static~/' + re[1];                                                       // 5
        var data = fs.readFileSync(filePath);                                                                        // 6
        res.writeHead(200, {                                                                                         // 7
            'Content-Type': 'image'                                                                                  // 8
        });                                                                                                          // 7
        res.write(data);                                                                                             // 10
        res.end();                                                                                                   // 11
    } else {                                                                                                         // 12
        // Other urls will have default behaviors                                                                    // 12
        next();                                                                                                      // 13
    }                                                                                                                // 14
});                                                                                                                  // 15
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publish.js                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.publish("posts", function () {                                                                                // 1
  //send data newest first to the client                                                                             // 2
  return posts.find({}, {                                                                                            // 3
    sort: {                                                                                                          // 3
      date_created: -1                                                                                               // 3
    }                                                                                                                // 3
  });                                                                                                                // 3
});                                                                                                                  // 4
Meteor.publish("raids", function () {                                                                                // 6
  return raids.find({});                                                                                             // 7
});                                                                                                                  // 8
Meteor.publish("questions", function () {                                                                            // 10
  return questions.find({});                                                                                         // 11
});                                                                                                                  // 12
Meteor.publish("siteDetails", function () {                                                                          // 14
  return siteDetails.find({});                                                                                       // 15
});                                                                                                                  // 16
Meteor.publish("counts", function () {                                                                               // 18
  return counts.find({});                                                                                            // 19
});                                                                                                                  // 20
Meteor.publish("apps", function () {                                                                                 // 22
  return apps.find({});                                                                                              // 23
});                                                                                                                  // 24
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/server.js                                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.startup(function () {                                                                                         // 1
  fs = Npm.require('fs');                                                                                            // 2
}); //checks to see if default site values are set, creates template for later                                       // 3
                                                                                                                     //
var needed = ['title', 'about', 'tabard', 'background', 'favicon', 'recruiting'];                                    // 7
var firstTime = 0;                                                                                                   // 8
                                                                                                                     //
for (var i = 0; i < needed.length; i++) {                                                                            // 9
  if (siteDetails.findOne({                                                                                          // 10
    _id: needed[i]                                                                                                   // 10
  })) {//horray!!                                                                                                    // 10
  } else {                                                                                                           // 12
    //lets create em                                                                                                 // 13
    siteDetails.insert({                                                                                             // 14
      _id: needed[i]                                                                                                 // 14
    });                                                                                                              // 14
    firstTime = 1;                                                                                                   // 15
  }                                                                                                                  // 16
}                                                                                                                    // 17
                                                                                                                     //
if (firstTime == 1) {                                                                                                // 18
  //wow                                                                                                              // 19
  siteDetails.update({                                                                                               // 20
    _id: 'recruiting'                                                                                                // 20
  }, {                                                                                                               // 20
    $set: {                                                                                                          // 20
      dnB: 'checked',                                                                                                // 20
      dnU: 'checked',                                                                                                // 20
      dnF: 'checked',                                                                                                // 20
      dhH: 'checked',                                                                                                // 20
      dhV: 'checked',                                                                                                // 20
      drB: 'checked',                                                                                                // 20
      drF: 'checked',                                                                                                // 20
      drR: 'checked',                                                                                                // 20
      drG: 'checked',                                                                                                // 20
      huM: 'checked',                                                                                                // 20
      huS: 'checked',                                                                                                // 20
      huB: 'checked',                                                                                                // 20
      maF: 'checked',                                                                                                // 20
      maFr: 'checked',                                                                                               // 20
      maA: 'checked',                                                                                                // 20
      moM: 'checked',                                                                                                // 20
      moW: 'checked',                                                                                                // 20
      moB: 'checked',                                                                                                // 20
      paH: 'checked',                                                                                                // 20
      paR: 'checked',                                                                                                // 20
      paP: 'checked',                                                                                                // 20
      prS: 'checked',                                                                                                // 20
      prD: 'checked',                                                                                                // 20
      prH: 'checked',                                                                                                // 20
      roA: 'checked',                                                                                                // 20
      roS: 'checked',                                                                                                // 20
      roC: 'checked',                                                                                                // 20
      shE: 'checked',                                                                                                // 20
      shR: 'checked',                                                                                                // 20
      shEn: 'checked',                                                                                               // 20
      waA: 'checked',                                                                                                // 20
      waD: 'checked',                                                                                                // 20
      waDe: 'checked',                                                                                               // 20
      warA: 'checked',                                                                                               // 20
      warF: 'checked',                                                                                               // 20
      warP: 'checked'                                                                                                // 20
    }                                                                                                                // 20
  });                                                                                                                // 20
  console.log('hi');                                                                                                 // 21
  firstTime = 0;                                                                                                     // 22
  counts.insert({                                                                                                    // 23
    _id: "data",                                                                                                     // 23
    postCount: 0,                                                                                                    // 23
    appCount: 0,                                                                                                     // 23
    raidCount: 0                                                                                                     // 23
  });                                                                                                                // 23
} //creates initial account                                                                                          // 24
                                                                                                                     //
                                                                                                                     //
Meteor.methods({                                                                                                     // 28
  'accountCheck': function () {                                                                                      // 29
    if (userCount.findOne({                                                                                          // 30
      count: 0                                                                                                       // 30
    })) {                                                                                                            // 30
      return true;                                                                                                   // 31
    } else {                                                                                                         // 32
      return false;                                                                                                  // 33
    }                                                                                                                // 34
  },                                                                                                                 // 35
  'phraseCheck': function (secret) {                                                                                 // 36
    if (secret == "SnowyTableSanDiegoFifteenTwelve") {                                                               // 37
      return true;                                                                                                   // 38
    }                                                                                                                // 39
  },                                                                                                                 // 40
  'createAcc': function (usm, psw) {                                                                                 // 41
    Accounts.createUser({                                                                                            // 42
      username: usm,                                                                                                 // 43
      password: psw                                                                                                  // 44
    });                                                                                                              // 42
    userCount.insert({                                                                                               // 46
      count: 1                                                                                                       // 46
    });                                                                                                              // 46
    userCount.remove({                                                                                               // 47
      count: 0                                                                                                       // 47
    });                                                                                                              // 47
  }                                                                                                                  // 48
});                                                                                                                  // 28
Meteor.methods({                                                                                                     // 51
  'post': function (imageData, title, content, cata) {                                                               // 52
    // our data URL string from canvas.toDataUrl();                                                                  // 53
    var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                       // 54
                                                                                                                     //
    var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp            // 56
                                                                                                                     //
    var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                     //
    var imageBuffer = new Buffer(base64Data, "base64");                                                              // 60
    var id = ShortId.generate();                                                                                     // 61
    var isoDate = new Date();                                                                                        // 62
    var res = isoDate.toString().split(" ");                                                                         // 63
    var date = res[1] + " " + res[2] + " " + res[3];                                                                 // 64
    var path = process.env["PWD"] + '/.static~/';                                                                    // 65
    var cata = cata;                                                                                                 // 67
                                                                                                                     //
    if (cata.includes("News")) {                                                                                     // 68
      cata = "News";                                                                                                 // 69
    } else if (cata.includes("Boss")) {                                                                              // 70
      cata = "Boss";                                                                                                 // 71
    } else {                                                                                                         // 72
      //if no catagory is supplied, assume it's just news                                                            // 73
      cata = "News";                                                                                                 // 74
    }                                                                                                                // 75
                                                                                                                     //
    posts.insert({                                                                                                   // 76
      _id: id,                                                                                                       // 76
      title: title,                                                                                                  // 76
      content: content,                                                                                              // 76
      imgPath: '/files/' + id + ".jpeg",                                                                             // 76
      date: date,                                                                                                    // 76
      cataSux: cata,                                                                                                 // 76
      date_created: new Date()                                                                                       // 76
    });                                                                                                              // 76
    counts.update({                                                                                                  // 77
      _id: "data"                                                                                                    // 77
    }, {                                                                                                             // 77
      $inc: {                                                                                                        // 77
        postCount: 1                                                                                                 // 77
      }                                                                                                              // 77
    });                                                                                                              // 77
    fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 78
      if (err) throw err;                                                                                            // 80
      console.log('Done!');                                                                                          // 81
    });                                                                                                              // 82
  },                                                                                                                 // 83
  'addRaid': function (title, normS, heroS, mythS, bossName, bossStatN, bossStatH, bossStatM, addCC) {               // 84
    //okay, I'm posting each boss and it's stats in an array. I need to break it up to show it, but I'm sure I can do that Client side.
    raids.insert({                                                                                                   // 86
      title: title,                                                                                                  // 86
      normS: normS,                                                                                                  // 86
      heroS: heroS,                                                                                                  // 86
      mythS: mythS,                                                                                                  // 86
      bossName: bossName,                                                                                            // 86
      bossStatN: bossStatN,                                                                                          // 86
      bossStatH: bossStatH,                                                                                          // 86
      bossStatM: bossStatM,                                                                                          // 86
      length: addCC                                                                                                  // 86
    });                                                                                                              // 86
    counts.update({                                                                                                  // 87
      _id: "data"                                                                                                    // 87
    }, {                                                                                                             // 87
      $inc: {                                                                                                        // 87
        raidCount: 1                                                                                                 // 87
      }                                                                                                              // 87
    });                                                                                                              // 87
  },                                                                                                                 // 88
  'addQues': function (ques, quesCount) {                                                                            // 89
    questions.remove({});                                                                                            // 90
    questions.insert({                                                                                               // 91
      ques: ques,                                                                                                    // 91
      quesCount: quesCount                                                                                           // 91
    });                                                                                                              // 91
  }                                                                                                                  // 92
});                                                                                                                  // 51
Meteor.methods({                                                                                                     // 95
  'updateSite': function (specStatus, title, about) {                                                                // 96
    var spec = ['dnB', 'dnU', 'dnF', 'dhH', 'dhV', 'drB', 'drF', 'drR', 'drG', 'huM', 'huS', 'huB', 'maF', 'maFr', 'maA', 'moM', 'moW', 'moB', 'paH', 'paR', 'paP', 'prS', 'prD', 'prH', 'roA', 'roS', 'roC', 'shE', 'shR', 'shEn', 'waA', 'waD', 'waDe', 'warA', 'warF', 'warP']; //for loop wont work, as I can only assign the value and not the property
                                                                                                                     //
    siteDetails.update({                                                                                             // 100
      _id: 'recruiting'                                                                                              // 100
    }, {                                                                                                             // 100
      $set: {                                                                                                        // 100
        dnB: specStatus[0],                                                                                          // 100
        dnU: specStatus[1],                                                                                          // 100
        dnF: specStatus[2],                                                                                          // 100
        dhH: specStatus[3],                                                                                          // 100
        dhV: specStatus[4],                                                                                          // 100
        drB: specStatus[5],                                                                                          // 100
        drF: specStatus[6],                                                                                          // 100
        drR: specStatus[7],                                                                                          // 100
        drG: specStatus[8],                                                                                          // 100
        huM: specStatus[9],                                                                                          // 100
        huS: specStatus[10],                                                                                         // 100
        huB: specStatus[11],                                                                                         // 100
        maF: specStatus[12],                                                                                         // 100
        maFr: specStatus[13],                                                                                        // 100
        maA: specStatus[14],                                                                                         // 100
        moM: specStatus[15],                                                                                         // 100
        moW: specStatus[16],                                                                                         // 100
        moB: specStatus[17],                                                                                         // 100
        paH: specStatus[18],                                                                                         // 100
        paR: specStatus[19],                                                                                         // 100
        paP: specStatus[20],                                                                                         // 100
        prS: specStatus[21],                                                                                         // 100
        prD: specStatus[22],                                                                                         // 100
        prH: specStatus[23],                                                                                         // 100
        roA: specStatus[24],                                                                                         // 100
        roS: specStatus[25],                                                                                         // 100
        roC: specStatus[26],                                                                                         // 100
        shE: specStatus[27],                                                                                         // 100
        shR: specStatus[28],                                                                                         // 100
        shEn: specStatus[29],                                                                                        // 100
        waA: specStatus[30],                                                                                         // 100
        waD: specStatus[31],                                                                                         // 100
        waDe: specStatus[32],                                                                                        // 100
        warA: specStatus[33],                                                                                        // 100
        warF: specStatus[34],                                                                                        // 100
        warP: specStatus[35]                                                                                         // 100
      }                                                                                                              // 100
    });                                                                                                              // 100
                                                                                                                     //
    if (title != "" && title != undefined && title != null) {                                                        // 103
      siteDetails.update({                                                                                           // 104
        _id: 'title'                                                                                                 // 104
      }, {                                                                                                           // 104
        $set: {                                                                                                      // 104
          title: title                                                                                               // 104
        }                                                                                                            // 104
      });                                                                                                            // 104
    }                                                                                                                // 105
                                                                                                                     //
    if (about != "" && about != undefined && about != null) {                                                        // 106
      siteDetails.update({                                                                                           // 107
        _id: 'about'                                                                                                 // 107
      }, {                                                                                                           // 107
        $set: {                                                                                                      // 107
          about: about                                                                                               // 107
        }                                                                                                            // 107
      });                                                                                                            // 107
    }                                                                                                                // 108
  }                                                                                                                  // 109
});                                                                                                                  // 95
Meteor.methods({                                                                                                     // 112
  'sendApp': function (questions, resps, amt) {                                                                      // 113
    apps.insert({                                                                                                    // 114
      username: resps[0],                                                                                            // 114
      questions: questions,                                                                                          // 114
      resps: resps,                                                                                                  // 114
      amt: amt                                                                                                       // 114
    });                                                                                                              // 114
    counts.update({                                                                                                  // 115
      _id: "data"                                                                                                    // 115
    }, {                                                                                                             // 115
      $inc: {                                                                                                        // 115
        appCount: 1                                                                                                  // 115
      }                                                                                                              // 115
    });                                                                                                              // 115
  }                                                                                                                  // 116
});                                                                                                                  // 112
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/db.js");
require("./lib/globals.js");
require("./lib/routes.js");
require("./server/fileserver.js");
require("./server/publish.js");
require("./server/server.js");
//# sourceMappingURL=app.js.map
