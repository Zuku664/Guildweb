var require = meteorInstall({"lib":{"db.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/db.js                                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
posts = new Mongo.Collection('posts');                                                                                 // 1
raids = new Mongo.Collection('raids');                                                                                 // 2
questions = new Mongo.Collection('questions');                                                                         // 3
apps = new Mongo.Collection('apps');                                                                                   // 4
userCount = new Mongo.Collection('userCount');                                                                         // 5
siteDetails = new Mongo.Collection('siteDetails');                                                                     // 6
counts = new Mongo.Collection('counts');                                                                               // 8
images = new Mongo.Collection('images'); //denys anyone access to these (unless the above allow is met)                // 10
                                                                                                                       //
posts.deny({                                                                                                           // 13
  update: function () {                                                                                                // 14
    return true;                                                                                                       // 15
  },                                                                                                                   // 16
  insert: function () {                                                                                                // 18
    return true;                                                                                                       // 19
  }                                                                                                                    // 20
});                                                                                                                    // 13
images.deny({                                                                                                          // 23
  update: function () {                                                                                                // 24
    return true;                                                                                                       // 25
  },                                                                                                                   // 26
  insert: function () {                                                                                                // 28
    return true;                                                                                                       // 29
  }                                                                                                                    // 30
});                                                                                                                    // 23
apps.deny({                                                                                                            // 33
  update: function () {                                                                                                // 34
    return true;                                                                                                       // 35
  },                                                                                                                   // 36
  insert: function () {                                                                                                // 38
    return true;                                                                                                       // 39
  }                                                                                                                    // 40
});                                                                                                                    // 33
questions.deny({                                                                                                       // 43
  update: function () {                                                                                                // 44
    return true;                                                                                                       // 45
  },                                                                                                                   // 46
  insert: function () {                                                                                                // 48
    return true;                                                                                                       // 49
  }                                                                                                                    // 50
});                                                                                                                    // 43
raids.deny({                                                                                                           // 53
  update: function () {                                                                                                // 54
    return true;                                                                                                       // 55
  },                                                                                                                   // 56
  insert: function () {                                                                                                // 58
    return true;                                                                                                       // 59
  }                                                                                                                    // 60
});                                                                                                                    // 53
Meteor.users.deny({                                                                                                    // 63
  update: function () {                                                                                                // 64
    return true;                                                                                                       // 65
  }                                                                                                                    // 66
});                                                                                                                    // 63
userCount.deny({                                                                                                       // 69
  update: function () {                                                                                                // 70
    return true;                                                                                                       // 71
  },                                                                                                                   // 72
  insert: function () {                                                                                                // 74
    return true;                                                                                                       // 75
  }                                                                                                                    // 76
});                                                                                                                    // 69
siteDetails.deny({                                                                                                     // 79
  update: function () {                                                                                                // 80
    return true;                                                                                                       // 81
  },                                                                                                                   // 82
  insert: function () {                                                                                                // 84
    return true;                                                                                                       // 85
  }                                                                                                                    // 86
});                                                                                                                    // 79
counts.deny({                                                                                                          // 90
  update: function () {                                                                                                // 91
    return true;                                                                                                       // 92
  },                                                                                                                   // 93
  insert: function () {                                                                                                // 95
    return true;                                                                                                       // 96
  }                                                                                                                    // 97
});                                                                                                                    // 90
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"globals.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/globals.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//defaults to feed (home)                                                                                              // 1
currentPage = new ReactiveVar("feed"); //gets currentPost                                                              // 2
                                                                                                                       //
currentPost = new ReactiveVar(); //admin page location                                                                 // 5
                                                                                                                       //
adminLoc = new ReactiveVar("dash"); //the news filter                                                                  // 8
                                                                                                                       //
newsFilter = new ReactiveVar('news'); //for application viewing                                                        // 11
                                                                                                                       //
currentApp = new ReactiveVar('currentApp'); //for viewing existing raid                                                // 14
                                                                                                                       //
currentRaid = new ReactiveVar('currentRaid'); //for deleting stuff                                                     // 17
                                                                                                                       //
deleting = new ReactiveVar(''); //for loading image in carousel                                                        // 20
                                                                                                                       //
currentImage = new ReactiveVar(''); //for lazy loading                                                                 // 23
                                                                                                                       //
postLimitServer = new ReactiveVar(7); //test                                                                           // 26
                                                                                                                       //
imageTest = new ReactiveVar();                                                                                         // 29
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routes.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
FlowRouter.route('/', {                                                                                                // 1
  name: 'home',                                                                                                        // 2
  subscriptions: function (params, queryParams) {                                                                      // 3
    // using Fast Render                                                                                               // 4
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 5
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 6
  },                                                                                                                   // 7
  action: function () {                                                                                                // 8
    BlazeLayout.render('index');                                                                                       // 9
  },                                                                                                                   // 10
  fastRender: true                                                                                                     // 11
});                                                                                                                    // 1
FlowRouter.route('/admin', {                                                                                           // 14
  name: "admin",                                                                                                       // 15
  action: function () {                                                                                                // 16
    if (Meteor.userId()) {                                                                                             // 17
      BlazeLayout.render('admin');                                                                                     // 18
    } else {                                                                                                           // 19
      BlazeLayout.render('signin');                                                                                    // 20
    }                                                                                                                  // 21
  }                                                                                                                    // 22
});                                                                                                                    // 14
FlowRouter.route('/admin-login', {                                                                                     // 25
  name: "login",                                                                                                       // 26
  action: function () {                                                                                                // 27
    BlazeLayout.render('signin');                                                                                      // 28
  }                                                                                                                    // 29
});                                                                                                                    // 25
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fileserver.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/fileserver.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var fs = Npm.require('fs');                                                                                            // 1
                                                                                                                       //
WebApp.connectHandlers.use(function (req, res, next) {                                                                 // 2
    var re = /^\/files\/(.*)$/.exec(req.url);                                                                          // 3
                                                                                                                       //
    if (re !== null) {                                                                                                 // 4
        // Only handle URLs that start with /uploads_url_prefix/*                                                      // 4
        var filePath = process.env.PWD + '/.static~/' + re[1];                                                         // 5
        var data = fs.readFileSync(filePath);                                                                          // 6
        res.writeHead(200, {                                                                                           // 7
            'Content-Type': 'image'                                                                                    // 8
        });                                                                                                            // 7
        res.write(data);                                                                                               // 10
        res.end();                                                                                                     // 11
    } else {                                                                                                           // 12
        // Other urls will have default behaviors                                                                      // 12
        next();                                                                                                        // 13
    }                                                                                                                  // 14
});                                                                                                                    // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publish.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publish("posts", function (limit) {                                                                             // 1
  var dl = limit || 7; //send data newest first to the client                                                          // 2
                                                                                                                       //
  if (!this.userId) {                                                                                                  // 4
    return posts.find({}, {                                                                                            // 5
      sort: {                                                                                                          // 5
        date_created: -1                                                                                               // 5
      },                                                                                                               // 5
      limit: dl                                                                                                        // 5
    });                                                                                                                // 5
  } else {                                                                                                             // 6
    return posts.find({});                                                                                             // 7
  }                                                                                                                    // 8
});                                                                                                                    // 9
Meteor.publish("raids", function () {                                                                                  // 11
  return raids.find({});                                                                                               // 12
});                                                                                                                    // 13
Meteor.publish("questions", function () {                                                                              // 15
  return questions.find({});                                                                                           // 16
});                                                                                                                    // 17
Meteor.publish("siteDetails", function () {                                                                            // 19
  return siteDetails.find({});                                                                                         // 20
});                                                                                                                    // 21
Meteor.publish("counts", function () {                                                                                 // 23
  return counts.find({});                                                                                              // 24
});                                                                                                                    // 25
Meteor.publish("apps", function () {                                                                                   // 27
  return apps.find({});                                                                                                // 28
});                                                                                                                    // 29
Meteor.publish('images', function (search, post) {                                                                     // 32
  return images.find({}, {                                                                                             // 33
    sort: {                                                                                                            // 33
      date_created: -1                                                                                                 // 33
    },                                                                                                                 // 33
    limit: 7                                                                                                           // 33
  });                                                                                                                  // 33
});                                                                                                                    // 34
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/server.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 1
  fs = Npm.require('fs');                                                                                              // 2
}); //checks to see if default site values are set, creates template for later                                         // 3
                                                                                                                       //
var needed = ['title', 'about', 'tabard', 'background', 'favicon', 'recruiting'];                                      // 7
var firstTime = 0;                                                                                                     // 8
                                                                                                                       //
for (var i = 0; i < needed.length; i++) {                                                                              // 9
  if (siteDetails.findOne({                                                                                            // 10
    _id: needed[i]                                                                                                     // 10
  })) {//horray!!                                                                                                      // 10
  } else {                                                                                                             // 12
    //lets create em                                                                                                   // 13
    siteDetails.insert({                                                                                               // 14
      _id: needed[i]                                                                                                   // 14
    });                                                                                                                // 14
    firstTime = 1;                                                                                                     // 15
  }                                                                                                                    // 16
}                                                                                                                      // 17
                                                                                                                       //
if (firstTime == 1) {                                                                                                  // 18
  //wow                                                                                                                // 19
  siteDetails.update({                                                                                                 // 20
    _id: 'recruiting'                                                                                                  // 20
  }, {                                                                                                                 // 20
    $set: {                                                                                                            // 20
      dnB: 'checked',                                                                                                  // 20
      dnU: 'checked',                                                                                                  // 20
      dnF: 'checked',                                                                                                  // 20
      dhH: 'checked',                                                                                                  // 20
      dhV: 'checked',                                                                                                  // 20
      drB: 'checked',                                                                                                  // 20
      drF: 'checked',                                                                                                  // 20
      drR: 'checked',                                                                                                  // 20
      drG: 'checked',                                                                                                  // 20
      huM: 'checked',                                                                                                  // 20
      huS: 'checked',                                                                                                  // 20
      huB: 'checked',                                                                                                  // 20
      maF: 'checked',                                                                                                  // 20
      maFr: 'checked',                                                                                                 // 20
      maA: 'checked',                                                                                                  // 20
      moM: 'checked',                                                                                                  // 20
      moW: 'checked',                                                                                                  // 20
      moB: 'checked',                                                                                                  // 20
      paH: 'checked',                                                                                                  // 20
      paR: 'checked',                                                                                                  // 20
      paP: 'checked',                                                                                                  // 20
      prS: 'checked',                                                                                                  // 20
      prD: 'checked',                                                                                                  // 20
      prH: 'checked',                                                                                                  // 20
      roA: 'checked',                                                                                                  // 20
      roS: 'checked',                                                                                                  // 20
      roC: 'checked',                                                                                                  // 20
      shE: 'checked',                                                                                                  // 20
      shR: 'checked',                                                                                                  // 20
      shEn: 'checked',                                                                                                 // 20
      waA: 'checked',                                                                                                  // 20
      waD: 'checked',                                                                                                  // 20
      waDe: 'checked',                                                                                                 // 20
      warA: 'checked',                                                                                                 // 20
      warF: 'checked',                                                                                                 // 20
      warP: 'checked'                                                                                                  // 20
    }                                                                                                                  // 20
  });                                                                                                                  // 20
  console.log('hi');                                                                                                   // 21
  firstTime = 0;                                                                                                       // 22
  counts.insert({                                                                                                      // 23
    _id: "data",                                                                                                       // 23
    postCount: 0,                                                                                                      // 23
    appCount: 0,                                                                                                       // 23
    raidCount: 0                                                                                                       // 23
  });                                                                                                                  // 23
} //creates initial account                                                                                            // 24
                                                                                                                       //
                                                                                                                       //
Meteor.methods({                                                                                                       // 28
  'accountCheck': function () {                                                                                        // 29
    if (userCount.findOne({                                                                                            // 30
      count: 0                                                                                                         // 30
    })) {                                                                                                              // 30
      return true;                                                                                                     // 31
    } else {                                                                                                           // 32
      return false;                                                                                                    // 33
    }                                                                                                                  // 34
  },                                                                                                                   // 35
  'phraseCheck': function (secret) {                                                                                   // 36
    if (secret == "SnowyTableSanDiegoFifteenTwelve") {                                                                 // 37
      return true;                                                                                                     // 38
    }                                                                                                                  // 39
  },                                                                                                                   // 40
  'createAcc': function (usm, psw) {                                                                                   // 41
    Accounts.createUser({                                                                                              // 42
      username: usm,                                                                                                   // 43
      password: psw                                                                                                    // 44
    });                                                                                                                // 42
    userCount.insert({                                                                                                 // 46
      count: 1                                                                                                         // 46
    });                                                                                                                // 46
    userCount.remove({                                                                                                 // 47
      count: 0                                                                                                         // 47
    });                                                                                                                // 47
  }                                                                                                                    // 48
});                                                                                                                    // 28
Meteor.methods({                                                                                                       // 51
  'post': function (imageData, title, content, cata) {                                                                 // 52
    if (Meteor.user()) {                                                                                               // 53
      // our data URL string from canvas.toDataUrl();                                                                  // 54
      var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                       // 55
                                                                                                                       //
      var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp            // 57
                                                                                                                       //
      var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
      var imageBuffer = new Buffer(base64Data, "base64");                                                              // 61
      var id = ShortId.generate();                                                                                     // 62
      var isoDate = new Date();                                                                                        // 63
      var res = isoDate.toString().split(" ");                                                                         // 64
      var date = res[1] + " " + res[2] + " " + res[3];                                                                 // 65
      var path = process.env["PWD"] + '/.static~/';                                                                    // 66
      var cata = cata;                                                                                                 // 68
                                                                                                                       //
      if (cata.includes("News")) {                                                                                     // 69
        cata = "News";                                                                                                 // 70
      } else if (cata.includes("Boss")) {                                                                              // 71
        cata = "Boss";                                                                                                 // 72
      } else {                                                                                                         // 73
        //if no catagory is supplied, assume it's just news                                                            // 74
        cata = "News";                                                                                                 // 75
      }                                                                                                                // 76
                                                                                                                       //
      posts.insert({                                                                                                   // 77
        _id: id,                                                                                                       // 77
        title: title,                                                                                                  // 77
        content: content,                                                                                              // 77
        imgPath: '/files/' + id + ".jpeg",                                                                             // 77
        date: date,                                                                                                    // 77
        cataSux: cata,                                                                                                 // 77
        date_created: new Date()                                                                                       // 77
      });                                                                                                              // 77
      counts.update({                                                                                                  // 78
        _id: "data"                                                                                                    // 78
      }, {                                                                                                             // 78
        $inc: {                                                                                                        // 78
          postCount: 1                                                                                                 // 78
        }                                                                                                              // 78
      });                                                                                                              // 78
                                                                                                                       //
      if (cata == "Boss") {                                                                                            // 79
        images.insert({                                                                                                // 80
          _id: id,                                                                                                     // 80
          title: title,                                                                                                // 80
          imgPath: '/files/' + id + ".jpeg",                                                                           // 80
          date_created: new Date()                                                                                     // 80
        });                                                                                                            // 80
      }                                                                                                                // 81
                                                                                                                       //
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 82
        if (err) throw err;                                                                                            // 84
        console.log('Done!');                                                                                          // 85
      });                                                                                                              // 86
    }                                                                                                                  // 87
  },                                                                                                                   // 88
  'addRaid': function (title, normS, heroS, mythS, bossName, bossStatN, bossStatH, bossStatM, addCC) {                 // 89
    if (Meteor.user()) {                                                                                               // 90
      //okay, I'm posting each boss and it's stats in an array. I need to break it up to show it, but I'm sure I can do that Client side.
      raids.insert({                                                                                                   // 92
        title: title,                                                                                                  // 92
        normS: normS,                                                                                                  // 92
        heroS: heroS,                                                                                                  // 92
        mythS: mythS,                                                                                                  // 92
        bossName: bossName,                                                                                            // 92
        bossStatN: bossStatN,                                                                                          // 92
        bossStatH: bossStatH,                                                                                          // 92
        bossStatM: bossStatM,                                                                                          // 92
        length: addCC                                                                                                  // 92
      });                                                                                                              // 92
      counts.update({                                                                                                  // 93
        _id: "data"                                                                                                    // 93
      }, {                                                                                                             // 93
        $inc: {                                                                                                        // 93
          raidCount: 1                                                                                                 // 93
        }                                                                                                              // 93
      });                                                                                                              // 93
    }                                                                                                                  // 94
  },                                                                                                                   // 95
  'addQues': function (ques, quesCount) {                                                                              // 96
    if (Meteor.user()) {                                                                                               // 97
      questions.remove({});                                                                                            // 98
      questions.insert({                                                                                               // 99
        ques: ques,                                                                                                    // 99
        quesCount: quesCount                                                                                           // 99
      });                                                                                                              // 99
    }                                                                                                                  // 100
  }                                                                                                                    // 101
});                                                                                                                    // 51
Meteor.methods({                                                                                                       // 104
  'updateSite': function (specStatus, title, about) {                                                                  // 105
    if (Meteor.user()) {                                                                                               // 106
      var spec = ['dnB', 'dnU', 'dnF', 'dhH', 'dhV', 'drB', 'drF', 'drR', 'drG', 'huM', 'huS', 'huB', 'maF', 'maFr', 'maA', 'moM', 'moW', 'moB', 'paH', 'paR', 'paP', 'prS', 'prD', 'prH', 'roA', 'roS', 'roC', 'shE', 'shR', 'shEn', 'waA', 'waD', 'waDe', 'warA', 'warF', 'warP']; //for loop wont work, as I can only assign the value and not the property
                                                                                                                       //
      siteDetails.update({                                                                                             // 110
        _id: 'recruiting'                                                                                              // 110
      }, {                                                                                                             // 110
        $set: {                                                                                                        // 110
          dnB: specStatus[0],                                                                                          // 110
          dnU: specStatus[1],                                                                                          // 110
          dnF: specStatus[2],                                                                                          // 110
          dhH: specStatus[3],                                                                                          // 110
          dhV: specStatus[4],                                                                                          // 110
          drB: specStatus[5],                                                                                          // 110
          drF: specStatus[6],                                                                                          // 110
          drR: specStatus[7],                                                                                          // 110
          drG: specStatus[8],                                                                                          // 110
          huM: specStatus[9],                                                                                          // 110
          huS: specStatus[10],                                                                                         // 110
          huB: specStatus[11],                                                                                         // 110
          maF: specStatus[12],                                                                                         // 110
          maFr: specStatus[13],                                                                                        // 110
          maA: specStatus[14],                                                                                         // 110
          moM: specStatus[15],                                                                                         // 110
          moW: specStatus[16],                                                                                         // 110
          moB: specStatus[17],                                                                                         // 110
          paH: specStatus[18],                                                                                         // 110
          paR: specStatus[19],                                                                                         // 110
          paP: specStatus[20],                                                                                         // 110
          prS: specStatus[21],                                                                                         // 110
          prD: specStatus[22],                                                                                         // 110
          prH: specStatus[23],                                                                                         // 110
          roA: specStatus[24],                                                                                         // 110
          roS: specStatus[25],                                                                                         // 110
          roC: specStatus[26],                                                                                         // 110
          shE: specStatus[27],                                                                                         // 110
          shR: specStatus[28],                                                                                         // 110
          shEn: specStatus[29],                                                                                        // 110
          waA: specStatus[30],                                                                                         // 110
          waD: specStatus[31],                                                                                         // 110
          waDe: specStatus[32],                                                                                        // 110
          warA: specStatus[33],                                                                                        // 110
          warF: specStatus[34],                                                                                        // 110
          warP: specStatus[35]                                                                                         // 110
        }                                                                                                              // 110
      });                                                                                                              // 110
                                                                                                                       //
      if (title != "" && title != undefined && title != null) {                                                        // 113
        siteDetails.update({                                                                                           // 114
          _id: 'title'                                                                                                 // 114
        }, {                                                                                                           // 114
          $set: {                                                                                                      // 114
            title: title                                                                                               // 114
          }                                                                                                            // 114
        });                                                                                                            // 114
      }                                                                                                                // 115
                                                                                                                       //
      if (about != "" && about != undefined && about != null) {                                                        // 116
        siteDetails.update({                                                                                           // 117
          _id: 'about'                                                                                                 // 117
        }, {                                                                                                           // 117
          $set: {                                                                                                      // 117
            about: about                                                                                               // 117
          }                                                                                                            // 117
        });                                                                                                            // 117
      }                                                                                                                // 118
    }                                                                                                                  // 119
  },                                                                                                                   // 120
  'updateRaid': function (title, normS, heroS, mythS, bossName, bossStatN, bossStatH, bossStatM, addCC, target) {      // 121
    if (Meteor.user()) {                                                                                               // 122
      raids.update({                                                                                                   // 123
        _id: target                                                                                                    // 123
      }, {                                                                                                             // 123
        $set: {                                                                                                        // 123
          title: title,                                                                                                // 123
          normS: normS,                                                                                                // 123
          heroS: heroS,                                                                                                // 123
          mythS: mythS,                                                                                                // 123
          bossName: bossName,                                                                                          // 123
          bossStatN: bossStatN,                                                                                        // 123
          bossStatH: bossStatH,                                                                                        // 123
          bossStatM: bossStatM,                                                                                        // 123
          length: addCC                                                                                                // 123
        }                                                                                                              // 123
      });                                                                                                              // 123
    }                                                                                                                  // 124
  },                                                                                                                   // 125
  'updatePost': function (title, content, id) {                                                                        // 126
    if (Meteor.user()) {                                                                                               // 127
      posts.update({                                                                                                   // 128
        _id: id                                                                                                        // 128
      }, {                                                                                                             // 128
        $set: {                                                                                                        // 128
          title: title,                                                                                                // 128
          content: content                                                                                             // 128
        }                                                                                                              // 128
      });                                                                                                              // 128
    }                                                                                                                  // 129
  }                                                                                                                    // 130
});                                                                                                                    // 104
Meteor.methods({                                                                                                       // 133
  'sendApp': function (questions, resps, amt) {                                                                        // 134
    apps.insert({                                                                                                      // 135
      username: resps[0].replace("::", ""),                                                                            // 135
      questions: questions,                                                                                            // 135
      resps: resps,                                                                                                    // 135
      amt: amt                                                                                                         // 135
    });                                                                                                                // 135
    counts.update({                                                                                                    // 136
      _id: "data"                                                                                                      // 136
    }, {                                                                                                               // 136
      $inc: {                                                                                                          // 136
        appCount: 1                                                                                                    // 136
      }                                                                                                                // 136
    });                                                                                                                // 136
  }                                                                                                                    // 137
});                                                                                                                    // 133
Meteor.methods({                                                                                                       // 140
  'deletePost': function (post) {                                                                                      // 141
    if (Meteor.user()) {                                                                                               // 142
      var filePath = process.env["PWD"] + '/.static~/' + post + '.jpeg';                                               // 143
      fs.unlinkSync(filePath);                                                                                         // 144
      posts.remove({                                                                                                   // 145
        _id: post                                                                                                      // 145
      });                                                                                                              // 145
      counts.update({                                                                                                  // 146
        _id: "data"                                                                                                    // 146
      }, {                                                                                                             // 146
        $inc: {                                                                                                        // 146
          postCount: -1                                                                                                // 146
        }                                                                                                              // 146
      });                                                                                                              // 146
    }                                                                                                                  // 147
  },                                                                                                                   // 148
  'deleteApp': function (appId) {                                                                                      // 149
    if (Meteor.user()) {                                                                                               // 150
      apps.remove({                                                                                                    // 151
        _id: appId                                                                                                     // 151
      });                                                                                                              // 151
      counts.update({                                                                                                  // 152
        _id: "data"                                                                                                    // 152
      }, {                                                                                                             // 152
        $inc: {                                                                                                        // 152
          appCount: -1                                                                                                 // 152
        }                                                                                                              // 152
      });                                                                                                              // 152
    }                                                                                                                  // 153
  },                                                                                                                   // 154
  'deleteRaid': function (raidId) {                                                                                    // 155
    if (Meteor.user()) {                                                                                               // 156
      raids.remove({                                                                                                   // 157
        _id: raidId                                                                                                    // 157
      });                                                                                                              // 157
      counts.update({                                                                                                  // 158
        _id: "data"                                                                                                    // 158
      }, {                                                                                                             // 158
        $inc: {                                                                                                        // 158
          raidCount: -1                                                                                                // 158
        }                                                                                                              // 158
      });                                                                                                              // 158
    }                                                                                                                  // 159
  }                                                                                                                    // 160
});                                                                                                                    // 140
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/db.js");
require("./lib/globals.js");
require("./lib/routes.js");
require("./server/fileserver.js");
require("./server/publish.js");
require("./server/server.js");
//# sourceMappingURL=app.js.map
