var require = meteorInstall({"lib":{"db.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/db.js                                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
posts = new Mongo.Collection('posts');                                                                                 // 1
raids = new Mongo.Collection('raids');                                                                                 // 2
questions = new Mongo.Collection('questions');                                                                         // 3
apps = new Mongo.Collection('apps');                                                                                   // 4
userCount = new Mongo.Collection('userCount');                                                                         // 5
siteDetails = new Mongo.Collection('siteDetails');                                                                     // 6
twitch = new Mongo.Collection('twitch');                                                                               // 7
counts = new Mongo.Collection('counts');                                                                               // 9
images = new Mongo.Collection('images'); //denys anyone access to these (unless the above allow is met)                // 11
                                                                                                                       //
posts.deny({                                                                                                           // 14
  update: function () {                                                                                                // 15
    return true;                                                                                                       // 16
  },                                                                                                                   // 17
  insert: function () {                                                                                                // 19
    return true;                                                                                                       // 20
  }                                                                                                                    // 21
});                                                                                                                    // 14
twitch.deny({                                                                                                          // 24
  update: function () {                                                                                                // 25
    return true;                                                                                                       // 26
  },                                                                                                                   // 27
  insert: function () {                                                                                                // 29
    return true;                                                                                                       // 30
  }                                                                                                                    // 31
});                                                                                                                    // 24
images.deny({                                                                                                          // 34
  update: function () {                                                                                                // 35
    return true;                                                                                                       // 36
  },                                                                                                                   // 37
  insert: function () {                                                                                                // 39
    return true;                                                                                                       // 40
  }                                                                                                                    // 41
});                                                                                                                    // 34
apps.deny({                                                                                                            // 44
  update: function () {                                                                                                // 45
    return true;                                                                                                       // 46
  },                                                                                                                   // 47
  insert: function () {                                                                                                // 49
    return true;                                                                                                       // 50
  }                                                                                                                    // 51
});                                                                                                                    // 44
questions.deny({                                                                                                       // 54
  update: function () {                                                                                                // 55
    return true;                                                                                                       // 56
  },                                                                                                                   // 57
  insert: function () {                                                                                                // 59
    return true;                                                                                                       // 60
  }                                                                                                                    // 61
});                                                                                                                    // 54
raids.deny({                                                                                                           // 64
  update: function () {                                                                                                // 65
    return true;                                                                                                       // 66
  },                                                                                                                   // 67
  insert: function () {                                                                                                // 69
    return true;                                                                                                       // 70
  }                                                                                                                    // 71
});                                                                                                                    // 64
Meteor.users.deny({                                                                                                    // 74
  update: function () {                                                                                                // 75
    return true;                                                                                                       // 76
  }                                                                                                                    // 77
});                                                                                                                    // 74
userCount.deny({                                                                                                       // 80
  update: function () {                                                                                                // 81
    return true;                                                                                                       // 82
  },                                                                                                                   // 83
  insert: function () {                                                                                                // 85
    return true;                                                                                                       // 86
  }                                                                                                                    // 87
});                                                                                                                    // 80
siteDetails.deny({                                                                                                     // 90
  update: function () {                                                                                                // 91
    return true;                                                                                                       // 92
  },                                                                                                                   // 93
  insert: function () {                                                                                                // 95
    return true;                                                                                                       // 96
  }                                                                                                                    // 97
});                                                                                                                    // 90
counts.deny({                                                                                                          // 101
  update: function () {                                                                                                // 102
    return true;                                                                                                       // 103
  },                                                                                                                   // 104
  insert: function () {                                                                                                // 106
    return true;                                                                                                       // 107
  }                                                                                                                    // 108
});                                                                                                                    // 101
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"globals.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/globals.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//defaults to feed (home)                                                                                              // 1
currentPage = new ReactiveVar("feed"); //gets currentPost                                                              // 2
                                                                                                                       //
currentPost = new ReactiveVar(); //admin page location                                                                 // 5
                                                                                                                       //
adminLoc = new ReactiveVar("dash"); //the news filter                                                                  // 8
                                                                                                                       //
newsFilter = new ReactiveVar('news'); //for application viewing                                                        // 11
                                                                                                                       //
currentApp = new ReactiveVar('currentApp'); //for viewing existing raid                                                // 14
                                                                                                                       //
currentRaid = new ReactiveVar('currentRaid'); //for deleting stuff                                                     // 17
                                                                                                                       //
deleting = new ReactiveVar(''); //for loading image in carousel                                                        // 20
                                                                                                                       //
currentImage = new ReactiveVar(''); //for lazy loading                                                                 // 23
                                                                                                                       //
postLimitServer = new ReactiveVar(7); //test                                                                           // 26
                                                                                                                       //
imageTest = new ReactiveVar(); //get post ID from slug, load                                                           // 29
                                                                                                                       //
postFromSlug = new ReactiveVar(); //set app sorting                                                                    // 32
                                                                                                                       //
appSort = new ReactiveVar('');                                                                                         // 35
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routes.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
FlowRouter.route('/', {                                                                                                // 1
  name: 'home',                                                                                                        // 2
  subscriptions: function (params, queryParams) {                                                                      // 3
    // using Fast Render                                                                                               // 4
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 5
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 6
  },                                                                                                                   // 7
  action: function () {                                                                                                // 8
    BlazeLayout.render('index');                                                                                       // 9
  },                                                                                                                   // 10
  fastRender: true                                                                                                     // 11
});                                                                                                                    // 1
FlowRouter.route('/admin', {                                                                                           // 14
  name: "admin",                                                                                                       // 15
  action: function () {                                                                                                // 16
    if (Meteor.userId()) {                                                                                             // 17
      BlazeLayout.render('admin');                                                                                     // 18
    } else {                                                                                                           // 19
      BlazeLayout.render('signin');                                                                                    // 20
    }                                                                                                                  // 21
  }                                                                                                                    // 22
});                                                                                                                    // 14
FlowRouter.route('/admin-login', {                                                                                     // 25
  name: "login",                                                                                                       // 26
  action: function () {                                                                                                // 27
    BlazeLayout.render('signin');                                                                                      // 28
  }                                                                                                                    // 29
});                                                                                                                    // 25
FlowRouter.route('/p/:_id', {                                                                                          // 32
  name: 'post',                                                                                                        // 33
  subscriptions: function (params, queryParams) {                                                                      // 34
    // using Fast Render                                                                                               // 35
    this.register('posts2', Meteor.subscribe('posts2'));                                                               // 36
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 37
  },                                                                                                                   // 38
  action: function (params, queryParams) {                                                                             // 39
    BlazeLayout.render('index');                                                                                       // 40
    var theseParms = params._id;                                                                                       // 41
    currentPage.set('article');                                                                                        // 42
    currentPost.set(theseParms);                                                                                       // 43
    postFromSlug.set(params._id);                                                                                      // 44
  }                                                                                                                    // 45
});                                                                                                                    // 32
FlowRouter.route('/feed', {                                                                                            // 48
  name: 'home2',                                                                                                       // 49
  subscriptions: function (params, queryParams) {                                                                      // 50
    // using Fast Render                                                                                               // 51
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 52
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 53
  },                                                                                                                   // 54
  action: function (params, queryParams) {                                                                             // 55
    BlazeLayout.render('index');                                                                                       // 56
    currentPage.set('feed');                                                                                           // 57
  }                                                                                                                    // 58
});                                                                                                                    // 48
FlowRouter.route('/about', {                                                                                           // 61
  name: 'about',                                                                                                       // 62
  subscriptions: function (params, queryParams) {                                                                      // 63
    // using Fast Render                                                                                               // 64
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 65
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 66
  },                                                                                                                   // 67
  action: function (params, queryParams) {                                                                             // 68
    BlazeLayout.render('index');                                                                                       // 69
    currentPage.set('about');                                                                                          // 70
  }                                                                                                                    // 71
});                                                                                                                    // 61
FlowRouter.route('/apply', {                                                                                           // 74
  name: 'apply',                                                                                                       // 75
  subscriptions: function (params, queryParams) {                                                                      // 76
    // using Fast Render                                                                                               // 77
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 78
  },                                                                                                                   // 79
  action: function (params, queryParams) {                                                                             // 80
    BlazeLayout.render('index');                                                                                       // 81
    currentPage.set('apply');                                                                                          // 82
  }                                                                                                                    // 83
});                                                                                                                    // 74
FlowRouter.route('/streams', {                                                                                         // 86
  name: 'streams',                                                                                                     // 87
  subscriptions: function (params, queryParams) {                                                                      // 88
    // using Fast Render                                                                                               // 89
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 90
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 91
  },                                                                                                                   // 92
  action: function (params, queryParams) {                                                                             // 93
    BlazeLayout.render('index');                                                                                       // 94
    currentPage.set('streams');                                                                                        // 95
  }                                                                                                                    // 96
});                                                                                                                    // 86
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fileserver.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/fileserver.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var fs = Npm.require('fs');                                                                                            // 1
                                                                                                                       //
WebApp.connectHandlers.use(function (req, res, next) {                                                                 // 2
    var re = /^\/files\/(.*)$/.exec(req.url);                                                                          // 3
                                                                                                                       //
    if (re !== null) {                                                                                                 // 4
        // Only handle URLs that start with /uploads_url_prefix/*                                                      // 4
        var filePath = process.env.PWD + '/.static~/' + re[1];                                                         // 5
        var data = fs.readFileSync(filePath);                                                                          // 6
        res.writeHead(200, {                                                                                           // 7
            'Content-Type': 'image'                                                                                    // 8
        });                                                                                                            // 7
        res.write(data);                                                                                               // 10
        res.end();                                                                                                     // 11
    } else {                                                                                                           // 12
        // Other urls will have default behaviors                                                                      // 12
        next();                                                                                                        // 13
    }                                                                                                                  // 14
});                                                                                                                    // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publish.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publish("posts", function (limit) {                                                                             // 1
  var dl = limit || 7; //send data newest first to the client                                                          // 2
                                                                                                                       //
  return posts.find({}, {                                                                                              // 4
    sort: {                                                                                                            // 4
      date_created: -1                                                                                                 // 4
    },                                                                                                                 // 4
    limit: dl                                                                                                          // 4
  });                                                                                                                  // 4
});                                                                                                                    // 5
Meteor.publish("posts2", function (target) {                                                                           // 7
  return posts.find({                                                                                                  // 8
    _id: target                                                                                                        // 8
  });                                                                                                                  // 8
});                                                                                                                    // 9
Meteor.publish("raids", function () {                                                                                  // 11
  return raids.find({}, {                                                                                              // 12
    sort: {                                                                                                            // 12
      date: -1                                                                                                         // 12
    }                                                                                                                  // 12
  });                                                                                                                  // 12
});                                                                                                                    // 13
Meteor.publish("twitch", function () {                                                                                 // 15
  return twitch.find({});                                                                                              // 16
});                                                                                                                    // 17
Meteor.publish("questions", function () {                                                                              // 19
  return questions.find({});                                                                                           // 20
});                                                                                                                    // 21
Meteor.publish("siteDetails", function () {                                                                            // 23
  return siteDetails.find({});                                                                                         // 24
});                                                                                                                    // 25
Meteor.publish("counts", function () {                                                                                 // 27
  return counts.find({});                                                                                              // 28
});                                                                                                                    // 29
Meteor.publish("apps", function () {                                                                                   // 31
  return apps.find({}, {                                                                                               // 32
    sort: {                                                                                                            // 32
      date_created: -1                                                                                                 // 32
    }                                                                                                                  // 32
  });                                                                                                                  // 32
});                                                                                                                    // 33
Meteor.publish('images', function (search, post) {                                                                     // 36
  return images.find({}, {                                                                                             // 37
    sort: {                                                                                                            // 37
      date_created: -1                                                                                                 // 37
    },                                                                                                                 // 37
    limit: 7                                                                                                           // 37
  });                                                                                                                  // 37
});                                                                                                                    // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/server.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 1
  fs = Npm.require('fs'); // converts old app dates to new format                                                      // 2
                                                                                                                       //
  var testingsometing = apps.find({}).fetch();                                                                         // 5
                                                                                                                       //
  for (var i = 0; i < testingsometing.length; i++) {                                                                   // 6
    if (!testingsometing[i].date_created) {                                                                            // 7
      var id = testingsometing[i]._id;                                                                                 // 8
      var date = testingsometing[i].date;                                                                              // 9
      var date_created = date;                                                                                         // 10
      var res = date.toString().split(" ");                                                                            // 11
      date = res[1] + " " + res[2] + " " + res[3];                                                                     // 12
      apps.update({                                                                                                    // 13
        _id: id                                                                                                        // 13
      }, {                                                                                                             // 13
        $set: {                                                                                                        // 13
          date: date,                                                                                                  // 13
          date_created: date_created                                                                                   // 13
        }                                                                                                              // 13
      });                                                                                                              // 13
    }                                                                                                                  // 14
  }                                                                                                                    // 15
}); //checks to see if default site values are set, creates template for later                                         // 16
                                                                                                                       //
var needed = ['title', 'about', 'tabard', 'background', 'favicon', 'recruiting'];                                      // 19
var firstTime = 0;                                                                                                     // 20
                                                                                                                       //
for (var i = 0; i < needed.length; i++) {                                                                              // 21
  if (siteDetails.findOne({                                                                                            // 22
    _id: needed[i]                                                                                                     // 22
  })) {//horray!!                                                                                                      // 22
  } else {                                                                                                             // 24
    //lets create em                                                                                                   // 25
    siteDetails.insert({                                                                                               // 26
      _id: needed[i]                                                                                                   // 26
    });                                                                                                                // 26
    firstTime = 1;                                                                                                     // 27
  }                                                                                                                    // 28
}                                                                                                                      // 29
                                                                                                                       //
if (firstTime == 1) {                                                                                                  // 30
  //wow                                                                                                                // 31
  siteDetails.update({                                                                                                 // 32
    _id: 'recruiting'                                                                                                  // 32
  }, {                                                                                                                 // 32
    $set: {                                                                                                            // 32
      dnB: 'checked',                                                                                                  // 32
      dnU: 'checked',                                                                                                  // 32
      dnF: 'checked',                                                                                                  // 32
      dhH: 'checked',                                                                                                  // 32
      dhV: 'checked',                                                                                                  // 32
      drB: 'checked',                                                                                                  // 32
      drF: 'checked',                                                                                                  // 32
      drR: 'checked',                                                                                                  // 32
      drG: 'checked',                                                                                                  // 32
      huM: 'checked',                                                                                                  // 32
      huS: 'checked',                                                                                                  // 32
      huB: 'checked',                                                                                                  // 32
      maF: 'checked',                                                                                                  // 32
      maFr: 'checked',                                                                                                 // 32
      maA: 'checked',                                                                                                  // 32
      moM: 'checked',                                                                                                  // 32
      moW: 'checked',                                                                                                  // 32
      moB: 'checked',                                                                                                  // 32
      paH: 'checked',                                                                                                  // 32
      paR: 'checked',                                                                                                  // 32
      paP: 'checked',                                                                                                  // 32
      prS: 'checked',                                                                                                  // 32
      prD: 'checked',                                                                                                  // 32
      prH: 'checked',                                                                                                  // 32
      roA: 'checked',                                                                                                  // 32
      roS: 'checked',                                                                                                  // 32
      roC: 'checked',                                                                                                  // 32
      shE: 'checked',                                                                                                  // 32
      shR: 'checked',                                                                                                  // 32
      shEn: 'checked',                                                                                                 // 32
      waA: 'checked',                                                                                                  // 32
      waD: 'checked',                                                                                                  // 32
      waDe: 'checked',                                                                                                 // 32
      warA: 'checked',                                                                                                 // 32
      warF: 'checked',                                                                                                 // 32
      warP: 'checked'                                                                                                  // 32
    }                                                                                                                  // 32
  });                                                                                                                  // 32
  userCount.insert({                                                                                                   // 33
    count: 0                                                                                                           // 33
  });                                                                                                                  // 33
  counts.insert({                                                                                                      // 34
    _id: "data",                                                                                                       // 34
    postCount: 0,                                                                                                      // 34
    appCount: 0,                                                                                                       // 34
    raidCount: 0                                                                                                       // 34
  });                                                                                                                  // 34
  firstTime = 0;                                                                                                       // 35
} //creates initial account                                                                                            // 36
                                                                                                                       //
                                                                                                                       //
Meteor.methods({                                                                                                       // 40
  'accountCheck': function () {                                                                                        // 41
    if (userCount.findOne({                                                                                            // 42
      count: 0                                                                                                         // 42
    })) {                                                                                                              // 42
      return true;                                                                                                     // 43
    } else {                                                                                                           // 44
      return false;                                                                                                    // 45
    }                                                                                                                  // 46
  },                                                                                                                   // 47
  'phraseCheck': function (secret) {                                                                                   // 48
    if (secret == "SnowyTableSanDiegoFifteenTwelve") {                                                                 // 49
      return true;                                                                                                     // 50
    }                                                                                                                  // 51
  },                                                                                                                   // 52
  'createAcc': function (usm, psw) {                                                                                   // 53
    if (userCount.findOne({                                                                                            // 54
      count: 0                                                                                                         // 54
    })) {                                                                                                              // 54
      Accounts.createUser({                                                                                            // 55
        username: usm,                                                                                                 // 56
        password: psw                                                                                                  // 57
      });                                                                                                              // 55
    }                                                                                                                  // 59
                                                                                                                       //
    userCount.insert({                                                                                                 // 60
      count: 1                                                                                                         // 60
    });                                                                                                                // 60
    userCount.remove({                                                                                                 // 61
      count: 0                                                                                                         // 61
    });                                                                                                                // 61
  }                                                                                                                    // 62
});                                                                                                                    // 40
Meteor.methods({                                                                                                       // 65
  'post': function (imageData, title, content, cata) {                                                                 // 66
    if (Meteor.user()) {                                                                                               // 67
      // our data URL string from canvas.toDataUrl();                                                                  // 68
      var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                       // 69
                                                                                                                       //
      var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp            // 71
                                                                                                                       //
      var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
      var imageBuffer = new Buffer(base64Data, "base64");                                                              // 75
      var id = ShortId.generate();                                                                                     // 76
      var isoDate = new Date();                                                                                        // 77
      var res = isoDate.toString().split(" ");                                                                         // 78
      var date = res[1] + " " + res[2] + " " + res[3];                                                                 // 79
      var path = process.env["PWD"] + '/.static~/';                                                                    // 80
      var cata = cata;                                                                                                 // 82
                                                                                                                       //
      if (cata.includes("News")) {                                                                                     // 83
        cata = "News";                                                                                                 // 84
      } else if (cata.includes("Boss")) {                                                                              // 85
        cata = "Boss";                                                                                                 // 86
      } else {                                                                                                         // 87
        //if no catagory is supplied, assume it's just news                                                            // 88
        cata = "News";                                                                                                 // 89
      }                                                                                                                // 90
                                                                                                                       //
      posts.insert({                                                                                                   // 91
        _id: id,                                                                                                       // 91
        title: title,                                                                                                  // 91
        content: content,                                                                                              // 91
        imgPath: '/files/' + id + ".jpeg",                                                                             // 91
        date: date,                                                                                                    // 91
        cataSux: cata,                                                                                                 // 91
        date_created: new Date()                                                                                       // 91
      });                                                                                                              // 91
      counts.update({                                                                                                  // 92
        _id: "data"                                                                                                    // 92
      }, {                                                                                                             // 92
        $inc: {                                                                                                        // 92
          postCount: 1                                                                                                 // 92
        }                                                                                                              // 92
      });                                                                                                              // 92
                                                                                                                       //
      if (cata == "Boss") {                                                                                            // 93
        images.insert({                                                                                                // 94
          _id: id,                                                                                                     // 94
          title: title,                                                                                                // 94
          imgPath: '/files/' + id + ".jpeg",                                                                           // 94
          date_created: new Date()                                                                                     // 94
        });                                                                                                            // 94
      }                                                                                                                // 95
                                                                                                                       //
      if (imageData == '') {                                                                                           // 96
        var rand = Math.floor(Math.random() * 3) + 1;                                                                  // 97
        var img = '';                                                                                                  // 98
                                                                                                                       //
        if (rand == 1) {                                                                                               // 99
          img = 'default1.jpg';                                                                                        // 100
        } else if (rand == 2) {                                                                                        // 101
          img = 'default2.jpg';                                                                                        // 102
        } else {                                                                                                       // 103
          img = 'default3.jpg';                                                                                        // 104
        }                                                                                                              // 105
                                                                                                                       //
        posts.update({                                                                                                 // 106
          _id: id                                                                                                      // 106
        }, {                                                                                                           // 106
          $set: {                                                                                                      // 106
            imgPath: '/' + img                                                                                         // 106
          }                                                                                                            // 106
        });                                                                                                            // 106
                                                                                                                       //
        if (cata == "Boss") {                                                                                          // 107
          images.update({                                                                                              // 108
            _id: id                                                                                                    // 108
          }, {                                                                                                         // 108
            $set: {                                                                                                    // 108
              imgPath: '/' + img                                                                                       // 108
            }                                                                                                          // 108
          });                                                                                                          // 108
        }                                                                                                              // 109
      }                                                                                                                // 110
                                                                                                                       //
      var canReload = false;                                                                                           // 111
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 112
        if (err) throw err;                                                                                            // 114
        console.log('Done!');                                                                                          // 115
        canReload = true;                                                                                              // 116
      });                                                                                                              // 117
                                                                                                                       //
      if (canReload == true) {                                                                                         // 118
        return true;                                                                                                   // 119
      }                                                                                                                // 120
    }                                                                                                                  // 121
  },                                                                                                                   // 122
  'addRaid': function (title, bossName, bossStatN, bossStatH, bossStatM, addCC) {                                      // 123
    if (Meteor.user()) {                                                                                               // 124
      //okay, I'm posting each boss and it's stats in an array. I need to break it up to show it, but I'm sure I can do that Client side.
      raids.insert({                                                                                                   // 126
        title: title,                                                                                                  // 126
        bossName: bossName,                                                                                            // 126
        bossStatN: bossStatN,                                                                                          // 126
        bossStatH: bossStatH,                                                                                          // 126
        bossStatM: bossStatM,                                                                                          // 126
        length: addCC,                                                                                                 // 126
        date: new Date()                                                                                               // 126
      });                                                                                                              // 126
      counts.update({                                                                                                  // 127
        _id: "data"                                                                                                    // 127
      }, {                                                                                                             // 127
        $inc: {                                                                                                        // 127
          raidCount: 1                                                                                                 // 127
        }                                                                                                              // 127
      });                                                                                                              // 127
    }                                                                                                                  // 128
  },                                                                                                                   // 129
  'addQues': function (ques, quesCount) {                                                                              // 130
    if (Meteor.user()) {                                                                                               // 131
      questions.remove({});                                                                                            // 132
      questions.insert({                                                                                               // 133
        ques: ques,                                                                                                    // 133
        quesCount: quesCount                                                                                           // 133
      });                                                                                                              // 133
    }                                                                                                                  // 134
  }                                                                                                                    // 135
});                                                                                                                    // 65
Meteor.methods({                                                                                                       // 138
  'updateSite': function (specStatus, title, about, tabard, background) {                                              // 139
    if (Meteor.user()) {                                                                                               // 140
      var spec = ['dnB', 'dnU', 'dnF', 'dhH', 'dhV', 'drB', 'drF', 'drR', 'drG', 'huM', 'huS', 'huB', 'maF', 'maFr', 'maA', 'moM', 'moW', 'moB', 'paH', 'paR', 'paP', 'prS', 'prD', 'prH', 'roA', 'roS', 'roC', 'shE', 'shR', 'shEn', 'waA', 'waD', 'waDe', 'warA', 'warF', 'warP'];
      var images = [];                                                                                                 // 142
      var canReload = [];                                                                                              // 143
                                                                                                                       //
      if (tabard != '') {                                                                                              // 144
        images.push('tabard');                                                                                         // 145
        canReload.push('0');                                                                                           // 146
      }                                                                                                                // 147
                                                                                                                       //
      if (background != '') {                                                                                          // 148
        images.push('background');                                                                                     // 149
        canReload.push('0');                                                                                           // 150
      }                                                                                                                // 151
                                                                                                                       //
      var path = process.env["PWD"] + '/.static~/';                                                                    // 152
                                                                                                                       //
      for (var i = 0; i < images.length; i++) {                                                                        // 153
        console.log(images[i]); // our data URL string from canvas.toDataUrl();                                        // 154
                                                                                                                       //
        var imageDataUrl = eval(images[i]); // declare a regexp to match the non base64 first characters               // 156
                                                                                                                       //
        var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp          // 158
                                                                                                                       //
        var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
        var imageBuffer = new Buffer(base64Data, "base64");                                                            // 162
        fs.writeFile(path + images[i] + '.png', imageBuffer, function (err) {                                          // 163
          if (err) throw err;                                                                                          // 165
          console.log('Done!');                                                                                        // 166
          canReload[i] = 1;                                                                                            // 167
        });                                                                                                            // 168
        siteDetails.update({                                                                                           // 169
          _id: images[i]                                                                                               // 169
        }, {                                                                                                           // 169
          $set: {                                                                                                      // 169
            path: '/files/' + images[i] + ".png"                                                                       // 169
          }                                                                                                            // 169
        });                                                                                                            // 169
      }                                                                                                                // 170
                                                                                                                       //
      var reloadLength = canReload.length;                                                                             // 172
                                                                                                                       //
      if (reloadLength == null) {                                                                                      // 173
        return true;                                                                                                   // 174
      } else if (reloadLength == 0 && canReload[0] == 1) {                                                             // 175
        return true;                                                                                                   // 176
      } else if (reloadLength == 1 && canReload[0] == 1 && canReload[1] == 1) {                                        // 177
        return true;                                                                                                   // 178
      }                                                                                                                // 179
                                                                                                                       //
      siteDetails.update({                                                                                             // 181
        _id: 'recruiting'                                                                                              // 181
      }, {                                                                                                             // 181
        $set: {                                                                                                        // 181
          dnB: specStatus[0],                                                                                          // 181
          dnU: specStatus[1],                                                                                          // 181
          dnF: specStatus[2],                                                                                          // 181
          dhH: specStatus[3],                                                                                          // 181
          dhV: specStatus[4],                                                                                          // 181
          drB: specStatus[5],                                                                                          // 181
          drF: specStatus[6],                                                                                          // 181
          drR: specStatus[7],                                                                                          // 181
          drG: specStatus[8],                                                                                          // 181
          huM: specStatus[9],                                                                                          // 181
          huS: specStatus[10],                                                                                         // 181
          huB: specStatus[11],                                                                                         // 181
          maF: specStatus[12],                                                                                         // 181
          maFr: specStatus[13],                                                                                        // 181
          maA: specStatus[14],                                                                                         // 181
          moM: specStatus[15],                                                                                         // 181
          moW: specStatus[16],                                                                                         // 181
          moB: specStatus[17],                                                                                         // 181
          paH: specStatus[18],                                                                                         // 181
          paR: specStatus[19],                                                                                         // 181
          paP: specStatus[20],                                                                                         // 181
          prS: specStatus[21],                                                                                         // 181
          prD: specStatus[22],                                                                                         // 181
          prH: specStatus[23],                                                                                         // 181
          roA: specStatus[24],                                                                                         // 181
          roS: specStatus[25],                                                                                         // 181
          roC: specStatus[26],                                                                                         // 181
          shE: specStatus[27],                                                                                         // 181
          shR: specStatus[28],                                                                                         // 181
          shEn: specStatus[29],                                                                                        // 181
          waA: specStatus[30],                                                                                         // 181
          waD: specStatus[31],                                                                                         // 181
          waDe: specStatus[32],                                                                                        // 181
          warA: specStatus[33],                                                                                        // 181
          warF: specStatus[34],                                                                                        // 181
          warP: specStatus[35]                                                                                         // 181
        }                                                                                                              // 181
      });                                                                                                              // 181
                                                                                                                       //
      if (title != "" && title != undefined && title != null) {                                                        // 183
        siteDetails.update({                                                                                           // 184
          _id: 'title'                                                                                                 // 184
        }, {                                                                                                           // 184
          $set: {                                                                                                      // 184
            title: title                                                                                               // 184
          }                                                                                                            // 184
        });                                                                                                            // 184
      }                                                                                                                // 185
                                                                                                                       //
      if (about != "" && about != undefined && about != null) {                                                        // 186
        siteDetails.update({                                                                                           // 187
          _id: 'about'                                                                                                 // 187
        }, {                                                                                                           // 187
          $set: {                                                                                                      // 187
            about: about                                                                                               // 187
          }                                                                                                            // 187
        });                                                                                                            // 187
      }                                                                                                                // 188
    }                                                                                                                  // 189
  },                                                                                                                   // 190
  'updateRaid': function (title, bossName, bossStatN, bossStatH, bossStatM, addCE, target) {                           // 191
    if (Meteor.user()) {                                                                                               // 192
      if (addCE < 0) {                                                                                                 // 193
        addCE = 0;                                                                                                     // 194
      }                                                                                                                // 195
                                                                                                                       //
      raids.update({                                                                                                   // 196
        _id: target                                                                                                    // 196
      }, {                                                                                                             // 196
        $set: {                                                                                                        // 196
          title: title,                                                                                                // 196
          bossName: bossName,                                                                                          // 196
          bossStatN: bossStatN,                                                                                        // 196
          bossStatH: bossStatH,                                                                                        // 196
          bossStatM: bossStatM,                                                                                        // 196
          length: addCE                                                                                                // 196
        }                                                                                                              // 196
      });                                                                                                              // 196
    }                                                                                                                  // 197
  },                                                                                                                   // 198
  'updatePost': function (title, content, id, imageData, cata) {                                                       // 199
    if (Meteor.user()) {                                                                                               // 200
      // our data URL string from canvas.toDataUrl();                                                                  // 201
      if (imageData != '') {                                                                                           // 202
        var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                     // 203
                                                                                                                       //
        var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp          // 205
                                                                                                                       //
        var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
        var imageBuffer = new Buffer(base64Data, "base64");                                                            // 209
        var path = process.env["PWD"] + '/.static~/';                                                                  // 210
        posts.update({                                                                                                 // 211
          _id: id                                                                                                      // 211
        }, {                                                                                                           // 211
          $set: {                                                                                                      // 211
            imgPath: '/files/' + id + ".jpeg"                                                                          // 211
          }                                                                                                            // 211
        }); //if we find an image with our ID                                                                          // 211
                                                                                                                       //
        if (images.findOne({                                                                                           // 213
          _id: id                                                                                                      // 213
        })) {                                                                                                          // 213
          //update it                                                                                                  // 214
          images.update({                                                                                              // 215
            _id: id                                                                                                    // 215
          }, {                                                                                                         // 215
            $set: {                                                                                                    // 215
              imgPath: '/files/' + id + ".jpeg"                                                                        // 215
            }                                                                                                          // 215
          });                                                                                                          // 215
        }                                                                                                              // 216
      }                                                                                                                // 217
                                                                                                                       //
      if (cata == 'Boss Fight') {                                                                                      // 218
        cata = "Boss";                                                                                                 // 219
      }                                                                                                                // 220
                                                                                                                       //
      if (cata == "News") {                                                                                            // 221
        images.remove({                                                                                                // 222
          _id: id                                                                                                      // 222
        });                                                                                                            // 222
      } else if (cata == "Boss") {                                                                                     // 223
        var thisDate = posts.findOne({                                                                                 // 224
          _id: id                                                                                                      // 224
        }).date_created;                                                                                               // 224
                                                                                                                       //
        if (images.findOne({                                                                                           // 225
          _id: id                                                                                                      // 225
        })) {//do something                                                                                            // 225
        } else {                                                                                                       // 227
          var imagePath = posts.findOne({                                                                              // 228
            _id: id                                                                                                    // 228
          }).imgPath;                                                                                                  // 228
          images.insert({                                                                                              // 229
            _id: id,                                                                                                   // 229
            date_created: thisDate,                                                                                    // 229
            imgPath: imagePath                                                                                         // 229
          });                                                                                                          // 229
        }                                                                                                              // 230
      }                                                                                                                // 231
                                                                                                                       //
      console.log(cata);                                                                                               // 232
                                                                                                                       //
      if (cata != null) {                                                                                              // 233
        posts.update({                                                                                                 // 234
          _id: id                                                                                                      // 234
        }, {                                                                                                           // 234
          $set: {                                                                                                      // 234
            title: title,                                                                                              // 234
            content: content,                                                                                          // 234
            cataSux: cata                                                                                              // 234
          }                                                                                                            // 234
        });                                                                                                            // 234
      } else {                                                                                                         // 235
        posts.update({                                                                                                 // 236
          _id: id                                                                                                      // 236
        }, {                                                                                                           // 236
          $set: {                                                                                                      // 236
            title: title,                                                                                              // 236
            content: content                                                                                           // 236
          }                                                                                                            // 236
        });                                                                                                            // 236
      }                                                                                                                // 237
                                                                                                                       //
      var canReload = false;                                                                                           // 238
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 239
        if (err) throw err;                                                                                            // 241
        console.log('Done!');                                                                                          // 242
        canReload = true;                                                                                              // 243
      });                                                                                                              // 244
                                                                                                                       //
      if (canReload == true) {                                                                                         // 245
        return true;                                                                                                   // 246
      }                                                                                                                // 247
    }                                                                                                                  // 248
  },                                                                                                                   // 249
  'updateTwitch': function (apiKey, names, counts) {                                                                   // 250
    if (Meteor.user()) {                                                                                               // 251
      if (counts < 0) {                                                                                                // 252
        counts = 0;                                                                                                    // 253
      }                                                                                                                // 254
                                                                                                                       //
      if (twitch.findOne({                                                                                             // 255
        _id: 'data'                                                                                                    // 255
      })) {                                                                                                            // 255
        twitch.update({                                                                                                // 256
          _id: 'data'                                                                                                  // 256
        }, {                                                                                                           // 256
          $set: {                                                                                                      // 256
            apiKey: apiKey,                                                                                            // 256
            names: names,                                                                                              // 256
            counts: counts                                                                                             // 256
          }                                                                                                            // 256
        });                                                                                                            // 256
        console.log('updating');                                                                                       // 257
      } else {                                                                                                         // 258
        twitch.insert({                                                                                                // 259
          _id: "data",                                                                                                 // 259
          apiKey: apiKey,                                                                                              // 259
          names: names,                                                                                                // 259
          counts: counts                                                                                               // 259
        });                                                                                                            // 259
        console.log('inserting');                                                                                      // 260
      }                                                                                                                // 261
    }                                                                                                                  // 262
  }                                                                                                                    // 263
});                                                                                                                    // 138
Meteor.methods({                                                                                                       // 266
  'sendApp': function (questions, resps, amt) {                                                                        // 267
    var isoDate = new Date();                                                                                          // 268
    var res = isoDate.toString().split(" ");                                                                           // 269
    var date = res[1] + " " + res[2] + " " + res[3];                                                                   // 270
    apps.insert({                                                                                                      // 271
      username: resps[0].replace("::", ""),                                                                            // 271
      questions: questions,                                                                                            // 271
      resps: resps,                                                                                                    // 271
      amt: amt,                                                                                                        // 271
      date: date,                                                                                                      // 271
      date_created: new Date(),                                                                                        // 271
      cataSux: 'Unviewed'                                                                                              // 271
    });                                                                                                                // 271
    counts.update({                                                                                                    // 272
      _id: "data"                                                                                                      // 272
    }, {                                                                                                               // 272
      $inc: {                                                                                                          // 272
        appCount: 1                                                                                                    // 272
      }                                                                                                                // 272
    });                                                                                                                // 272
    return 'success';                                                                                                  // 273
  },                                                                                                                   // 274
  'updateApp': function (id, cata) {                                                                                   // 275
    apps.update({                                                                                                      // 276
      _id: id                                                                                                          // 276
    }, {                                                                                                               // 276
      $set: {                                                                                                          // 276
        cataSux: cata                                                                                                  // 276
      }                                                                                                                // 276
    });                                                                                                                // 276
    return "done";                                                                                                     // 277
  }                                                                                                                    // 278
});                                                                                                                    // 266
Meteor.methods({                                                                                                       // 281
  'deletePost': function (post) {                                                                                      // 282
    if (Meteor.user()) {                                                                                               // 283
      var filePath = process.env["PWD"] + '/.static~/' + post + '.jpeg';                                               // 284
      fs.unlinkSync(filePath);                                                                                         // 285
      posts.remove({                                                                                                   // 286
        _id: post                                                                                                      // 286
      });                                                                                                              // 286
      images.remove({                                                                                                  // 287
        _id: post                                                                                                      // 287
      });                                                                                                              // 287
      counts.update({                                                                                                  // 288
        _id: "data"                                                                                                    // 288
      }, {                                                                                                             // 288
        $inc: {                                                                                                        // 288
          postCount: -1                                                                                                // 288
        }                                                                                                              // 288
      });                                                                                                              // 288
    }                                                                                                                  // 289
  },                                                                                                                   // 290
  'deleteApp': function (appId) {                                                                                      // 291
    if (Meteor.user()) {                                                                                               // 292
      apps.remove({                                                                                                    // 293
        _id: appId                                                                                                     // 293
      });                                                                                                              // 293
      counts.update({                                                                                                  // 294
        _id: "data"                                                                                                    // 294
      }, {                                                                                                             // 294
        $inc: {                                                                                                        // 294
          appCount: -1                                                                                                 // 294
        }                                                                                                              // 294
      });                                                                                                              // 294
    }                                                                                                                  // 295
  },                                                                                                                   // 296
  'deleteRaid': function (raidId) {                                                                                    // 297
    if (Meteor.user()) {                                                                                               // 298
      raids.remove({                                                                                                   // 299
        _id: raidId                                                                                                    // 299
      });                                                                                                              // 299
      counts.update({                                                                                                  // 300
        _id: "data"                                                                                                    // 300
      }, {                                                                                                             // 300
        $inc: {                                                                                                        // 300
          raidCount: -1                                                                                                // 300
        }                                                                                                              // 300
      });                                                                                                              // 300
    }                                                                                                                  // 301
  }                                                                                                                    // 302
}); // Makes you SEO friendly baby                                                                                     // 281
                                                                                                                       //
WebApp.rawConnectHandlers.use(Meteor.bindEnvironment(function (req, res, next) {                                       // 306
  var title = siteDetails.findOne({                                                                                    // 308
    _id: 'title'                                                                                                       // 308
  }).title;                                                                                                            // 308
  var about = siteDetails.findOne({                                                                                    // 309
    _id: 'about'                                                                                                       // 309
  }).about;                                                                                                            // 309
  var tabard = siteDetails.findOne({                                                                                   // 310
    _id: 'tabard'                                                                                                      // 310
  }).path;                                                                                                             // 310
                                                                                                                       //
  if (title == undefined || title == null || title == '') {                                                            // 311
    req.dynamicHead = (req.dynamicHead || "") + '<title>OpenGuild-CMS | FinchMFG</title>';                             // 312
  } else {                                                                                                             // 313
    req.dynamicHead = (req.dynamicHead || "") + '<title>' + title + '</title>';                                        // 314
  }                                                                                                                    // 315
                                                                                                                       //
  if (about == undefined || about == null || about == '') {                                                            // 317
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="description" content="Awesome open source Wow Raid software by FinchMFG" />';
  } else {                                                                                                             // 319
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="description" content="' + about + '"/>';                  // 320
  }                                                                                                                    // 321
                                                                                                                       //
  if (tabard == undefined || tabard == null || tabard == '') {                                                         // 323
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="tabard" content="blessed" />';                            // 324
  } else {                                                                                                             // 325
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="tabard" content="' + tabard + '" />';                     // 326
  }                                                                                                                    // 327
                                                                                                                       //
  next();                                                                                                              // 328
})); //Meteor SEO SSR for BOTS mang                                                                                    // 329
                                                                                                                       //
var SeoRouter = Picker.filter(function (request, response) {                                                           // 333
  var botAgents = [/^facebookexternalhit/i, // Facebook                                                                // 334
  /^linkedinbot/i, // LinkedIn                                                                                         // 336
  /^twitterbot/i, // Twitter                                                                                           // 337
  /^slackbot-linkexpanding/i, // Slack                                                                                 // 338
  /^googlebot/i];                                                                                                      // 339
  return (/_escaped_fragment_/.test(request.url) || botAgents.some(function (i) {                                      // 342
      return i.test(request.headers['user-agent']);                                                                    // 342
    })                                                                                                                 // 342
  );                                                                                                                   // 342
});                                                                                                                    // 343
SeoRouter.route('/', function (params, request, response) {                                                            // 345
  SSR.compileTemplate('index', Assets.getText('index.html'));                                                          // 346
  Template.index.helpers({                                                                                             // 347
    getDocType: function () {                                                                                          // 348
      return "<!DOCTYPE html>";                                                                                        // 349
    },                                                                                                                 // 350
    title: function () {                                                                                               // 351
      return siteDetails.findOne({                                                                                     // 352
        _id: "title"                                                                                                   // 352
      }).title;                                                                                                        // 352
    },                                                                                                                 // 353
    meta: function () {                                                                                                // 354
      return siteDetails.findOne({                                                                                     // 355
        _id: "about"                                                                                                   // 355
      }).about;                                                                                                        // 355
    }                                                                                                                  // 356
  });                                                                                                                  // 347
  var html = SSR.render('index');                                                                                      // 359
  response.setHeader('Content-Type', 'text/html;charset=utf-8');                                                       // 361
  response.end(html);                                                                                                  // 362
}); //END                                                                                                              // 363
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/db.js");
require("./lib/globals.js");
require("./lib/routes.js");
require("./server/fileserver.js");
require("./server/publish.js");
require("./server/server.js");
//# sourceMappingURL=app.js.map
