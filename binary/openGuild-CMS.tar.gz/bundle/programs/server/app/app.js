var require = meteorInstall({"lib":{"db.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/db.js                                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
posts = new Mongo.Collection('posts');                                                                                 // 1
raids = new Mongo.Collection('raids');                                                                                 // 2
questions = new Mongo.Collection('questions');                                                                         // 3
apps = new Mongo.Collection('apps');                                                                                   // 4
userCount = new Mongo.Collection('userCount');                                                                         // 5
siteDetails = new Mongo.Collection('siteDetails');                                                                     // 6
twitch = new Mongo.Collection('twitch');                                                                               // 7
counts = new Mongo.Collection('counts');                                                                               // 9
images = new Mongo.Collection('images'); //denys anyone access to these (unless the above allow is met)                // 11
                                                                                                                       //
posts.deny({                                                                                                           // 14
  update: function () {                                                                                                // 15
    return true;                                                                                                       // 16
  },                                                                                                                   // 17
  insert: function () {                                                                                                // 19
    return true;                                                                                                       // 20
  }                                                                                                                    // 21
});                                                                                                                    // 14
twitch.deny({                                                                                                          // 24
  update: function () {                                                                                                // 25
    return true;                                                                                                       // 26
  },                                                                                                                   // 27
  insert: function () {                                                                                                // 29
    return true;                                                                                                       // 30
  }                                                                                                                    // 31
});                                                                                                                    // 24
images.deny({                                                                                                          // 34
  update: function () {                                                                                                // 35
    return true;                                                                                                       // 36
  },                                                                                                                   // 37
  insert: function () {                                                                                                // 39
    return true;                                                                                                       // 40
  }                                                                                                                    // 41
});                                                                                                                    // 34
apps.deny({                                                                                                            // 44
  update: function () {                                                                                                // 45
    return true;                                                                                                       // 46
  },                                                                                                                   // 47
  insert: function () {                                                                                                // 49
    return true;                                                                                                       // 50
  }                                                                                                                    // 51
});                                                                                                                    // 44
questions.deny({                                                                                                       // 54
  update: function () {                                                                                                // 55
    return true;                                                                                                       // 56
  },                                                                                                                   // 57
  insert: function () {                                                                                                // 59
    return true;                                                                                                       // 60
  }                                                                                                                    // 61
});                                                                                                                    // 54
raids.deny({                                                                                                           // 64
  update: function () {                                                                                                // 65
    return true;                                                                                                       // 66
  },                                                                                                                   // 67
  insert: function () {                                                                                                // 69
    return true;                                                                                                       // 70
  }                                                                                                                    // 71
});                                                                                                                    // 64
Meteor.users.deny({                                                                                                    // 74
  update: function () {                                                                                                // 75
    return true;                                                                                                       // 76
  }                                                                                                                    // 77
});                                                                                                                    // 74
userCount.deny({                                                                                                       // 80
  update: function () {                                                                                                // 81
    return true;                                                                                                       // 82
  },                                                                                                                   // 83
  insert: function () {                                                                                                // 85
    return true;                                                                                                       // 86
  }                                                                                                                    // 87
});                                                                                                                    // 80
siteDetails.deny({                                                                                                     // 90
  update: function () {                                                                                                // 91
    return true;                                                                                                       // 92
  },                                                                                                                   // 93
  insert: function () {                                                                                                // 95
    return true;                                                                                                       // 96
  }                                                                                                                    // 97
});                                                                                                                    // 90
counts.deny({                                                                                                          // 101
  update: function () {                                                                                                // 102
    return true;                                                                                                       // 103
  },                                                                                                                   // 104
  insert: function () {                                                                                                // 106
    return true;                                                                                                       // 107
  }                                                                                                                    // 108
});                                                                                                                    // 101
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"globals.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/globals.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//defaults to feed (home)                                                                                              // 1
currentPage = new ReactiveVar("feed"); //gets currentPost                                                              // 2
                                                                                                                       //
currentPost = new ReactiveVar(); //admin page location                                                                 // 5
                                                                                                                       //
adminLoc = new ReactiveVar("dash"); //the news filter                                                                  // 8
                                                                                                                       //
newsFilter = new ReactiveVar('news'); //for application viewing                                                        // 11
                                                                                                                       //
currentApp = new ReactiveVar('currentApp'); //for viewing existing raid                                                // 14
                                                                                                                       //
currentRaid = new ReactiveVar('currentRaid'); //for deleting stuff                                                     // 17
                                                                                                                       //
deleting = new ReactiveVar(''); //for loading image in carousel                                                        // 20
                                                                                                                       //
currentImage = new ReactiveVar(''); //for lazy loading                                                                 // 23
                                                                                                                       //
postLimitServer = new ReactiveVar(7); //test                                                                           // 26
                                                                                                                       //
imageTest = new ReactiveVar(); //get post ID from slug, load                                                           // 29
                                                                                                                       //
postFromSlug = new ReactiveVar();                                                                                      // 32
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routes.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
FlowRouter.route('/', {                                                                                                // 1
  name: 'home',                                                                                                        // 2
  subscriptions: function (params, queryParams) {                                                                      // 3
    // using Fast Render                                                                                               // 4
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 5
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 6
  },                                                                                                                   // 7
  action: function () {                                                                                                // 8
    BlazeLayout.render('index');                                                                                       // 9
  },                                                                                                                   // 10
  fastRender: true                                                                                                     // 11
});                                                                                                                    // 1
FlowRouter.route('/admin', {                                                                                           // 14
  name: "admin",                                                                                                       // 15
  action: function () {                                                                                                // 16
    if (Meteor.userId()) {                                                                                             // 17
      BlazeLayout.render('admin');                                                                                     // 18
    } else {                                                                                                           // 19
      BlazeLayout.render('signin');                                                                                    // 20
    }                                                                                                                  // 21
  }                                                                                                                    // 22
});                                                                                                                    // 14
FlowRouter.route('/admin-login', {                                                                                     // 25
  name: "login",                                                                                                       // 26
  action: function () {                                                                                                // 27
    BlazeLayout.render('signin');                                                                                      // 28
  }                                                                                                                    // 29
});                                                                                                                    // 25
FlowRouter.route('/p/:_id', {                                                                                          // 32
  name: 'post',                                                                                                        // 33
  subscriptions: function (params, queryParams) {                                                                      // 34
    // using Fast Render                                                                                               // 35
    this.register('posts2', Meteor.subscribe('posts2'));                                                               // 36
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 37
  },                                                                                                                   // 38
  action: function (params, queryParams) {                                                                             // 39
    BlazeLayout.render('index');                                                                                       // 40
    var theseParms = params._id;                                                                                       // 41
    currentPage.set('article');                                                                                        // 42
    currentPost.set(theseParms);                                                                                       // 43
    postFromSlug.set(params._id);                                                                                      // 44
  }                                                                                                                    // 45
});                                                                                                                    // 32
FlowRouter.route('/feed', {                                                                                            // 48
  name: 'home2',                                                                                                       // 49
  subscriptions: function (params, queryParams) {                                                                      // 50
    // using Fast Render                                                                                               // 51
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 52
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 53
  },                                                                                                                   // 54
  action: function (params, queryParams) {                                                                             // 55
    BlazeLayout.render('index');                                                                                       // 56
    currentPage.set('feed');                                                                                           // 57
  }                                                                                                                    // 58
});                                                                                                                    // 48
FlowRouter.route('/about', {                                                                                           // 61
  name: 'about',                                                                                                       // 62
  subscriptions: function (params, queryParams) {                                                                      // 63
    // using Fast Render                                                                                               // 64
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 65
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 66
  },                                                                                                                   // 67
  action: function (params, queryParams) {                                                                             // 68
    BlazeLayout.render('index');                                                                                       // 69
    currentPage.set('about');                                                                                          // 70
  }                                                                                                                    // 71
});                                                                                                                    // 61
FlowRouter.route('/apply', {                                                                                           // 74
  name: 'apply',                                                                                                       // 75
  subscriptions: function (params, queryParams) {                                                                      // 76
    // using Fast Render                                                                                               // 77
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 78
  },                                                                                                                   // 79
  action: function (params, queryParams) {                                                                             // 80
    BlazeLayout.render('index');                                                                                       // 81
    currentPage.set('apply');                                                                                          // 82
  }                                                                                                                    // 83
});                                                                                                                    // 74
FlowRouter.route('/streams', {                                                                                         // 86
  name: 'streams',                                                                                                     // 87
  subscriptions: function (params, queryParams) {                                                                      // 88
    // using Fast Render                                                                                               // 89
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 90
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 91
  },                                                                                                                   // 92
  action: function (params, queryParams) {                                                                             // 93
    BlazeLayout.render('index');                                                                                       // 94
    currentPage.set('streams');                                                                                        // 95
  }                                                                                                                    // 96
});                                                                                                                    // 86
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fileserver.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/fileserver.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var fs = Npm.require('fs');                                                                                            // 1
                                                                                                                       //
WebApp.connectHandlers.use(function (req, res, next) {                                                                 // 2
    var re = /^\/files\/(.*)$/.exec(req.url);                                                                          // 3
                                                                                                                       //
    if (re !== null) {                                                                                                 // 4
        // Only handle URLs that start with /uploads_url_prefix/*                                                      // 4
        var filePath = process.env.PWD + '/.static~/' + re[1];                                                         // 5
        var data = fs.readFileSync(filePath);                                                                          // 6
        res.writeHead(200, {                                                                                           // 7
            'Content-Type': 'image'                                                                                    // 8
        });                                                                                                            // 7
        res.write(data);                                                                                               // 10
        res.end();                                                                                                     // 11
    } else {                                                                                                           // 12
        // Other urls will have default behaviors                                                                      // 12
        next();                                                                                                        // 13
    }                                                                                                                  // 14
});                                                                                                                    // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publish.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publish("posts", function (limit) {                                                                             // 1
  var dl = limit || 7; //send data newest first to the client                                                          // 2
                                                                                                                       //
  return posts.find({}, {                                                                                              // 4
    sort: {                                                                                                            // 4
      date_created: -1                                                                                                 // 4
    },                                                                                                                 // 4
    limit: dl                                                                                                          // 4
  });                                                                                                                  // 4
});                                                                                                                    // 5
Meteor.publish("posts2", function (target) {                                                                           // 7
  return posts.find({                                                                                                  // 8
    _id: target                                                                                                        // 8
  });                                                                                                                  // 8
});                                                                                                                    // 9
Meteor.publish("raids", function () {                                                                                  // 11
  return raids.find({}, {                                                                                              // 12
    sort: {                                                                                                            // 12
      date: -1                                                                                                         // 12
    }                                                                                                                  // 12
  });                                                                                                                  // 12
});                                                                                                                    // 13
Meteor.publish("twitch", function () {                                                                                 // 15
  return twitch.find({});                                                                                              // 16
});                                                                                                                    // 17
Meteor.publish("questions", function () {                                                                              // 19
  return questions.find({});                                                                                           // 20
});                                                                                                                    // 21
Meteor.publish("siteDetails", function () {                                                                            // 23
  return siteDetails.find({});                                                                                         // 24
});                                                                                                                    // 25
Meteor.publish("counts", function () {                                                                                 // 27
  return counts.find({});                                                                                              // 28
});                                                                                                                    // 29
Meteor.publish("apps", function () {                                                                                   // 31
  return apps.find({}, {                                                                                               // 32
    sort: {                                                                                                            // 32
      date: -1                                                                                                         // 32
    }                                                                                                                  // 32
  });                                                                                                                  // 32
});                                                                                                                    // 33
Meteor.publish('images', function (search, post) {                                                                     // 36
  return images.find({}, {                                                                                             // 37
    sort: {                                                                                                            // 37
      date_created: -1                                                                                                 // 37
    },                                                                                                                 // 37
    limit: 7                                                                                                           // 37
  });                                                                                                                  // 37
});                                                                                                                    // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/server.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 1
  fs = Npm.require('fs');                                                                                              // 2
}); //checks to see if default site values are set, creates template for later                                         // 3
                                                                                                                       //
var needed = ['title', 'about', 'tabard', 'background', 'favicon', 'recruiting'];                                      // 7
var firstTime = 0;                                                                                                     // 8
                                                                                                                       //
for (var i = 0; i < needed.length; i++) {                                                                              // 9
  if (siteDetails.findOne({                                                                                            // 10
    _id: needed[i]                                                                                                     // 10
  })) {//horray!!                                                                                                      // 10
  } else {                                                                                                             // 12
    //lets create em                                                                                                   // 13
    siteDetails.insert({                                                                                               // 14
      _id: needed[i]                                                                                                   // 14
    });                                                                                                                // 14
    firstTime = 1;                                                                                                     // 15
  }                                                                                                                    // 16
}                                                                                                                      // 17
                                                                                                                       //
if (firstTime == 1) {                                                                                                  // 18
  //wow                                                                                                                // 19
  siteDetails.update({                                                                                                 // 20
    _id: 'recruiting'                                                                                                  // 20
  }, {                                                                                                                 // 20
    $set: {                                                                                                            // 20
      dnB: 'checked',                                                                                                  // 20
      dnU: 'checked',                                                                                                  // 20
      dnF: 'checked',                                                                                                  // 20
      dhH: 'checked',                                                                                                  // 20
      dhV: 'checked',                                                                                                  // 20
      drB: 'checked',                                                                                                  // 20
      drF: 'checked',                                                                                                  // 20
      drR: 'checked',                                                                                                  // 20
      drG: 'checked',                                                                                                  // 20
      huM: 'checked',                                                                                                  // 20
      huS: 'checked',                                                                                                  // 20
      huB: 'checked',                                                                                                  // 20
      maF: 'checked',                                                                                                  // 20
      maFr: 'checked',                                                                                                 // 20
      maA: 'checked',                                                                                                  // 20
      moM: 'checked',                                                                                                  // 20
      moW: 'checked',                                                                                                  // 20
      moB: 'checked',                                                                                                  // 20
      paH: 'checked',                                                                                                  // 20
      paR: 'checked',                                                                                                  // 20
      paP: 'checked',                                                                                                  // 20
      prS: 'checked',                                                                                                  // 20
      prD: 'checked',                                                                                                  // 20
      prH: 'checked',                                                                                                  // 20
      roA: 'checked',                                                                                                  // 20
      roS: 'checked',                                                                                                  // 20
      roC: 'checked',                                                                                                  // 20
      shE: 'checked',                                                                                                  // 20
      shR: 'checked',                                                                                                  // 20
      shEn: 'checked',                                                                                                 // 20
      waA: 'checked',                                                                                                  // 20
      waD: 'checked',                                                                                                  // 20
      waDe: 'checked',                                                                                                 // 20
      warA: 'checked',                                                                                                 // 20
      warF: 'checked',                                                                                                 // 20
      warP: 'checked'                                                                                                  // 20
    }                                                                                                                  // 20
  });                                                                                                                  // 20
  userCount.insert({                                                                                                   // 21
    count: 0                                                                                                           // 21
  });                                                                                                                  // 21
  counts.insert({                                                                                                      // 22
    _id: "data",                                                                                                       // 22
    postCount: 0,                                                                                                      // 22
    appCount: 0,                                                                                                       // 22
    raidCount: 0                                                                                                       // 22
  });                                                                                                                  // 22
  firstTime = 0;                                                                                                       // 23
} //creates initial account                                                                                            // 24
                                                                                                                       //
                                                                                                                       //
Meteor.methods({                                                                                                       // 28
  'accountCheck': function () {                                                                                        // 29
    if (userCount.findOne({                                                                                            // 30
      count: 0                                                                                                         // 30
    })) {                                                                                                              // 30
      return true;                                                                                                     // 31
    } else {                                                                                                           // 32
      return false;                                                                                                    // 33
    }                                                                                                                  // 34
  },                                                                                                                   // 35
  'phraseCheck': function (secret) {                                                                                   // 36
    if (secret == "SnowyTableSanDiegoFifteenTwelve") {                                                                 // 37
      return true;                                                                                                     // 38
    }                                                                                                                  // 39
  },                                                                                                                   // 40
  'createAcc': function (usm, psw) {                                                                                   // 41
    if (userCount.findOne({                                                                                            // 42
      count: 0                                                                                                         // 42
    })) {                                                                                                              // 42
      Accounts.createUser({                                                                                            // 43
        username: usm,                                                                                                 // 44
        password: psw                                                                                                  // 45
      });                                                                                                              // 43
    }                                                                                                                  // 47
                                                                                                                       //
    userCount.insert({                                                                                                 // 48
      count: 1                                                                                                         // 48
    });                                                                                                                // 48
    userCount.remove({                                                                                                 // 49
      count: 0                                                                                                         // 49
    });                                                                                                                // 49
  }                                                                                                                    // 50
});                                                                                                                    // 28
Meteor.methods({                                                                                                       // 53
  'post': function (imageData, title, content, cata) {                                                                 // 54
    if (Meteor.user()) {                                                                                               // 55
      // our data URL string from canvas.toDataUrl();                                                                  // 56
      var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                       // 57
                                                                                                                       //
      var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp            // 59
                                                                                                                       //
      var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
      var imageBuffer = new Buffer(base64Data, "base64");                                                              // 63
      var id = ShortId.generate();                                                                                     // 64
      var isoDate = new Date();                                                                                        // 65
      var res = isoDate.toString().split(" ");                                                                         // 66
      var date = res[1] + " " + res[2] + " " + res[3];                                                                 // 67
      var path = process.env["PWD"] + '/.static~/';                                                                    // 68
      var cata = cata;                                                                                                 // 70
                                                                                                                       //
      if (cata.includes("News")) {                                                                                     // 71
        cata = "News";                                                                                                 // 72
      } else if (cata.includes("Boss")) {                                                                              // 73
        cata = "Boss";                                                                                                 // 74
      } else {                                                                                                         // 75
        //if no catagory is supplied, assume it's just news                                                            // 76
        cata = "News";                                                                                                 // 77
      }                                                                                                                // 78
                                                                                                                       //
      posts.insert({                                                                                                   // 79
        _id: id,                                                                                                       // 79
        title: title,                                                                                                  // 79
        content: content,                                                                                              // 79
        imgPath: '/files/' + id + ".jpeg",                                                                             // 79
        date: date,                                                                                                    // 79
        cataSux: cata,                                                                                                 // 79
        date_created: new Date()                                                                                       // 79
      });                                                                                                              // 79
      counts.update({                                                                                                  // 80
        _id: "data"                                                                                                    // 80
      }, {                                                                                                             // 80
        $inc: {                                                                                                        // 80
          postCount: 1                                                                                                 // 80
        }                                                                                                              // 80
      });                                                                                                              // 80
                                                                                                                       //
      if (cata == "Boss") {                                                                                            // 81
        images.insert({                                                                                                // 82
          _id: id,                                                                                                     // 82
          title: title,                                                                                                // 82
          imgPath: '/files/' + id + ".jpeg",                                                                           // 82
          date_created: new Date()                                                                                     // 82
        });                                                                                                            // 82
      }                                                                                                                // 83
                                                                                                                       //
      if (imageData == '') {                                                                                           // 84
        var rand = Math.floor(Math.random() * 3) + 1;                                                                  // 85
        var img = '';                                                                                                  // 86
                                                                                                                       //
        if (rand == 1) {                                                                                               // 87
          img = 'default1.jpg';                                                                                        // 88
        } else if (rand == 2) {                                                                                        // 89
          img = 'default2.jpg';                                                                                        // 90
        } else {                                                                                                       // 91
          img = 'default3.jpg';                                                                                        // 92
        }                                                                                                              // 93
                                                                                                                       //
        posts.update({                                                                                                 // 94
          _id: id                                                                                                      // 94
        }, {                                                                                                           // 94
          $set: {                                                                                                      // 94
            imgPath: '/' + img                                                                                         // 94
          }                                                                                                            // 94
        });                                                                                                            // 94
                                                                                                                       //
        if (cata == "Boss") {                                                                                          // 95
          images.update({                                                                                              // 96
            _id: id                                                                                                    // 96
          }, {                                                                                                         // 96
            $set: {                                                                                                    // 96
              imgPath: '/' + img                                                                                       // 96
            }                                                                                                          // 96
          });                                                                                                          // 96
        }                                                                                                              // 97
      }                                                                                                                // 98
                                                                                                                       //
      var canReload = false;                                                                                           // 99
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 100
        if (err) throw err;                                                                                            // 102
        console.log('Done!');                                                                                          // 103
        canReload = true;                                                                                              // 104
      });                                                                                                              // 105
                                                                                                                       //
      if (canReload == true) {                                                                                         // 106
        return true;                                                                                                   // 107
      }                                                                                                                // 108
    }                                                                                                                  // 109
  },                                                                                                                   // 110
  'addRaid': function (title, bossName, bossStatN, bossStatH, bossStatM, addCC) {                                      // 111
    if (Meteor.user()) {                                                                                               // 112
      //okay, I'm posting each boss and it's stats in an array. I need to break it up to show it, but I'm sure I can do that Client side.
      raids.insert({                                                                                                   // 114
        title: title,                                                                                                  // 114
        bossName: bossName,                                                                                            // 114
        bossStatN: bossStatN,                                                                                          // 114
        bossStatH: bossStatH,                                                                                          // 114
        bossStatM: bossStatM,                                                                                          // 114
        length: addCC,                                                                                                 // 114
        date: new Date()                                                                                               // 114
      });                                                                                                              // 114
      counts.update({                                                                                                  // 115
        _id: "data"                                                                                                    // 115
      }, {                                                                                                             // 115
        $inc: {                                                                                                        // 115
          raidCount: 1                                                                                                 // 115
        }                                                                                                              // 115
      });                                                                                                              // 115
    }                                                                                                                  // 116
  },                                                                                                                   // 117
  'addQues': function (ques, quesCount) {                                                                              // 118
    if (Meteor.user()) {                                                                                               // 119
      questions.remove({});                                                                                            // 120
      questions.insert({                                                                                               // 121
        ques: ques,                                                                                                    // 121
        quesCount: quesCount                                                                                           // 121
      });                                                                                                              // 121
    }                                                                                                                  // 122
  }                                                                                                                    // 123
});                                                                                                                    // 53
Meteor.methods({                                                                                                       // 126
  'updateSite': function (specStatus, title, about, tabard, background) {                                              // 127
    if (Meteor.user()) {                                                                                               // 128
      var spec = ['dnB', 'dnU', 'dnF', 'dhH', 'dhV', 'drB', 'drF', 'drR', 'drG', 'huM', 'huS', 'huB', 'maF', 'maFr', 'maA', 'moM', 'moW', 'moB', 'paH', 'paR', 'paP', 'prS', 'prD', 'prH', 'roA', 'roS', 'roC', 'shE', 'shR', 'shEn', 'waA', 'waD', 'waDe', 'warA', 'warF', 'warP'];
      var images = [];                                                                                                 // 130
      var canReload = [];                                                                                              // 131
                                                                                                                       //
      if (tabard != '') {                                                                                              // 132
        images.push('tabard');                                                                                         // 133
        canReload.push('0');                                                                                           // 134
      }                                                                                                                // 135
                                                                                                                       //
      if (background != '') {                                                                                          // 136
        images.push('background');                                                                                     // 137
        canReload.push('0');                                                                                           // 138
      }                                                                                                                // 139
                                                                                                                       //
      var path = process.env["PWD"] + '/.static~/';                                                                    // 140
                                                                                                                       //
      for (var i = 0; i < images.length; i++) {                                                                        // 141
        console.log(images[i]); // our data URL string from canvas.toDataUrl();                                        // 142
                                                                                                                       //
        var imageDataUrl = eval(images[i]); // declare a regexp to match the non base64 first characters               // 144
                                                                                                                       //
        var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp          // 146
                                                                                                                       //
        var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
        var imageBuffer = new Buffer(base64Data, "base64");                                                            // 150
        fs.writeFile(path + images[i] + '.png', imageBuffer, function (err) {                                          // 151
          if (err) throw err;                                                                                          // 153
          console.log('Done!');                                                                                        // 154
          canReload[i] = 1;                                                                                            // 155
        });                                                                                                            // 156
        siteDetails.update({                                                                                           // 157
          _id: images[i]                                                                                               // 157
        }, {                                                                                                           // 157
          $set: {                                                                                                      // 157
            path: '/files/' + images[i] + ".png"                                                                       // 157
          }                                                                                                            // 157
        });                                                                                                            // 157
      }                                                                                                                // 158
                                                                                                                       //
      var reloadLength = canReload.length;                                                                             // 160
                                                                                                                       //
      if (reloadLength == null) {                                                                                      // 161
        return true;                                                                                                   // 162
      } else if (reloadLength == 0 && canReload[0] == 1) {                                                             // 163
        return true;                                                                                                   // 164
      } else if (reloadLength == 1 && canReload[0] == 1 && canReload[1] == 1) {                                        // 165
        return true;                                                                                                   // 166
      }                                                                                                                // 167
                                                                                                                       //
      siteDetails.update({                                                                                             // 169
        _id: 'recruiting'                                                                                              // 169
      }, {                                                                                                             // 169
        $set: {                                                                                                        // 169
          dnB: specStatus[0],                                                                                          // 169
          dnU: specStatus[1],                                                                                          // 169
          dnF: specStatus[2],                                                                                          // 169
          dhH: specStatus[3],                                                                                          // 169
          dhV: specStatus[4],                                                                                          // 169
          drB: specStatus[5],                                                                                          // 169
          drF: specStatus[6],                                                                                          // 169
          drR: specStatus[7],                                                                                          // 169
          drG: specStatus[8],                                                                                          // 169
          huM: specStatus[9],                                                                                          // 169
          huS: specStatus[10],                                                                                         // 169
          huB: specStatus[11],                                                                                         // 169
          maF: specStatus[12],                                                                                         // 169
          maFr: specStatus[13],                                                                                        // 169
          maA: specStatus[14],                                                                                         // 169
          moM: specStatus[15],                                                                                         // 169
          moW: specStatus[16],                                                                                         // 169
          moB: specStatus[17],                                                                                         // 169
          paH: specStatus[18],                                                                                         // 169
          paR: specStatus[19],                                                                                         // 169
          paP: specStatus[20],                                                                                         // 169
          prS: specStatus[21],                                                                                         // 169
          prD: specStatus[22],                                                                                         // 169
          prH: specStatus[23],                                                                                         // 169
          roA: specStatus[24],                                                                                         // 169
          roS: specStatus[25],                                                                                         // 169
          roC: specStatus[26],                                                                                         // 169
          shE: specStatus[27],                                                                                         // 169
          shR: specStatus[28],                                                                                         // 169
          shEn: specStatus[29],                                                                                        // 169
          waA: specStatus[30],                                                                                         // 169
          waD: specStatus[31],                                                                                         // 169
          waDe: specStatus[32],                                                                                        // 169
          warA: specStatus[33],                                                                                        // 169
          warF: specStatus[34],                                                                                        // 169
          warP: specStatus[35]                                                                                         // 169
        }                                                                                                              // 169
      });                                                                                                              // 169
                                                                                                                       //
      if (title != "" && title != undefined && title != null) {                                                        // 171
        siteDetails.update({                                                                                           // 172
          _id: 'title'                                                                                                 // 172
        }, {                                                                                                           // 172
          $set: {                                                                                                      // 172
            title: title                                                                                               // 172
          }                                                                                                            // 172
        });                                                                                                            // 172
      }                                                                                                                // 173
                                                                                                                       //
      if (about != "" && about != undefined && about != null) {                                                        // 174
        siteDetails.update({                                                                                           // 175
          _id: 'about'                                                                                                 // 175
        }, {                                                                                                           // 175
          $set: {                                                                                                      // 175
            about: about                                                                                               // 175
          }                                                                                                            // 175
        });                                                                                                            // 175
      }                                                                                                                // 176
    }                                                                                                                  // 177
  },                                                                                                                   // 178
  'updateRaid': function (title, bossName, bossStatN, bossStatH, bossStatM, addCE, target) {                           // 179
    if (Meteor.user()) {                                                                                               // 180
      if (addCE < 0) {                                                                                                 // 181
        addCE = 0;                                                                                                     // 182
      }                                                                                                                // 183
                                                                                                                       //
      raids.update({                                                                                                   // 184
        _id: target                                                                                                    // 184
      }, {                                                                                                             // 184
        $set: {                                                                                                        // 184
          title: title,                                                                                                // 184
          bossName: bossName,                                                                                          // 184
          bossStatN: bossStatN,                                                                                        // 184
          bossStatH: bossStatH,                                                                                        // 184
          bossStatM: bossStatM,                                                                                        // 184
          length: addCE                                                                                                // 184
        }                                                                                                              // 184
      });                                                                                                              // 184
    }                                                                                                                  // 185
  },                                                                                                                   // 186
  'updatePost': function (title, content, id, imageData, cata) {                                                       // 187
    if (Meteor.user()) {                                                                                               // 188
      // our data URL string from canvas.toDataUrl();                                                                  // 189
      if (imageData != '') {                                                                                           // 190
        var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                     // 191
                                                                                                                       //
        var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp          // 193
                                                                                                                       //
        var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
        var imageBuffer = new Buffer(base64Data, "base64");                                                            // 197
        var path = process.env["PWD"] + '/.static~/';                                                                  // 198
        posts.update({                                                                                                 // 199
          _id: id                                                                                                      // 199
        }, {                                                                                                           // 199
          $set: {                                                                                                      // 199
            imgPath: '/files/' + id + ".jpeg"                                                                          // 199
          }                                                                                                            // 199
        }); //if we find an image with our ID                                                                          // 199
                                                                                                                       //
        if (images.findOne({                                                                                           // 201
          _id: id                                                                                                      // 201
        })) {                                                                                                          // 201
          //update it                                                                                                  // 202
          images.update({                                                                                              // 203
            _id: id                                                                                                    // 203
          }, {                                                                                                         // 203
            $set: {                                                                                                    // 203
              imgPath: '/files/' + id + ".jpeg"                                                                        // 203
            }                                                                                                          // 203
          });                                                                                                          // 203
        }                                                                                                              // 204
      }                                                                                                                // 205
                                                                                                                       //
      if (cata == 'Boss Fight') {                                                                                      // 206
        cata = "Boss";                                                                                                 // 207
      }                                                                                                                // 208
                                                                                                                       //
      if (cata == "News") {                                                                                            // 209
        images.remove({                                                                                                // 210
          _id: id                                                                                                      // 210
        });                                                                                                            // 210
      } else if (cata == "Boss") {                                                                                     // 211
        var thisDate = posts.findOne({                                                                                 // 212
          _id: id                                                                                                      // 212
        }).date_created;                                                                                               // 212
                                                                                                                       //
        if (images.findOne({                                                                                           // 213
          _id: id                                                                                                      // 213
        })) {//do something                                                                                            // 213
        } else {                                                                                                       // 215
          var imagePath = posts.findOne({                                                                              // 216
            _id: id                                                                                                    // 216
          }).imgPath;                                                                                                  // 216
          images.insert({                                                                                              // 217
            _id: id,                                                                                                   // 217
            date_created: thisDate,                                                                                    // 217
            imgPath: imagePath                                                                                         // 217
          });                                                                                                          // 217
        }                                                                                                              // 218
      }                                                                                                                // 219
                                                                                                                       //
      console.log(cata);                                                                                               // 220
                                                                                                                       //
      if (cata != null) {                                                                                              // 221
        posts.update({                                                                                                 // 222
          _id: id                                                                                                      // 222
        }, {                                                                                                           // 222
          $set: {                                                                                                      // 222
            title: title,                                                                                              // 222
            content: content,                                                                                          // 222
            cataSux: cata                                                                                              // 222
          }                                                                                                            // 222
        });                                                                                                            // 222
      } else {                                                                                                         // 223
        posts.update({                                                                                                 // 224
          _id: id                                                                                                      // 224
        }, {                                                                                                           // 224
          $set: {                                                                                                      // 224
            title: title,                                                                                              // 224
            content: content                                                                                           // 224
          }                                                                                                            // 224
        });                                                                                                            // 224
      }                                                                                                                // 225
                                                                                                                       //
      var canReload = false;                                                                                           // 226
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 227
        if (err) throw err;                                                                                            // 229
        console.log('Done!');                                                                                          // 230
        canReload = true;                                                                                              // 231
      });                                                                                                              // 232
                                                                                                                       //
      if (canReload == true) {                                                                                         // 233
        return true;                                                                                                   // 234
      }                                                                                                                // 235
    }                                                                                                                  // 236
  },                                                                                                                   // 237
  'updateTwitch': function (apiKey, names, counts) {                                                                   // 238
    if (Meteor.user()) {                                                                                               // 239
      if (counts < 0) {                                                                                                // 240
        counts = 0;                                                                                                    // 241
      }                                                                                                                // 242
                                                                                                                       //
      if (twitch.findOne({                                                                                             // 243
        _id: 'data'                                                                                                    // 243
      })) {                                                                                                            // 243
        twitch.update({                                                                                                // 244
          _id: 'data'                                                                                                  // 244
        }, {                                                                                                           // 244
          $set: {                                                                                                      // 244
            apiKey: apiKey,                                                                                            // 244
            names: names,                                                                                              // 244
            counts: counts                                                                                             // 244
          }                                                                                                            // 244
        });                                                                                                            // 244
        console.log('updating');                                                                                       // 245
      } else {                                                                                                         // 246
        twitch.insert({                                                                                                // 247
          _id: "data",                                                                                                 // 247
          apiKey: apiKey,                                                                                              // 247
          names: names,                                                                                                // 247
          counts: counts                                                                                               // 247
        });                                                                                                            // 247
        console.log('inserting');                                                                                      // 248
      }                                                                                                                // 249
    }                                                                                                                  // 250
  }                                                                                                                    // 251
});                                                                                                                    // 126
Meteor.methods({                                                                                                       // 254
  'sendApp': function (questions, resps, amt) {                                                                        // 255
    apps.insert({                                                                                                      // 256
      username: resps[0].replace("::", ""),                                                                            // 256
      questions: questions,                                                                                            // 256
      resps: resps,                                                                                                    // 256
      amt: amt,                                                                                                        // 256
      date: new Date()                                                                                                 // 256
    });                                                                                                                // 256
    counts.update({                                                                                                    // 257
      _id: "data"                                                                                                      // 257
    }, {                                                                                                               // 257
      $inc: {                                                                                                          // 257
        appCount: 1                                                                                                    // 257
      }                                                                                                                // 257
    });                                                                                                                // 257
  }                                                                                                                    // 258
});                                                                                                                    // 254
Meteor.methods({                                                                                                       // 261
  'deletePost': function (post) {                                                                                      // 262
    if (Meteor.user()) {                                                                                               // 263
      var filePath = process.env["PWD"] + '/.static~/' + post + '.jpeg';                                               // 264
      fs.unlinkSync(filePath);                                                                                         // 265
      posts.remove({                                                                                                   // 266
        _id: post                                                                                                      // 266
      });                                                                                                              // 266
      images.remove({                                                                                                  // 267
        _id: post                                                                                                      // 267
      });                                                                                                              // 267
      counts.update({                                                                                                  // 268
        _id: "data"                                                                                                    // 268
      }, {                                                                                                             // 268
        $inc: {                                                                                                        // 268
          postCount: -1                                                                                                // 268
        }                                                                                                              // 268
      });                                                                                                              // 268
    }                                                                                                                  // 269
  },                                                                                                                   // 270
  'deleteApp': function (appId) {                                                                                      // 271
    if (Meteor.user()) {                                                                                               // 272
      apps.remove({                                                                                                    // 273
        _id: appId                                                                                                     // 273
      });                                                                                                              // 273
      counts.update({                                                                                                  // 274
        _id: "data"                                                                                                    // 274
      }, {                                                                                                             // 274
        $inc: {                                                                                                        // 274
          appCount: -1                                                                                                 // 274
        }                                                                                                              // 274
      });                                                                                                              // 274
    }                                                                                                                  // 275
  },                                                                                                                   // 276
  'deleteRaid': function (raidId) {                                                                                    // 277
    if (Meteor.user()) {                                                                                               // 278
      raids.remove({                                                                                                   // 279
        _id: raidId                                                                                                    // 279
      });                                                                                                              // 279
      counts.update({                                                                                                  // 280
        _id: "data"                                                                                                    // 280
      }, {                                                                                                             // 280
        $inc: {                                                                                                        // 280
          raidCount: -1                                                                                                // 280
        }                                                                                                              // 280
      });                                                                                                              // 280
    }                                                                                                                  // 281
  }                                                                                                                    // 282
}); // Makes you SEO friendly baby                                                                                     // 261
                                                                                                                       //
WebApp.rawConnectHandlers.use(Meteor.bindEnvironment(function (req, res, next) {                                       // 286
  var title = siteDetails.findOne({                                                                                    // 288
    _id: 'title'                                                                                                       // 288
  }).title;                                                                                                            // 288
  var about = siteDetails.findOne({                                                                                    // 289
    _id: 'about'                                                                                                       // 289
  }).about;                                                                                                            // 289
  var tabard = siteDetails.findOne({                                                                                   // 290
    _id: 'tabard'                                                                                                      // 290
  }).path;                                                                                                             // 290
                                                                                                                       //
  if (title == undefined || title == null || title == '') {                                                            // 291
    req.dynamicHead = (req.dynamicHead || "") + '<title>OpenGuild-CMS | FinchMFG</title>';                             // 292
  } else {                                                                                                             // 293
    req.dynamicHead = (req.dynamicHead || "") + '<title>' + title + '</title>';                                        // 294
  }                                                                                                                    // 295
                                                                                                                       //
  if (about == undefined || about == null || about == '') {                                                            // 297
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="description" content="Awesome open source Wow Raid software by FinchMFG" />';
  } else {                                                                                                             // 299
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="description" content="' + about + '"/>';                  // 300
  }                                                                                                                    // 301
                                                                                                                       //
  if (tabard == undefined || tabard == null || tabard == '') {                                                         // 303
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="tabard" content="blessed" />';                            // 304
  } else {                                                                                                             // 305
    req.dynamicHead = (req.dynamicHead || "") + '<meta name="tabard" content="' + tabard + '" />';                     // 306
  }                                                                                                                    // 307
                                                                                                                       //
  next();                                                                                                              // 308
})); //Meteor SEO SSR for BOTS mang                                                                                    // 309
                                                                                                                       //
var SeoRouter = Picker.filter(function (request, response) {                                                           // 313
  var botAgents = [/^facebookexternalhit/i, // Facebook                                                                // 314
  /^linkedinbot/i, // LinkedIn                                                                                         // 316
  /^twitterbot/i, // Twitter                                                                                           // 317
  /^slackbot-linkexpanding/i, // Slack                                                                                 // 318
  /^googlebot/i];                                                                                                      // 319
  return (/_escaped_fragment_/.test(request.url) || botAgents.some(function (i) {                                      // 322
      return i.test(request.headers['user-agent']);                                                                    // 322
    })                                                                                                                 // 322
  );                                                                                                                   // 322
});                                                                                                                    // 323
SeoRouter.route('/', function (params, request, response) {                                                            // 325
  SSR.compileTemplate('index', Assets.getText('index.html'));                                                          // 326
  Template.index.helpers({                                                                                             // 327
    getDocType: function () {                                                                                          // 328
      return "<!DOCTYPE html>";                                                                                        // 329
    },                                                                                                                 // 330
    title: function () {                                                                                               // 331
      return siteDetails.findOne({                                                                                     // 332
        _id: "title"                                                                                                   // 332
      }).title;                                                                                                        // 332
    },                                                                                                                 // 333
    meta: function () {                                                                                                // 334
      return siteDetails.findOne({                                                                                     // 335
        _id: "about"                                                                                                   // 335
      }).about;                                                                                                        // 335
    }                                                                                                                  // 336
  });                                                                                                                  // 327
  var html = SSR.render('index');                                                                                      // 339
  response.setHeader('Content-Type', 'text/html;charset=utf-8');                                                       // 341
  response.end(html);                                                                                                  // 342
}); //END                                                                                                              // 343
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/db.js");
require("./lib/globals.js");
require("./lib/routes.js");
require("./server/fileserver.js");
require("./server/publish.js");
require("./server/server.js");
//# sourceMappingURL=app.js.map
