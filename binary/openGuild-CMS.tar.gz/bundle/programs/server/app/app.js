var require = meteorInstall({"lib":{"db.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/db.js                                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
posts = new Mongo.Collection('posts');                                                                                 // 1
raids = new Mongo.Collection('raids');                                                                                 // 2
questions = new Mongo.Collection('questions');                                                                         // 3
apps = new Mongo.Collection('apps');                                                                                   // 4
userCount = new Mongo.Collection('userCount');                                                                         // 5
siteDetails = new Mongo.Collection('siteDetails');                                                                     // 6
twitch = new Mongo.Collection('twitch');                                                                               // 7
counts = new Mongo.Collection('counts');                                                                               // 9
images = new Mongo.Collection('images'); //denys anyone access to these (unless the above allow is met)                // 11
                                                                                                                       //
posts.deny({                                                                                                           // 14
  update: function () {                                                                                                // 15
    return true;                                                                                                       // 16
  },                                                                                                                   // 17
  insert: function () {                                                                                                // 19
    return true;                                                                                                       // 20
  }                                                                                                                    // 21
});                                                                                                                    // 14
twitch.deny({                                                                                                          // 24
  update: function () {                                                                                                // 25
    return true;                                                                                                       // 26
  },                                                                                                                   // 27
  insert: function () {                                                                                                // 29
    return true;                                                                                                       // 30
  }                                                                                                                    // 31
});                                                                                                                    // 24
images.deny({                                                                                                          // 34
  update: function () {                                                                                                // 35
    return true;                                                                                                       // 36
  },                                                                                                                   // 37
  insert: function () {                                                                                                // 39
    return true;                                                                                                       // 40
  }                                                                                                                    // 41
});                                                                                                                    // 34
apps.deny({                                                                                                            // 44
  update: function () {                                                                                                // 45
    return true;                                                                                                       // 46
  },                                                                                                                   // 47
  insert: function () {                                                                                                // 49
    return true;                                                                                                       // 50
  }                                                                                                                    // 51
});                                                                                                                    // 44
questions.deny({                                                                                                       // 54
  update: function () {                                                                                                // 55
    return true;                                                                                                       // 56
  },                                                                                                                   // 57
  insert: function () {                                                                                                // 59
    return true;                                                                                                       // 60
  }                                                                                                                    // 61
});                                                                                                                    // 54
raids.deny({                                                                                                           // 64
  update: function () {                                                                                                // 65
    return true;                                                                                                       // 66
  },                                                                                                                   // 67
  insert: function () {                                                                                                // 69
    return true;                                                                                                       // 70
  }                                                                                                                    // 71
});                                                                                                                    // 64
Meteor.users.deny({                                                                                                    // 74
  update: function () {                                                                                                // 75
    return true;                                                                                                       // 76
  }                                                                                                                    // 77
});                                                                                                                    // 74
userCount.deny({                                                                                                       // 80
  update: function () {                                                                                                // 81
    return true;                                                                                                       // 82
  },                                                                                                                   // 83
  insert: function () {                                                                                                // 85
    return true;                                                                                                       // 86
  }                                                                                                                    // 87
});                                                                                                                    // 80
siteDetails.deny({                                                                                                     // 90
  update: function () {                                                                                                // 91
    return true;                                                                                                       // 92
  },                                                                                                                   // 93
  insert: function () {                                                                                                // 95
    return true;                                                                                                       // 96
  }                                                                                                                    // 97
});                                                                                                                    // 90
counts.deny({                                                                                                          // 101
  update: function () {                                                                                                // 102
    return true;                                                                                                       // 103
  },                                                                                                                   // 104
  insert: function () {                                                                                                // 106
    return true;                                                                                                       // 107
  }                                                                                                                    // 108
});                                                                                                                    // 101
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"globals.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/globals.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//defaults to feed (home)                                                                                              // 1
currentPage = new ReactiveVar("feed"); //gets currentPost                                                              // 2
                                                                                                                       //
currentPost = new ReactiveVar(); //admin page location                                                                 // 5
                                                                                                                       //
adminLoc = new ReactiveVar("dash"); //the news filter                                                                  // 8
                                                                                                                       //
newsFilter = new ReactiveVar('news'); //for application viewing                                                        // 11
                                                                                                                       //
currentApp = new ReactiveVar('currentApp'); //for viewing existing raid                                                // 14
                                                                                                                       //
currentRaid = new ReactiveVar('currentRaid'); //for deleting stuff                                                     // 17
                                                                                                                       //
deleting = new ReactiveVar(''); //for loading image in carousel                                                        // 20
                                                                                                                       //
currentImage = new ReactiveVar(''); //for lazy loading                                                                 // 23
                                                                                                                       //
postLimitServer = new ReactiveVar(7); //test                                                                           // 26
                                                                                                                       //
imageTest = new ReactiveVar();                                                                                         // 29
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routes.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
FlowRouter.route('/', {                                                                                                // 1
  name: 'home',                                                                                                        // 2
  subscriptions: function (params, queryParams) {                                                                      // 3
    // using Fast Render                                                                                               // 4
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 5
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 6
  },                                                                                                                   // 7
  action: function () {                                                                                                // 8
    BlazeLayout.render('index');                                                                                       // 9
  },                                                                                                                   // 10
  fastRender: true                                                                                                     // 11
});                                                                                                                    // 1
FlowRouter.route('/admin', {                                                                                           // 14
  name: "admin",                                                                                                       // 15
  action: function () {                                                                                                // 16
    if (Meteor.userId()) {                                                                                             // 17
      BlazeLayout.render('admin');                                                                                     // 18
    } else {                                                                                                           // 19
      BlazeLayout.render('signin');                                                                                    // 20
    }                                                                                                                  // 21
  }                                                                                                                    // 22
});                                                                                                                    // 14
FlowRouter.route('/admin-login', {                                                                                     // 25
  name: "login",                                                                                                       // 26
  action: function () {                                                                                                // 27
    BlazeLayout.render('signin');                                                                                      // 28
  }                                                                                                                    // 29
});                                                                                                                    // 25
FlowRouter.route('/p/:_id', {                                                                                          // 32
  name: 'post',                                                                                                        // 33
  subscriptions: function (params, queryParams) {                                                                      // 34
    // using Fast Render                                                                                               // 35
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 36
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 37
  },                                                                                                                   // 38
  action: function (params, queryParams) {                                                                             // 39
    BlazeLayout.render('index');                                                                                       // 40
    var theseParms = params._id;                                                                                       // 41
    currentPage.set('article');                                                                                        // 42
    currentPost.set(theseParms);                                                                                       // 43
  }                                                                                                                    // 44
});                                                                                                                    // 32
FlowRouter.route('/feed', {                                                                                            // 47
  name: 'home2',                                                                                                       // 48
  subscriptions: function (params, queryParams) {                                                                      // 49
    // using Fast Render                                                                                               // 50
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 51
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 52
  },                                                                                                                   // 53
  action: function (params, queryParams) {                                                                             // 54
    BlazeLayout.render('index');                                                                                       // 55
    currentPage.set('feed');                                                                                           // 56
  }                                                                                                                    // 57
});                                                                                                                    // 47
FlowRouter.route('/about', {                                                                                           // 60
  name: 'about',                                                                                                       // 61
  subscriptions: function (params, queryParams) {                                                                      // 62
    // using Fast Render                                                                                               // 63
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 64
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 65
  },                                                                                                                   // 66
  action: function (params, queryParams) {                                                                             // 67
    BlazeLayout.render('index');                                                                                       // 68
    currentPage.set('about');                                                                                          // 69
  }                                                                                                                    // 70
});                                                                                                                    // 60
FlowRouter.route('/apply', {                                                                                           // 73
  name: 'apply',                                                                                                       // 74
  subscriptions: function (params, queryParams) {                                                                      // 75
    // using Fast Render                                                                                               // 76
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 77
  },                                                                                                                   // 78
  action: function (params, queryParams) {                                                                             // 79
    BlazeLayout.render('index');                                                                                       // 80
    currentPage.set('feed');                                                                                           // 81
  }                                                                                                                    // 82
});                                                                                                                    // 73
FlowRouter.route('/streams', {                                                                                         // 85
  name: 'streams',                                                                                                     // 86
  subscriptions: function (params, queryParams) {                                                                      // 87
    // using Fast Render                                                                                               // 88
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 89
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 90
  },                                                                                                                   // 91
  action: function (params, queryParams) {                                                                             // 92
    BlazeLayout.render('index');                                                                                       // 93
    currentPage.set('streams');                                                                                        // 94
  }                                                                                                                    // 95
});                                                                                                                    // 85
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fileserver.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/fileserver.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var fs = Npm.require('fs');                                                                                            // 1
                                                                                                                       //
WebApp.connectHandlers.use(function (req, res, next) {                                                                 // 2
    var re = /^\/files\/(.*)$/.exec(req.url);                                                                          // 3
                                                                                                                       //
    if (re !== null) {                                                                                                 // 4
        // Only handle URLs that start with /uploads_url_prefix/*                                                      // 4
        var filePath = process.env.PWD + '/.static~/' + re[1];                                                         // 5
        var data = fs.readFileSync(filePath);                                                                          // 6
        res.writeHead(200, {                                                                                           // 7
            'Content-Type': 'image'                                                                                    // 8
        });                                                                                                            // 7
        res.write(data);                                                                                               // 10
        res.end();                                                                                                     // 11
    } else {                                                                                                           // 12
        // Other urls will have default behaviors                                                                      // 12
        next();                                                                                                        // 13
    }                                                                                                                  // 14
});                                                                                                                    // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publish.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publish("posts", function (limit) {                                                                             // 1
  var dl = limit || 7; //send data newest first to the client                                                          // 2
                                                                                                                       //
  if (!this.userId) {                                                                                                  // 4
    return posts.find({}, {                                                                                            // 5
      sort: {                                                                                                          // 5
        date_created: -1                                                                                               // 5
      },                                                                                                               // 5
      limit: dl                                                                                                        // 5
    });                                                                                                                // 5
  } else {                                                                                                             // 6
    return posts.find({});                                                                                             // 7
  }                                                                                                                    // 8
});                                                                                                                    // 9
Meteor.publish("raids", function () {                                                                                  // 11
  return raids.find({}, {                                                                                              // 12
    sort: {                                                                                                            // 12
      date: -1                                                                                                         // 12
    }                                                                                                                  // 12
  });                                                                                                                  // 12
});                                                                                                                    // 13
Meteor.publish("twitch", function () {                                                                                 // 15
  return twitch.find({});                                                                                              // 16
});                                                                                                                    // 17
Meteor.publish("questions", function () {                                                                              // 19
  return questions.find({});                                                                                           // 20
});                                                                                                                    // 21
Meteor.publish("siteDetails", function () {                                                                            // 23
  return siteDetails.find({});                                                                                         // 24
});                                                                                                                    // 25
Meteor.publish("counts", function () {                                                                                 // 27
  return counts.find({});                                                                                              // 28
});                                                                                                                    // 29
Meteor.publish("apps", function () {                                                                                   // 31
  return apps.find({}, {                                                                                               // 32
    sort: {                                                                                                            // 32
      date: -1                                                                                                         // 32
    }                                                                                                                  // 32
  });                                                                                                                  // 32
});                                                                                                                    // 33
Meteor.publish('images', function (search, post) {                                                                     // 36
  return images.find({}, {                                                                                             // 37
    sort: {                                                                                                            // 37
      date_created: -1                                                                                                 // 37
    },                                                                                                                 // 37
    limit: 7                                                                                                           // 37
  });                                                                                                                  // 37
});                                                                                                                    // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/server.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 1
  fs = Npm.require('fs');                                                                                              // 2
}); //checks to see if default site values are set, creates template for later                                         // 3
                                                                                                                       //
var needed = ['title', 'about', 'tabard', 'background', 'favicon', 'recruiting'];                                      // 7
var firstTime = 0;                                                                                                     // 8
                                                                                                                       //
for (var i = 0; i < needed.length; i++) {                                                                              // 9
  if (siteDetails.findOne({                                                                                            // 10
    _id: needed[i]                                                                                                     // 10
  })) {//horray!!                                                                                                      // 10
  } else {                                                                                                             // 12
    //lets create em                                                                                                   // 13
    siteDetails.insert({                                                                                               // 14
      _id: needed[i]                                                                                                   // 14
    });                                                                                                                // 14
    firstTime = 1;                                                                                                     // 15
  }                                                                                                                    // 16
}                                                                                                                      // 17
                                                                                                                       //
if (firstTime == 1) {                                                                                                  // 18
  //wow                                                                                                                // 19
  siteDetails.update({                                                                                                 // 20
    _id: 'recruiting'                                                                                                  // 20
  }, {                                                                                                                 // 20
    $set: {                                                                                                            // 20
      dnB: 'checked',                                                                                                  // 20
      dnU: 'checked',                                                                                                  // 20
      dnF: 'checked',                                                                                                  // 20
      dhH: 'checked',                                                                                                  // 20
      dhV: 'checked',                                                                                                  // 20
      drB: 'checked',                                                                                                  // 20
      drF: 'checked',                                                                                                  // 20
      drR: 'checked',                                                                                                  // 20
      drG: 'checked',                                                                                                  // 20
      huM: 'checked',                                                                                                  // 20
      huS: 'checked',                                                                                                  // 20
      huB: 'checked',                                                                                                  // 20
      maF: 'checked',                                                                                                  // 20
      maFr: 'checked',                                                                                                 // 20
      maA: 'checked',                                                                                                  // 20
      moM: 'checked',                                                                                                  // 20
      moW: 'checked',                                                                                                  // 20
      moB: 'checked',                                                                                                  // 20
      paH: 'checked',                                                                                                  // 20
      paR: 'checked',                                                                                                  // 20
      paP: 'checked',                                                                                                  // 20
      prS: 'checked',                                                                                                  // 20
      prD: 'checked',                                                                                                  // 20
      prH: 'checked',                                                                                                  // 20
      roA: 'checked',                                                                                                  // 20
      roS: 'checked',                                                                                                  // 20
      roC: 'checked',                                                                                                  // 20
      shE: 'checked',                                                                                                  // 20
      shR: 'checked',                                                                                                  // 20
      shEn: 'checked',                                                                                                 // 20
      waA: 'checked',                                                                                                  // 20
      waD: 'checked',                                                                                                  // 20
      waDe: 'checked',                                                                                                 // 20
      warA: 'checked',                                                                                                 // 20
      warF: 'checked',                                                                                                 // 20
      warP: 'checked'                                                                                                  // 20
    }                                                                                                                  // 20
  });                                                                                                                  // 20
  userCount.insert({                                                                                                   // 21
    count: 0                                                                                                           // 21
  });                                                                                                                  // 21
  counts.insert({                                                                                                      // 22
    _id: "data",                                                                                                       // 22
    postCount: 0,                                                                                                      // 22
    appCount: 0,                                                                                                       // 22
    raidCount: 0                                                                                                       // 22
  });                                                                                                                  // 22
  firstTime = 0;                                                                                                       // 23
} //creates initial account                                                                                            // 24
                                                                                                                       //
                                                                                                                       //
Meteor.methods({                                                                                                       // 28
  'accountCheck': function () {                                                                                        // 29
    if (userCount.findOne({                                                                                            // 30
      count: 0                                                                                                         // 30
    })) {                                                                                                              // 30
      return true;                                                                                                     // 31
    } else {                                                                                                           // 32
      return false;                                                                                                    // 33
    }                                                                                                                  // 34
  },                                                                                                                   // 35
  'phraseCheck': function (secret) {                                                                                   // 36
    if (secret == "SnowyTableSanDiegoFifteenTwelve") {                                                                 // 37
      return true;                                                                                                     // 38
    }                                                                                                                  // 39
  },                                                                                                                   // 40
  'createAcc': function (usm, psw) {                                                                                   // 41
    Accounts.createUser({                                                                                              // 42
      username: usm,                                                                                                   // 43
      password: psw                                                                                                    // 44
    });                                                                                                                // 42
    userCount.insert({                                                                                                 // 46
      count: 1                                                                                                         // 46
    });                                                                                                                // 46
    userCount.remove({                                                                                                 // 47
      count: 0                                                                                                         // 47
    });                                                                                                                // 47
  }                                                                                                                    // 48
});                                                                                                                    // 28
Meteor.methods({                                                                                                       // 51
  'post': function (imageData, title, content, cata) {                                                                 // 52
    if (Meteor.user()) {                                                                                               // 53
      // our data URL string from canvas.toDataUrl();                                                                  // 54
      var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                       // 55
                                                                                                                       //
      var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp            // 57
                                                                                                                       //
      var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
      var imageBuffer = new Buffer(base64Data, "base64");                                                              // 61
      var id = ShortId.generate();                                                                                     // 62
      var isoDate = new Date();                                                                                        // 63
      var res = isoDate.toString().split(" ");                                                                         // 64
      var date = res[1] + " " + res[2] + " " + res[3];                                                                 // 65
      var path = process.env["PWD"] + '/.static~/';                                                                    // 66
      var cata = cata;                                                                                                 // 68
                                                                                                                       //
      if (cata.includes("News")) {                                                                                     // 69
        cata = "News";                                                                                                 // 70
      } else if (cata.includes("Boss")) {                                                                              // 71
        cata = "Boss";                                                                                                 // 72
      } else {                                                                                                         // 73
        //if no catagory is supplied, assume it's just news                                                            // 74
        cata = "News";                                                                                                 // 75
      }                                                                                                                // 76
                                                                                                                       //
      posts.insert({                                                                                                   // 77
        _id: id,                                                                                                       // 77
        title: title,                                                                                                  // 77
        content: content,                                                                                              // 77
        imgPath: '/files/' + id + ".jpeg",                                                                             // 77
        date: date,                                                                                                    // 77
        cataSux: cata,                                                                                                 // 77
        date_created: new Date()                                                                                       // 77
      });                                                                                                              // 77
      counts.update({                                                                                                  // 78
        _id: "data"                                                                                                    // 78
      }, {                                                                                                             // 78
        $inc: {                                                                                                        // 78
          postCount: 1                                                                                                 // 78
        }                                                                                                              // 78
      });                                                                                                              // 78
                                                                                                                       //
      if (cata == "Boss") {                                                                                            // 79
        images.insert({                                                                                                // 80
          _id: id,                                                                                                     // 80
          title: title,                                                                                                // 80
          imgPath: '/files/' + id + ".jpeg",                                                                           // 80
          date_created: new Date()                                                                                     // 80
        });                                                                                                            // 80
      }                                                                                                                // 81
                                                                                                                       //
      if (imageData == '') {                                                                                           // 82
        var rand = Math.floor(Math.random() * 3) + 1;                                                                  // 83
        var img = '';                                                                                                  // 84
                                                                                                                       //
        if (rand == 1) {                                                                                               // 85
          img = 'default1.jpg';                                                                                        // 86
        } else if (rand == 2) {                                                                                        // 87
          img = 'default2.jpg';                                                                                        // 88
        } else {                                                                                                       // 89
          img = 'default3.jpg';                                                                                        // 90
        }                                                                                                              // 91
                                                                                                                       //
        posts.update({                                                                                                 // 92
          _id: id                                                                                                      // 92
        }, {                                                                                                           // 92
          $set: {                                                                                                      // 92
            imgPath: '/' + img                                                                                         // 92
          }                                                                                                            // 92
        });                                                                                                            // 92
                                                                                                                       //
        if (cata == "Boss") {                                                                                          // 93
          images.update({                                                                                              // 94
            _id: id                                                                                                    // 94
          }, {                                                                                                         // 94
            $set: {                                                                                                    // 94
              imgPath: '/' + img                                                                                       // 94
            }                                                                                                          // 94
          });                                                                                                          // 94
        }                                                                                                              // 95
      }                                                                                                                // 96
                                                                                                                       //
      var canReload = false;                                                                                           // 97
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 98
        if (err) throw err;                                                                                            // 100
        console.log('Done!');                                                                                          // 101
        canReload = true;                                                                                              // 102
      });                                                                                                              // 103
                                                                                                                       //
      if (canReload == true) {                                                                                         // 104
        return true;                                                                                                   // 105
      }                                                                                                                // 106
    }                                                                                                                  // 107
  },                                                                                                                   // 108
  'addRaid': function (title, bossName, bossStatN, bossStatH, bossStatM, addCC) {                                      // 109
    if (Meteor.user()) {                                                                                               // 110
      //okay, I'm posting each boss and it's stats in an array. I need to break it up to show it, but I'm sure I can do that Client side.
      raids.insert({                                                                                                   // 112
        title: title,                                                                                                  // 112
        bossName: bossName,                                                                                            // 112
        bossStatN: bossStatN,                                                                                          // 112
        bossStatH: bossStatH,                                                                                          // 112
        bossStatM: bossStatM,                                                                                          // 112
        length: addCC,                                                                                                 // 112
        date: new Date()                                                                                               // 112
      });                                                                                                              // 112
      counts.update({                                                                                                  // 113
        _id: "data"                                                                                                    // 113
      }, {                                                                                                             // 113
        $inc: {                                                                                                        // 113
          raidCount: 1                                                                                                 // 113
        }                                                                                                              // 113
      });                                                                                                              // 113
    }                                                                                                                  // 114
  },                                                                                                                   // 115
  'addQues': function (ques, quesCount) {                                                                              // 116
    if (Meteor.user()) {                                                                                               // 117
      questions.remove({});                                                                                            // 118
      questions.insert({                                                                                               // 119
        ques: ques,                                                                                                    // 119
        quesCount: quesCount                                                                                           // 119
      });                                                                                                              // 119
    }                                                                                                                  // 120
  }                                                                                                                    // 121
});                                                                                                                    // 51
Meteor.methods({                                                                                                       // 124
  'updateSite': function (specStatus, title, about, tabard, background) {                                              // 125
    if (Meteor.user()) {                                                                                               // 126
      var spec = ['dnB', 'dnU', 'dnF', 'dhH', 'dhV', 'drB', 'drF', 'drR', 'drG', 'huM', 'huS', 'huB', 'maF', 'maFr', 'maA', 'moM', 'moW', 'moB', 'paH', 'paR', 'paP', 'prS', 'prD', 'prH', 'roA', 'roS', 'roC', 'shE', 'shR', 'shEn', 'waA', 'waD', 'waDe', 'warA', 'warF', 'warP'];
      var images = [];                                                                                                 // 128
      var canReload = [];                                                                                              // 129
                                                                                                                       //
      if (tabard != '') {                                                                                              // 130
        images.push('tabard');                                                                                         // 131
        canReload.push('0');                                                                                           // 132
      }                                                                                                                // 133
                                                                                                                       //
      if (background != '') {                                                                                          // 134
        images.push('background');                                                                                     // 135
        canReload.push('0');                                                                                           // 136
      }                                                                                                                // 137
                                                                                                                       //
      var path = process.env["PWD"] + '/.static~/';                                                                    // 138
                                                                                                                       //
      for (var i = 0; i < images.length; i++) {                                                                        // 139
        // our data URL string from canvas.toDataUrl();                                                                // 140
        var imageDataUrl = eval(images[i]); // declare a regexp to match the non base64 first characters               // 141
                                                                                                                       //
        var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp          // 143
                                                                                                                       //
        var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
        var imageBuffer = new Buffer(base64Data, "base64");                                                            // 147
        fs.writeFile(path + images[i] + '.jpeg', imageBuffer, function (err) {                                         // 148
          if (err) throw err;                                                                                          // 150
          console.log('Done!');                                                                                        // 151
          canReload[i] = 1;                                                                                            // 152
        });                                                                                                            // 153
        siteDetails.update({                                                                                           // 154
          _id: images[i]                                                                                               // 154
        }, {                                                                                                           // 154
          $set: {                                                                                                      // 154
            path: '/files/' + images[i] + ".jpeg"                                                                      // 154
          }                                                                                                            // 154
        });                                                                                                            // 154
      }                                                                                                                // 155
                                                                                                                       //
      var reloadLength = canReload.length;                                                                             // 157
                                                                                                                       //
      if (reloadLength == null) {                                                                                      // 158
        return true;                                                                                                   // 159
      } else if (reloadLength == 0 && canReload[0] == 1) {                                                             // 160
        return true;                                                                                                   // 161
      } else if (reloadLength == 1 && canReload[0] == 1 && canReload[1] == 1) {                                        // 162
        return true;                                                                                                   // 163
      }                                                                                                                // 164
                                                                                                                       //
      siteDetails.update({                                                                                             // 166
        _id: 'recruiting'                                                                                              // 166
      }, {                                                                                                             // 166
        $set: {                                                                                                        // 166
          dnB: specStatus[0],                                                                                          // 166
          dnU: specStatus[1],                                                                                          // 166
          dnF: specStatus[2],                                                                                          // 166
          dhH: specStatus[3],                                                                                          // 166
          dhV: specStatus[4],                                                                                          // 166
          drB: specStatus[5],                                                                                          // 166
          drF: specStatus[6],                                                                                          // 166
          drR: specStatus[7],                                                                                          // 166
          drG: specStatus[8],                                                                                          // 166
          huM: specStatus[9],                                                                                          // 166
          huS: specStatus[10],                                                                                         // 166
          huB: specStatus[11],                                                                                         // 166
          maF: specStatus[12],                                                                                         // 166
          maFr: specStatus[13],                                                                                        // 166
          maA: specStatus[14],                                                                                         // 166
          moM: specStatus[15],                                                                                         // 166
          moW: specStatus[16],                                                                                         // 166
          moB: specStatus[17],                                                                                         // 166
          paH: specStatus[18],                                                                                         // 166
          paR: specStatus[19],                                                                                         // 166
          paP: specStatus[20],                                                                                         // 166
          prS: specStatus[21],                                                                                         // 166
          prD: specStatus[22],                                                                                         // 166
          prH: specStatus[23],                                                                                         // 166
          roA: specStatus[24],                                                                                         // 166
          roS: specStatus[25],                                                                                         // 166
          roC: specStatus[26],                                                                                         // 166
          shE: specStatus[27],                                                                                         // 166
          shR: specStatus[28],                                                                                         // 166
          shEn: specStatus[29],                                                                                        // 166
          waA: specStatus[30],                                                                                         // 166
          waD: specStatus[31],                                                                                         // 166
          waDe: specStatus[32],                                                                                        // 166
          warA: specStatus[33],                                                                                        // 166
          warF: specStatus[34],                                                                                        // 166
          warP: specStatus[35]                                                                                         // 166
        }                                                                                                              // 166
      });                                                                                                              // 166
                                                                                                                       //
      if (title != "" && title != undefined && title != null) {                                                        // 168
        siteDetails.update({                                                                                           // 169
          _id: 'title'                                                                                                 // 169
        }, {                                                                                                           // 169
          $set: {                                                                                                      // 169
            title: title                                                                                               // 169
          }                                                                                                            // 169
        });                                                                                                            // 169
      }                                                                                                                // 170
                                                                                                                       //
      if (about != "" && about != undefined && about != null) {                                                        // 171
        siteDetails.update({                                                                                           // 172
          _id: 'about'                                                                                                 // 172
        }, {                                                                                                           // 172
          $set: {                                                                                                      // 172
            about: about                                                                                               // 172
          }                                                                                                            // 172
        });                                                                                                            // 172
      }                                                                                                                // 173
    }                                                                                                                  // 174
  },                                                                                                                   // 175
  'updateRaid': function (title, bossName, bossStatN, bossStatH, bossStatM, addCE, target) {                           // 176
    if (Meteor.user()) {                                                                                               // 177
      if (addCE < 0) {                                                                                                 // 178
        addCE = 0;                                                                                                     // 179
      }                                                                                                                // 180
                                                                                                                       //
      raids.update({                                                                                                   // 181
        _id: target                                                                                                    // 181
      }, {                                                                                                             // 181
        $set: {                                                                                                        // 181
          title: title,                                                                                                // 181
          bossName: bossName,                                                                                          // 181
          bossStatN: bossStatN,                                                                                        // 181
          bossStatH: bossStatH,                                                                                        // 181
          bossStatM: bossStatM,                                                                                        // 181
          length: addCE                                                                                                // 181
        }                                                                                                              // 181
      });                                                                                                              // 181
    }                                                                                                                  // 182
  },                                                                                                                   // 183
  'updatePost': function (title, content, id, imageData, cata) {                                                       // 184
    if (Meteor.user()) {                                                                                               // 185
      // our data URL string from canvas.toDataUrl();                                                                  // 186
      if (imageData != '') {                                                                                           // 187
        var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                     // 188
                                                                                                                       //
        var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp          // 190
                                                                                                                       //
        var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
        var imageBuffer = new Buffer(base64Data, "base64");                                                            // 194
        var path = process.env["PWD"] + '/.static~/';                                                                  // 195
        posts.update({                                                                                                 // 196
          _id: id                                                                                                      // 196
        }, {                                                                                                           // 196
          $set: {                                                                                                      // 196
            imgPath: '/files/' + id + ".jpeg"                                                                          // 196
          }                                                                                                            // 196
        }); //if we find an image with our ID                                                                          // 196
                                                                                                                       //
        if (images.findOne({                                                                                           // 198
          _id: id                                                                                                      // 198
        })) {                                                                                                          // 198
          //update it                                                                                                  // 199
          images.update({                                                                                              // 200
            _id: id                                                                                                    // 200
          }, {                                                                                                         // 200
            $set: {                                                                                                    // 200
              imgPath: '/files/' + id + ".jpeg"                                                                        // 200
            }                                                                                                          // 200
          });                                                                                                          // 200
        }                                                                                                              // 201
      }                                                                                                                // 202
                                                                                                                       //
      if (cata == 'Boss Fight') {                                                                                      // 203
        cata = "Boss";                                                                                                 // 204
      }                                                                                                                // 205
                                                                                                                       //
      if (cata == "News") {                                                                                            // 206
        images.remove({                                                                                                // 207
          _id: id                                                                                                      // 207
        });                                                                                                            // 207
      } else if (cata == "Boss") {                                                                                     // 208
        var thisDate = posts.findOne({                                                                                 // 209
          _id: id                                                                                                      // 209
        }).date_created;                                                                                               // 209
                                                                                                                       //
        if (images.findOne({                                                                                           // 210
          _id: id                                                                                                      // 210
        })) {//do something                                                                                            // 210
        } else {                                                                                                       // 212
          var imagePath = posts.findOne({                                                                              // 213
            _id: id                                                                                                    // 213
          }).imgPath;                                                                                                  // 213
          images.insert({                                                                                              // 214
            _id: id,                                                                                                   // 214
            date_created: thisDate,                                                                                    // 214
            imgPath: imagePath                                                                                         // 214
          });                                                                                                          // 214
        }                                                                                                              // 215
      }                                                                                                                // 216
                                                                                                                       //
      console.log(cata);                                                                                               // 217
                                                                                                                       //
      if (cata != null) {                                                                                              // 218
        posts.update({                                                                                                 // 219
          _id: id                                                                                                      // 219
        }, {                                                                                                           // 219
          $set: {                                                                                                      // 219
            title: title,                                                                                              // 219
            content: content,                                                                                          // 219
            cataSux: cata                                                                                              // 219
          }                                                                                                            // 219
        });                                                                                                            // 219
      } else {                                                                                                         // 220
        posts.update({                                                                                                 // 221
          _id: id                                                                                                      // 221
        }, {                                                                                                           // 221
          $set: {                                                                                                      // 221
            title: title,                                                                                              // 221
            content: content                                                                                           // 221
          }                                                                                                            // 221
        });                                                                                                            // 221
      }                                                                                                                // 222
                                                                                                                       //
      var canReload = false;                                                                                           // 223
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 224
        if (err) throw err;                                                                                            // 226
        console.log('Done!');                                                                                          // 227
        canReload = true;                                                                                              // 228
      });                                                                                                              // 229
                                                                                                                       //
      if (canReload == true) {                                                                                         // 230
        return true;                                                                                                   // 231
      }                                                                                                                // 232
    }                                                                                                                  // 233
  },                                                                                                                   // 234
  'updateTwitch': function (apiKey, names, counts) {                                                                   // 235
    if (Meteor.user()) {                                                                                               // 236
      if (counts < 0) {                                                                                                // 237
        counts = 0;                                                                                                    // 238
      }                                                                                                                // 239
                                                                                                                       //
      if (twitch.findOne({                                                                                             // 240
        _id: 'data'                                                                                                    // 240
      })) {                                                                                                            // 240
        twitch.update({                                                                                                // 241
          _id: 'data'                                                                                                  // 241
        }, {                                                                                                           // 241
          $set: {                                                                                                      // 241
            apiKey: apiKey,                                                                                            // 241
            names: names,                                                                                              // 241
            counts: counts                                                                                             // 241
          }                                                                                                            // 241
        });                                                                                                            // 241
        console.log('updating');                                                                                       // 242
      } else {                                                                                                         // 243
        twitch.insert({                                                                                                // 244
          _id: "data",                                                                                                 // 244
          apiKey: apiKey,                                                                                              // 244
          names: names,                                                                                                // 244
          counts: counts                                                                                               // 244
        });                                                                                                            // 244
        console.log('inserting');                                                                                      // 245
      }                                                                                                                // 246
    }                                                                                                                  // 247
  }                                                                                                                    // 248
});                                                                                                                    // 124
Meteor.methods({                                                                                                       // 251
  'sendApp': function (questions, resps, amt) {                                                                        // 252
    apps.insert({                                                                                                      // 253
      username: resps[0].replace("::", ""),                                                                            // 253
      questions: questions,                                                                                            // 253
      resps: resps,                                                                                                    // 253
      amt: amt,                                                                                                        // 253
      date: new Date()                                                                                                 // 253
    });                                                                                                                // 253
    counts.update({                                                                                                    // 254
      _id: "data"                                                                                                      // 254
    }, {                                                                                                               // 254
      $inc: {                                                                                                          // 254
        appCount: 1                                                                                                    // 254
      }                                                                                                                // 254
    });                                                                                                                // 254
  }                                                                                                                    // 255
});                                                                                                                    // 251
Meteor.methods({                                                                                                       // 258
  'deletePost': function (post) {                                                                                      // 259
    if (Meteor.user()) {                                                                                               // 260
      var filePath = process.env["PWD"] + '/.static~/' + post + '.jpeg';                                               // 261
      fs.unlinkSync(filePath);                                                                                         // 262
      posts.remove({                                                                                                   // 263
        _id: post                                                                                                      // 263
      });                                                                                                              // 263
      images.remove({                                                                                                  // 264
        _id: post                                                                                                      // 264
      });                                                                                                              // 264
      counts.update({                                                                                                  // 265
        _id: "data"                                                                                                    // 265
      }, {                                                                                                             // 265
        $inc: {                                                                                                        // 265
          postCount: -1                                                                                                // 265
        }                                                                                                              // 265
      });                                                                                                              // 265
    }                                                                                                                  // 266
  },                                                                                                                   // 267
  'deleteApp': function (appId) {                                                                                      // 268
    if (Meteor.user()) {                                                                                               // 269
      apps.remove({                                                                                                    // 270
        _id: appId                                                                                                     // 270
      });                                                                                                              // 270
      counts.update({                                                                                                  // 271
        _id: "data"                                                                                                    // 271
      }, {                                                                                                             // 271
        $inc: {                                                                                                        // 271
          appCount: -1                                                                                                 // 271
        }                                                                                                              // 271
      });                                                                                                              // 271
    }                                                                                                                  // 272
  },                                                                                                                   // 273
  'deleteRaid': function (raidId) {                                                                                    // 274
    if (Meteor.user()) {                                                                                               // 275
      raids.remove({                                                                                                   // 276
        _id: raidId                                                                                                    // 276
      });                                                                                                              // 276
      counts.update({                                                                                                  // 277
        _id: "data"                                                                                                    // 277
      }, {                                                                                                             // 277
        $inc: {                                                                                                        // 277
          raidCount: -1                                                                                                // 277
        }                                                                                                              // 277
      });                                                                                                              // 277
    }                                                                                                                  // 278
  }                                                                                                                    // 279
});                                                                                                                    // 258
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/db.js");
require("./lib/globals.js");
require("./lib/routes.js");
require("./server/fileserver.js");
require("./server/publish.js");
require("./server/server.js");
//# sourceMappingURL=app.js.map
