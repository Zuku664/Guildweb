var require = meteorInstall({"lib":{"db.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/db.js                                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
posts = new Mongo.Collection('posts');                                                                                 // 1
raids = new Mongo.Collection('raids');                                                                                 // 2
questions = new Mongo.Collection('questions');                                                                         // 3
apps = new Mongo.Collection('apps');                                                                                   // 4
userCount = new Mongo.Collection('userCount');                                                                         // 5
siteDetails = new Mongo.Collection('siteDetails');                                                                     // 6
twitch = new Mongo.Collection('twitch');                                                                               // 7
counts = new Mongo.Collection('counts');                                                                               // 9
images = new Mongo.Collection('images'); //denys anyone access to these (unless the above allow is met)                // 11
                                                                                                                       //
posts.deny({                                                                                                           // 14
  update: function () {                                                                                                // 15
    return true;                                                                                                       // 16
  },                                                                                                                   // 17
  insert: function () {                                                                                                // 19
    return true;                                                                                                       // 20
  }                                                                                                                    // 21
});                                                                                                                    // 14
twitch.deny({                                                                                                          // 24
  update: function () {                                                                                                // 25
    return true;                                                                                                       // 26
  },                                                                                                                   // 27
  insert: function () {                                                                                                // 29
    return true;                                                                                                       // 30
  }                                                                                                                    // 31
});                                                                                                                    // 24
images.deny({                                                                                                          // 34
  update: function () {                                                                                                // 35
    return true;                                                                                                       // 36
  },                                                                                                                   // 37
  insert: function () {                                                                                                // 39
    return true;                                                                                                       // 40
  }                                                                                                                    // 41
});                                                                                                                    // 34
apps.deny({                                                                                                            // 44
  update: function () {                                                                                                // 45
    return true;                                                                                                       // 46
  },                                                                                                                   // 47
  insert: function () {                                                                                                // 49
    return true;                                                                                                       // 50
  }                                                                                                                    // 51
});                                                                                                                    // 44
questions.deny({                                                                                                       // 54
  update: function () {                                                                                                // 55
    return true;                                                                                                       // 56
  },                                                                                                                   // 57
  insert: function () {                                                                                                // 59
    return true;                                                                                                       // 60
  }                                                                                                                    // 61
});                                                                                                                    // 54
raids.deny({                                                                                                           // 64
  update: function () {                                                                                                // 65
    return true;                                                                                                       // 66
  },                                                                                                                   // 67
  insert: function () {                                                                                                // 69
    return true;                                                                                                       // 70
  }                                                                                                                    // 71
});                                                                                                                    // 64
Meteor.users.deny({                                                                                                    // 74
  update: function () {                                                                                                // 75
    return true;                                                                                                       // 76
  }                                                                                                                    // 77
});                                                                                                                    // 74
userCount.deny({                                                                                                       // 80
  update: function () {                                                                                                // 81
    return true;                                                                                                       // 82
  },                                                                                                                   // 83
  insert: function () {                                                                                                // 85
    return true;                                                                                                       // 86
  }                                                                                                                    // 87
});                                                                                                                    // 80
siteDetails.deny({                                                                                                     // 90
  update: function () {                                                                                                // 91
    return true;                                                                                                       // 92
  },                                                                                                                   // 93
  insert: function () {                                                                                                // 95
    return true;                                                                                                       // 96
  }                                                                                                                    // 97
});                                                                                                                    // 90
counts.deny({                                                                                                          // 101
  update: function () {                                                                                                // 102
    return true;                                                                                                       // 103
  },                                                                                                                   // 104
  insert: function () {                                                                                                // 106
    return true;                                                                                                       // 107
  }                                                                                                                    // 108
});                                                                                                                    // 101
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"globals.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/globals.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//defaults to feed (home)                                                                                              // 1
currentPage = new ReactiveVar("feed"); //gets currentPost                                                              // 2
                                                                                                                       //
currentPost = new ReactiveVar(); //admin page location                                                                 // 5
                                                                                                                       //
adminLoc = new ReactiveVar("dash"); //the news filter                                                                  // 8
                                                                                                                       //
newsFilter = new ReactiveVar('news'); //for application viewing                                                        // 11
                                                                                                                       //
currentApp = new ReactiveVar('currentApp'); //for viewing existing raid                                                // 14
                                                                                                                       //
currentRaid = new ReactiveVar('currentRaid'); //for deleting stuff                                                     // 17
                                                                                                                       //
deleting = new ReactiveVar(''); //for loading image in carousel                                                        // 20
                                                                                                                       //
currentImage = new ReactiveVar(''); //for lazy loading                                                                 // 23
                                                                                                                       //
postLimitServer = new ReactiveVar(7); //test                                                                           // 26
                                                                                                                       //
imageTest = new ReactiveVar();                                                                                         // 29
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routes.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
FlowRouter.route('/', {                                                                                                // 1
  name: 'home',                                                                                                        // 2
  subscriptions: function (params, queryParams) {                                                                      // 3
    // using Fast Render                                                                                               // 4
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 5
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 6
  },                                                                                                                   // 7
  action: function () {                                                                                                // 8
    BlazeLayout.render('index');                                                                                       // 9
  },                                                                                                                   // 10
  fastRender: true                                                                                                     // 11
});                                                                                                                    // 1
FlowRouter.route('/admin', {                                                                                           // 14
  name: "admin",                                                                                                       // 15
  action: function () {                                                                                                // 16
    if (Meteor.userId()) {                                                                                             // 17
      BlazeLayout.render('admin');                                                                                     // 18
    } else {                                                                                                           // 19
      BlazeLayout.render('signin');                                                                                    // 20
    }                                                                                                                  // 21
  }                                                                                                                    // 22
});                                                                                                                    // 14
FlowRouter.route('/admin-login', {                                                                                     // 25
  name: "login",                                                                                                       // 26
  action: function () {                                                                                                // 27
    BlazeLayout.render('signin');                                                                                      // 28
  }                                                                                                                    // 29
});                                                                                                                    // 25
FlowRouter.route('/p/:_id', {                                                                                          // 32
  name: 'post',                                                                                                        // 33
  subscriptions: function (params, queryParams) {                                                                      // 34
    // using Fast Render                                                                                               // 35
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 36
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 37
  },                                                                                                                   // 38
  action: function (params, queryParams) {                                                                             // 39
    BlazeLayout.render('index');                                                                                       // 40
    var theseParms = params._id;                                                                                       // 41
    currentPage.set('article');                                                                                        // 42
    currentPost.set(theseParms);                                                                                       // 43
  }                                                                                                                    // 44
});                                                                                                                    // 32
FlowRouter.route('/feed', {                                                                                            // 47
  name: 'home2',                                                                                                       // 48
  subscriptions: function (params, queryParams) {                                                                      // 49
    // using Fast Render                                                                                               // 50
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 51
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 52
  },                                                                                                                   // 53
  action: function (params, queryParams) {                                                                             // 54
    BlazeLayout.render('index');                                                                                       // 55
    currentPage.set('feed');                                                                                           // 56
  }                                                                                                                    // 57
});                                                                                                                    // 47
FlowRouter.route('/about', {                                                                                           // 60
  name: 'about',                                                                                                       // 61
  subscriptions: function (params, queryParams) {                                                                      // 62
    // using Fast Render                                                                                               // 63
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 64
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 65
  },                                                                                                                   // 66
  action: function (params, queryParams) {                                                                             // 67
    BlazeLayout.render('index');                                                                                       // 68
    currentPage.set('about');                                                                                          // 69
  }                                                                                                                    // 70
});                                                                                                                    // 60
FlowRouter.route('/apply', {                                                                                           // 73
  name: 'apply',                                                                                                       // 74
  subscriptions: function (params, queryParams) {                                                                      // 75
    // using Fast Render                                                                                               // 76
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 77
  },                                                                                                                   // 78
  action: function (params, queryParams) {                                                                             // 79
    BlazeLayout.render('index');                                                                                       // 80
    currentPage.set('feed');                                                                                           // 81
  }                                                                                                                    // 82
});                                                                                                                    // 73
FlowRouter.route('/streams', {                                                                                         // 85
  name: 'streams',                                                                                                     // 86
  subscriptions: function (params, queryParams) {                                                                      // 87
    // using Fast Render                                                                                               // 88
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 89
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 90
  },                                                                                                                   // 91
  action: function (params, queryParams) {                                                                             // 92
    BlazeLayout.render('index');                                                                                       // 93
    currentPage.set('streams');                                                                                        // 94
  }                                                                                                                    // 95
});                                                                                                                    // 85
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fileserver.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/fileserver.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var fs = Npm.require('fs');                                                                                            // 1
                                                                                                                       //
WebApp.connectHandlers.use(function (req, res, next) {                                                                 // 2
    var re = /^\/files\/(.*)$/.exec(req.url);                                                                          // 3
                                                                                                                       //
    if (re !== null) {                                                                                                 // 4
        // Only handle URLs that start with /uploads_url_prefix/*                                                      // 4
        var filePath = process.env.PWD + '/.static~/' + re[1];                                                         // 5
        var data = fs.readFileSync(filePath);                                                                          // 6
        res.writeHead(200, {                                                                                           // 7
            'Content-Type': 'image'                                                                                    // 8
        });                                                                                                            // 7
        res.write(data);                                                                                               // 10
        res.end();                                                                                                     // 11
    } else {                                                                                                           // 12
        // Other urls will have default behaviors                                                                      // 12
        next();                                                                                                        // 13
    }                                                                                                                  // 14
});                                                                                                                    // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publish.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publish("posts", function (limit) {                                                                             // 1
  var dl = limit || 7; //send data newest first to the client                                                          // 2
                                                                                                                       //
  if (!this.userId) {                                                                                                  // 4
    return posts.find({}, {                                                                                            // 5
      sort: {                                                                                                          // 5
        date_created: -1                                                                                               // 5
      },                                                                                                               // 5
      limit: dl                                                                                                        // 5
    });                                                                                                                // 5
  } else {                                                                                                             // 6
    return posts.find({});                                                                                             // 7
  }                                                                                                                    // 8
});                                                                                                                    // 9
Meteor.publish("raids", function () {                                                                                  // 11
  return raids.find({}, {                                                                                              // 12
    sort: {                                                                                                            // 12
      date: -1                                                                                                         // 12
    }                                                                                                                  // 12
  });                                                                                                                  // 12
});                                                                                                                    // 13
Meteor.publish("twitch", function () {                                                                                 // 15
  return twitch.find({});                                                                                              // 16
});                                                                                                                    // 17
Meteor.publish("questions", function () {                                                                              // 19
  return questions.find({});                                                                                           // 20
});                                                                                                                    // 21
Meteor.publish("siteDetails", function () {                                                                            // 23
  return siteDetails.find({});                                                                                         // 24
});                                                                                                                    // 25
Meteor.publish("counts", function () {                                                                                 // 27
  return counts.find({});                                                                                              // 28
});                                                                                                                    // 29
Meteor.publish("apps", function () {                                                                                   // 31
  return apps.find({}, {                                                                                               // 32
    sort: {                                                                                                            // 32
      date: -1                                                                                                         // 32
    }                                                                                                                  // 32
  });                                                                                                                  // 32
});                                                                                                                    // 33
Meteor.publish('images', function (search, post) {                                                                     // 36
  return images.find({}, {                                                                                             // 37
    sort: {                                                                                                            // 37
      date_created: -1                                                                                                 // 37
    },                                                                                                                 // 37
    limit: 7                                                                                                           // 37
  });                                                                                                                  // 37
});                                                                                                                    // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/server.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 1
  fs = Npm.require('fs');                                                                                              // 2
}); //Meteor SEO SSR                                                                                                   // 3
                                                                                                                       //
var SeoRouter = Picker.filter(function (request, response) {                                                           // 6
  var botAgents = [/^facebookexternalhit/i, // Facebook                                                                // 7
  /^linkedinbot/i, // LinkedIn                                                                                         // 9
  /^twitterbot/i, // Twitter                                                                                           // 10
  /^slackbot-linkexpanding/i, // Slack                                                                                 // 11
  /^googlebot/i];                                                                                                      // 12
  return (/_escaped_fragment_/.test(request.url) || botAgents.some(function (i) {                                      // 15
      return i.test(request.headers['user-agent']);                                                                    // 15
    })                                                                                                                 // 15
  );                                                                                                                   // 15
});                                                                                                                    // 16
SeoRouter.route('/', function (params, request, response) {                                                            // 18
  SSR.compileTemplate('index', Assets.getText('index.html'));                                                          // 19
  Template.index.helpers({                                                                                             // 20
    getDocType: function () {                                                                                          // 21
      return "<!DOCTYPE html>";                                                                                        // 22
    },                                                                                                                 // 23
    title: function () {                                                                                               // 24
      return siteDetails.findOne({                                                                                     // 25
        _id: "title"                                                                                                   // 25
      }).title;                                                                                                        // 25
    },                                                                                                                 // 26
    meta: function () {                                                                                                // 27
      return siteDetails.findOne({                                                                                     // 28
        _id: "about"                                                                                                   // 28
      }).about;                                                                                                        // 28
    }                                                                                                                  // 29
  });                                                                                                                  // 20
  var html = SSR.render('index');                                                                                      // 32
  response.setHeader('Content-Type', 'text/html;charset=utf-8');                                                       // 34
  response.end(html);                                                                                                  // 35
}); //END                                                                                                              // 36
//checks to see if default site values are set, creates template for later                                             // 40
                                                                                                                       //
var needed = ['title', 'about', 'tabard', 'background', 'favicon', 'recruiting'];                                      // 41
var firstTime = 0;                                                                                                     // 42
                                                                                                                       //
for (var i = 0; i < needed.length; i++) {                                                                              // 43
  if (siteDetails.findOne({                                                                                            // 44
    _id: needed[i]                                                                                                     // 44
  })) {//horray!!                                                                                                      // 44
  } else {                                                                                                             // 46
    //lets create em                                                                                                   // 47
    siteDetails.insert({                                                                                               // 48
      _id: needed[i]                                                                                                   // 48
    });                                                                                                                // 48
    firstTime = 1;                                                                                                     // 49
  }                                                                                                                    // 50
}                                                                                                                      // 51
                                                                                                                       //
if (firstTime == 1) {                                                                                                  // 52
  //wow                                                                                                                // 53
  siteDetails.update({                                                                                                 // 54
    _id: 'recruiting'                                                                                                  // 54
  }, {                                                                                                                 // 54
    $set: {                                                                                                            // 54
      dnB: 'checked',                                                                                                  // 54
      dnU: 'checked',                                                                                                  // 54
      dnF: 'checked',                                                                                                  // 54
      dhH: 'checked',                                                                                                  // 54
      dhV: 'checked',                                                                                                  // 54
      drB: 'checked',                                                                                                  // 54
      drF: 'checked',                                                                                                  // 54
      drR: 'checked',                                                                                                  // 54
      drG: 'checked',                                                                                                  // 54
      huM: 'checked',                                                                                                  // 54
      huS: 'checked',                                                                                                  // 54
      huB: 'checked',                                                                                                  // 54
      maF: 'checked',                                                                                                  // 54
      maFr: 'checked',                                                                                                 // 54
      maA: 'checked',                                                                                                  // 54
      moM: 'checked',                                                                                                  // 54
      moW: 'checked',                                                                                                  // 54
      moB: 'checked',                                                                                                  // 54
      paH: 'checked',                                                                                                  // 54
      paR: 'checked',                                                                                                  // 54
      paP: 'checked',                                                                                                  // 54
      prS: 'checked',                                                                                                  // 54
      prD: 'checked',                                                                                                  // 54
      prH: 'checked',                                                                                                  // 54
      roA: 'checked',                                                                                                  // 54
      roS: 'checked',                                                                                                  // 54
      roC: 'checked',                                                                                                  // 54
      shE: 'checked',                                                                                                  // 54
      shR: 'checked',                                                                                                  // 54
      shEn: 'checked',                                                                                                 // 54
      waA: 'checked',                                                                                                  // 54
      waD: 'checked',                                                                                                  // 54
      waDe: 'checked',                                                                                                 // 54
      warA: 'checked',                                                                                                 // 54
      warF: 'checked',                                                                                                 // 54
      warP: 'checked'                                                                                                  // 54
    }                                                                                                                  // 54
  });                                                                                                                  // 54
  userCount.insert({                                                                                                   // 55
    count: 0                                                                                                           // 55
  });                                                                                                                  // 55
  counts.insert({                                                                                                      // 56
    _id: "data",                                                                                                       // 56
    postCount: 0,                                                                                                      // 56
    appCount: 0,                                                                                                       // 56
    raidCount: 0                                                                                                       // 56
  });                                                                                                                  // 56
  firstTime = 0;                                                                                                       // 57
} //creates initial account                                                                                            // 58
                                                                                                                       //
                                                                                                                       //
Meteor.methods({                                                                                                       // 62
  'accountCheck': function () {                                                                                        // 63
    if (userCount.findOne({                                                                                            // 64
      count: 0                                                                                                         // 64
    })) {                                                                                                              // 64
      return true;                                                                                                     // 65
    } else {                                                                                                           // 66
      return false;                                                                                                    // 67
    }                                                                                                                  // 68
  },                                                                                                                   // 69
  'phraseCheck': function (secret) {                                                                                   // 70
    if (secret == "SnowyTableSanDiegoFifteenTwelve") {                                                                 // 71
      return true;                                                                                                     // 72
    }                                                                                                                  // 73
  },                                                                                                                   // 74
  'createAcc': function (usm, psw) {                                                                                   // 75
    if (userCount.findOne({                                                                                            // 76
      count: 0                                                                                                         // 76
    })) {                                                                                                              // 76
      Accounts.createUser({                                                                                            // 77
        username: usm,                                                                                                 // 78
        password: psw                                                                                                  // 79
      });                                                                                                              // 77
    }                                                                                                                  // 81
                                                                                                                       //
    userCount.insert({                                                                                                 // 82
      count: 1                                                                                                         // 82
    });                                                                                                                // 82
    userCount.remove({                                                                                                 // 83
      count: 0                                                                                                         // 83
    });                                                                                                                // 83
  }                                                                                                                    // 84
});                                                                                                                    // 62
Meteor.methods({                                                                                                       // 87
  'post': function (imageData, title, content, cata) {                                                                 // 88
    if (Meteor.user()) {                                                                                               // 89
      // our data URL string from canvas.toDataUrl();                                                                  // 90
      var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                       // 91
                                                                                                                       //
      var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp            // 93
                                                                                                                       //
      var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
      var imageBuffer = new Buffer(base64Data, "base64");                                                              // 97
      var id = ShortId.generate();                                                                                     // 98
      var isoDate = new Date();                                                                                        // 99
      var res = isoDate.toString().split(" ");                                                                         // 100
      var date = res[1] + " " + res[2] + " " + res[3];                                                                 // 101
      var path = process.env["PWD"] + '/.static~/';                                                                    // 102
      var cata = cata;                                                                                                 // 104
                                                                                                                       //
      if (cata.includes("News")) {                                                                                     // 105
        cata = "News";                                                                                                 // 106
      } else if (cata.includes("Boss")) {                                                                              // 107
        cata = "Boss";                                                                                                 // 108
      } else {                                                                                                         // 109
        //if no catagory is supplied, assume it's just news                                                            // 110
        cata = "News";                                                                                                 // 111
      }                                                                                                                // 112
                                                                                                                       //
      posts.insert({                                                                                                   // 113
        _id: id,                                                                                                       // 113
        title: title,                                                                                                  // 113
        content: content,                                                                                              // 113
        imgPath: '/files/' + id + ".jpeg",                                                                             // 113
        date: date,                                                                                                    // 113
        cataSux: cata,                                                                                                 // 113
        date_created: new Date()                                                                                       // 113
      });                                                                                                              // 113
      counts.update({                                                                                                  // 114
        _id: "data"                                                                                                    // 114
      }, {                                                                                                             // 114
        $inc: {                                                                                                        // 114
          postCount: 1                                                                                                 // 114
        }                                                                                                              // 114
      });                                                                                                              // 114
                                                                                                                       //
      if (cata == "Boss") {                                                                                            // 115
        images.insert({                                                                                                // 116
          _id: id,                                                                                                     // 116
          title: title,                                                                                                // 116
          imgPath: '/files/' + id + ".jpeg",                                                                           // 116
          date_created: new Date()                                                                                     // 116
        });                                                                                                            // 116
      }                                                                                                                // 117
                                                                                                                       //
      if (imageData == '') {                                                                                           // 118
        var rand = Math.floor(Math.random() * 3) + 1;                                                                  // 119
        var img = '';                                                                                                  // 120
                                                                                                                       //
        if (rand == 1) {                                                                                               // 121
          img = 'default1.jpg';                                                                                        // 122
        } else if (rand == 2) {                                                                                        // 123
          img = 'default2.jpg';                                                                                        // 124
        } else {                                                                                                       // 125
          img = 'default3.jpg';                                                                                        // 126
        }                                                                                                              // 127
                                                                                                                       //
        posts.update({                                                                                                 // 128
          _id: id                                                                                                      // 128
        }, {                                                                                                           // 128
          $set: {                                                                                                      // 128
            imgPath: '/' + img                                                                                         // 128
          }                                                                                                            // 128
        });                                                                                                            // 128
                                                                                                                       //
        if (cata == "Boss") {                                                                                          // 129
          images.update({                                                                                              // 130
            _id: id                                                                                                    // 130
          }, {                                                                                                         // 130
            $set: {                                                                                                    // 130
              imgPath: '/' + img                                                                                       // 130
            }                                                                                                          // 130
          });                                                                                                          // 130
        }                                                                                                              // 131
      }                                                                                                                // 132
                                                                                                                       //
      var canReload = false;                                                                                           // 133
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 134
        if (err) throw err;                                                                                            // 136
        console.log('Done!');                                                                                          // 137
        canReload = true;                                                                                              // 138
      });                                                                                                              // 139
                                                                                                                       //
      if (canReload == true) {                                                                                         // 140
        return true;                                                                                                   // 141
      }                                                                                                                // 142
    }                                                                                                                  // 143
  },                                                                                                                   // 144
  'addRaid': function (title, bossName, bossStatN, bossStatH, bossStatM, addCC) {                                      // 145
    if (Meteor.user()) {                                                                                               // 146
      //okay, I'm posting each boss and it's stats in an array. I need to break it up to show it, but I'm sure I can do that Client side.
      raids.insert({                                                                                                   // 148
        title: title,                                                                                                  // 148
        bossName: bossName,                                                                                            // 148
        bossStatN: bossStatN,                                                                                          // 148
        bossStatH: bossStatH,                                                                                          // 148
        bossStatM: bossStatM,                                                                                          // 148
        length: addCC,                                                                                                 // 148
        date: new Date()                                                                                               // 148
      });                                                                                                              // 148
      counts.update({                                                                                                  // 149
        _id: "data"                                                                                                    // 149
      }, {                                                                                                             // 149
        $inc: {                                                                                                        // 149
          raidCount: 1                                                                                                 // 149
        }                                                                                                              // 149
      });                                                                                                              // 149
    }                                                                                                                  // 150
  },                                                                                                                   // 151
  'addQues': function (ques, quesCount) {                                                                              // 152
    if (Meteor.user()) {                                                                                               // 153
      questions.remove({});                                                                                            // 154
      questions.insert({                                                                                               // 155
        ques: ques,                                                                                                    // 155
        quesCount: quesCount                                                                                           // 155
      });                                                                                                              // 155
    }                                                                                                                  // 156
  }                                                                                                                    // 157
});                                                                                                                    // 87
Meteor.methods({                                                                                                       // 160
  'updateSite': function (specStatus, title, about, tabard, background) {                                              // 161
    if (Meteor.user()) {                                                                                               // 162
      var spec = ['dnB', 'dnU', 'dnF', 'dhH', 'dhV', 'drB', 'drF', 'drR', 'drG', 'huM', 'huS', 'huB', 'maF', 'maFr', 'maA', 'moM', 'moW', 'moB', 'paH', 'paR', 'paP', 'prS', 'prD', 'prH', 'roA', 'roS', 'roC', 'shE', 'shR', 'shEn', 'waA', 'waD', 'waDe', 'warA', 'warF', 'warP'];
      var images = [];                                                                                                 // 164
      var canReload = [];                                                                                              // 165
                                                                                                                       //
      if (tabard != '') {                                                                                              // 166
        images.push('tabard');                                                                                         // 167
        canReload.push('0');                                                                                           // 168
      }                                                                                                                // 169
                                                                                                                       //
      if (background != '') {                                                                                          // 170
        images.push('background');                                                                                     // 171
        canReload.push('0');                                                                                           // 172
      }                                                                                                                // 173
                                                                                                                       //
      var path = process.env["PWD"] + '/.static~/';                                                                    // 174
                                                                                                                       //
      for (var i = 0; i < images.length; i++) {                                                                        // 175
        console.log(images[i]); // our data URL string from canvas.toDataUrl();                                        // 176
                                                                                                                       //
        var imageDataUrl = eval(images[i]); // declare a regexp to match the non base64 first characters               // 178
                                                                                                                       //
        var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp          // 180
                                                                                                                       //
        var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
        var imageBuffer = new Buffer(base64Data, "base64");                                                            // 184
        fs.writeFile(path + images[i] + '.jpeg', imageBuffer, function (err) {                                         // 185
          if (err) throw err;                                                                                          // 187
          console.log('Done!');                                                                                        // 188
          canReload[i] = 1;                                                                                            // 189
        });                                                                                                            // 190
        siteDetails.update({                                                                                           // 191
          _id: images[i]                                                                                               // 191
        }, {                                                                                                           // 191
          $set: {                                                                                                      // 191
            path: '/files/' + images[i] + ".jpeg"                                                                      // 191
          }                                                                                                            // 191
        });                                                                                                            // 191
      }                                                                                                                // 192
                                                                                                                       //
      var reloadLength = canReload.length;                                                                             // 194
                                                                                                                       //
      if (reloadLength == null) {                                                                                      // 195
        return true;                                                                                                   // 196
      } else if (reloadLength == 0 && canReload[0] == 1) {                                                             // 197
        return true;                                                                                                   // 198
      } else if (reloadLength == 1 && canReload[0] == 1 && canReload[1] == 1) {                                        // 199
        return true;                                                                                                   // 200
      }                                                                                                                // 201
                                                                                                                       //
      siteDetails.update({                                                                                             // 203
        _id: 'recruiting'                                                                                              // 203
      }, {                                                                                                             // 203
        $set: {                                                                                                        // 203
          dnB: specStatus[0],                                                                                          // 203
          dnU: specStatus[1],                                                                                          // 203
          dnF: specStatus[2],                                                                                          // 203
          dhH: specStatus[3],                                                                                          // 203
          dhV: specStatus[4],                                                                                          // 203
          drB: specStatus[5],                                                                                          // 203
          drF: specStatus[6],                                                                                          // 203
          drR: specStatus[7],                                                                                          // 203
          drG: specStatus[8],                                                                                          // 203
          huM: specStatus[9],                                                                                          // 203
          huS: specStatus[10],                                                                                         // 203
          huB: specStatus[11],                                                                                         // 203
          maF: specStatus[12],                                                                                         // 203
          maFr: specStatus[13],                                                                                        // 203
          maA: specStatus[14],                                                                                         // 203
          moM: specStatus[15],                                                                                         // 203
          moW: specStatus[16],                                                                                         // 203
          moB: specStatus[17],                                                                                         // 203
          paH: specStatus[18],                                                                                         // 203
          paR: specStatus[19],                                                                                         // 203
          paP: specStatus[20],                                                                                         // 203
          prS: specStatus[21],                                                                                         // 203
          prD: specStatus[22],                                                                                         // 203
          prH: specStatus[23],                                                                                         // 203
          roA: specStatus[24],                                                                                         // 203
          roS: specStatus[25],                                                                                         // 203
          roC: specStatus[26],                                                                                         // 203
          shE: specStatus[27],                                                                                         // 203
          shR: specStatus[28],                                                                                         // 203
          shEn: specStatus[29],                                                                                        // 203
          waA: specStatus[30],                                                                                         // 203
          waD: specStatus[31],                                                                                         // 203
          waDe: specStatus[32],                                                                                        // 203
          warA: specStatus[33],                                                                                        // 203
          warF: specStatus[34],                                                                                        // 203
          warP: specStatus[35]                                                                                         // 203
        }                                                                                                              // 203
      });                                                                                                              // 203
                                                                                                                       //
      if (title != "" && title != undefined && title != null) {                                                        // 205
        siteDetails.update({                                                                                           // 206
          _id: 'title'                                                                                                 // 206
        }, {                                                                                                           // 206
          $set: {                                                                                                      // 206
            title: title                                                                                               // 206
          }                                                                                                            // 206
        });                                                                                                            // 206
      }                                                                                                                // 207
                                                                                                                       //
      if (about != "" && about != undefined && about != null) {                                                        // 208
        siteDetails.update({                                                                                           // 209
          _id: 'about'                                                                                                 // 209
        }, {                                                                                                           // 209
          $set: {                                                                                                      // 209
            about: about                                                                                               // 209
          }                                                                                                            // 209
        });                                                                                                            // 209
      }                                                                                                                // 210
    }                                                                                                                  // 211
  },                                                                                                                   // 212
  'updateRaid': function (title, bossName, bossStatN, bossStatH, bossStatM, addCE, target) {                           // 213
    if (Meteor.user()) {                                                                                               // 214
      if (addCE < 0) {                                                                                                 // 215
        addCE = 0;                                                                                                     // 216
      }                                                                                                                // 217
                                                                                                                       //
      raids.update({                                                                                                   // 218
        _id: target                                                                                                    // 218
      }, {                                                                                                             // 218
        $set: {                                                                                                        // 218
          title: title,                                                                                                // 218
          bossName: bossName,                                                                                          // 218
          bossStatN: bossStatN,                                                                                        // 218
          bossStatH: bossStatH,                                                                                        // 218
          bossStatM: bossStatM,                                                                                        // 218
          length: addCE                                                                                                // 218
        }                                                                                                              // 218
      });                                                                                                              // 218
    }                                                                                                                  // 219
  },                                                                                                                   // 220
  'updatePost': function (title, content, id, imageData, cata) {                                                       // 221
    if (Meteor.user()) {                                                                                               // 222
      // our data URL string from canvas.toDataUrl();                                                                  // 223
      if (imageData != '') {                                                                                           // 224
        var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                     // 225
                                                                                                                       //
        var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp          // 227
                                                                                                                       //
        var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
        var imageBuffer = new Buffer(base64Data, "base64");                                                            // 231
        var path = process.env["PWD"] + '/.static~/';                                                                  // 232
        posts.update({                                                                                                 // 233
          _id: id                                                                                                      // 233
        }, {                                                                                                           // 233
          $set: {                                                                                                      // 233
            imgPath: '/files/' + id + ".jpeg"                                                                          // 233
          }                                                                                                            // 233
        }); //if we find an image with our ID                                                                          // 233
                                                                                                                       //
        if (images.findOne({                                                                                           // 235
          _id: id                                                                                                      // 235
        })) {                                                                                                          // 235
          //update it                                                                                                  // 236
          images.update({                                                                                              // 237
            _id: id                                                                                                    // 237
          }, {                                                                                                         // 237
            $set: {                                                                                                    // 237
              imgPath: '/files/' + id + ".jpeg"                                                                        // 237
            }                                                                                                          // 237
          });                                                                                                          // 237
        }                                                                                                              // 238
      }                                                                                                                // 239
                                                                                                                       //
      if (cata == 'Boss Fight') {                                                                                      // 240
        cata = "Boss";                                                                                                 // 241
      }                                                                                                                // 242
                                                                                                                       //
      if (cata == "News") {                                                                                            // 243
        images.remove({                                                                                                // 244
          _id: id                                                                                                      // 244
        });                                                                                                            // 244
      } else if (cata == "Boss") {                                                                                     // 245
        var thisDate = posts.findOne({                                                                                 // 246
          _id: id                                                                                                      // 246
        }).date_created;                                                                                               // 246
                                                                                                                       //
        if (images.findOne({                                                                                           // 247
          _id: id                                                                                                      // 247
        })) {//do something                                                                                            // 247
        } else {                                                                                                       // 249
          var imagePath = posts.findOne({                                                                              // 250
            _id: id                                                                                                    // 250
          }).imgPath;                                                                                                  // 250
          images.insert({                                                                                              // 251
            _id: id,                                                                                                   // 251
            date_created: thisDate,                                                                                    // 251
            imgPath: imagePath                                                                                         // 251
          });                                                                                                          // 251
        }                                                                                                              // 252
      }                                                                                                                // 253
                                                                                                                       //
      console.log(cata);                                                                                               // 254
                                                                                                                       //
      if (cata != null) {                                                                                              // 255
        posts.update({                                                                                                 // 256
          _id: id                                                                                                      // 256
        }, {                                                                                                           // 256
          $set: {                                                                                                      // 256
            title: title,                                                                                              // 256
            content: content,                                                                                          // 256
            cataSux: cata                                                                                              // 256
          }                                                                                                            // 256
        });                                                                                                            // 256
      } else {                                                                                                         // 257
        posts.update({                                                                                                 // 258
          _id: id                                                                                                      // 258
        }, {                                                                                                           // 258
          $set: {                                                                                                      // 258
            title: title,                                                                                              // 258
            content: content                                                                                           // 258
          }                                                                                                            // 258
        });                                                                                                            // 258
      }                                                                                                                // 259
                                                                                                                       //
      var canReload = false;                                                                                           // 260
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 261
        if (err) throw err;                                                                                            // 263
        console.log('Done!');                                                                                          // 264
        canReload = true;                                                                                              // 265
      });                                                                                                              // 266
                                                                                                                       //
      if (canReload == true) {                                                                                         // 267
        return true;                                                                                                   // 268
      }                                                                                                                // 269
    }                                                                                                                  // 270
  },                                                                                                                   // 271
  'updateTwitch': function (apiKey, names, counts) {                                                                   // 272
    if (Meteor.user()) {                                                                                               // 273
      if (counts < 0) {                                                                                                // 274
        counts = 0;                                                                                                    // 275
      }                                                                                                                // 276
                                                                                                                       //
      if (twitch.findOne({                                                                                             // 277
        _id: 'data'                                                                                                    // 277
      })) {                                                                                                            // 277
        twitch.update({                                                                                                // 278
          _id: 'data'                                                                                                  // 278
        }, {                                                                                                           // 278
          $set: {                                                                                                      // 278
            apiKey: apiKey,                                                                                            // 278
            names: names,                                                                                              // 278
            counts: counts                                                                                             // 278
          }                                                                                                            // 278
        });                                                                                                            // 278
        console.log('updating');                                                                                       // 279
      } else {                                                                                                         // 280
        twitch.insert({                                                                                                // 281
          _id: "data",                                                                                                 // 281
          apiKey: apiKey,                                                                                              // 281
          names: names,                                                                                                // 281
          counts: counts                                                                                               // 281
        });                                                                                                            // 281
        console.log('inserting');                                                                                      // 282
      }                                                                                                                // 283
    }                                                                                                                  // 284
  }                                                                                                                    // 285
});                                                                                                                    // 160
Meteor.methods({                                                                                                       // 288
  'sendApp': function (questions, resps, amt) {                                                                        // 289
    apps.insert({                                                                                                      // 290
      username: resps[0].replace("::", ""),                                                                            // 290
      questions: questions,                                                                                            // 290
      resps: resps,                                                                                                    // 290
      amt: amt,                                                                                                        // 290
      date: new Date()                                                                                                 // 290
    });                                                                                                                // 290
    counts.update({                                                                                                    // 291
      _id: "data"                                                                                                      // 291
    }, {                                                                                                               // 291
      $inc: {                                                                                                          // 291
        appCount: 1                                                                                                    // 291
      }                                                                                                                // 291
    });                                                                                                                // 291
  }                                                                                                                    // 292
});                                                                                                                    // 288
Meteor.methods({                                                                                                       // 295
  'deletePost': function (post) {                                                                                      // 296
    if (Meteor.user()) {                                                                                               // 297
      var filePath = process.env["PWD"] + '/.static~/' + post + '.jpeg';                                               // 298
      fs.unlinkSync(filePath);                                                                                         // 299
      posts.remove({                                                                                                   // 300
        _id: post                                                                                                      // 300
      });                                                                                                              // 300
      images.remove({                                                                                                  // 301
        _id: post                                                                                                      // 301
      });                                                                                                              // 301
      counts.update({                                                                                                  // 302
        _id: "data"                                                                                                    // 302
      }, {                                                                                                             // 302
        $inc: {                                                                                                        // 302
          postCount: -1                                                                                                // 302
        }                                                                                                              // 302
      });                                                                                                              // 302
    }                                                                                                                  // 303
  },                                                                                                                   // 304
  'deleteApp': function (appId) {                                                                                      // 305
    if (Meteor.user()) {                                                                                               // 306
      apps.remove({                                                                                                    // 307
        _id: appId                                                                                                     // 307
      });                                                                                                              // 307
      counts.update({                                                                                                  // 308
        _id: "data"                                                                                                    // 308
      }, {                                                                                                             // 308
        $inc: {                                                                                                        // 308
          appCount: -1                                                                                                 // 308
        }                                                                                                              // 308
      });                                                                                                              // 308
    }                                                                                                                  // 309
  },                                                                                                                   // 310
  'deleteRaid': function (raidId) {                                                                                    // 311
    if (Meteor.user()) {                                                                                               // 312
      raids.remove({                                                                                                   // 313
        _id: raidId                                                                                                    // 313
      });                                                                                                              // 313
      counts.update({                                                                                                  // 314
        _id: "data"                                                                                                    // 314
      }, {                                                                                                             // 314
        $inc: {                                                                                                        // 314
          raidCount: -1                                                                                                // 314
        }                                                                                                              // 314
      });                                                                                                              // 314
    }                                                                                                                  // 315
  }                                                                                                                    // 316
});                                                                                                                    // 295
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/db.js");
require("./lib/globals.js");
require("./lib/routes.js");
require("./server/fileserver.js");
require("./server/publish.js");
require("./server/server.js");
//# sourceMappingURL=app.js.map
