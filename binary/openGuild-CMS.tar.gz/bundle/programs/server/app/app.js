var require = meteorInstall({"lib":{"db.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/db.js                                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
posts = new Mongo.Collection('posts');                                                                                 // 1
raids = new Mongo.Collection('raids');                                                                                 // 2
questions = new Mongo.Collection('questions');                                                                         // 3
apps = new Mongo.Collection('apps');                                                                                   // 4
userCount = new Mongo.Collection('userCount');                                                                         // 5
siteDetails = new Mongo.Collection('siteDetails');                                                                     // 6
counts = new Mongo.Collection('counts'); //denys anyone access to these (unless the above allow is met)                // 8
                                                                                                                       //
posts.deny({                                                                                                           // 11
  update: function () {                                                                                                // 12
    return true;                                                                                                       // 13
  },                                                                                                                   // 14
  insert: function () {                                                                                                // 16
    return true;                                                                                                       // 17
  }                                                                                                                    // 18
});                                                                                                                    // 11
apps.deny({                                                                                                            // 21
  update: function () {                                                                                                // 22
    return true;                                                                                                       // 23
  },                                                                                                                   // 24
  insert: function () {                                                                                                // 26
    return true;                                                                                                       // 27
  }                                                                                                                    // 28
});                                                                                                                    // 21
questions.deny({                                                                                                       // 31
  update: function () {                                                                                                // 32
    return true;                                                                                                       // 33
  },                                                                                                                   // 34
  insert: function () {                                                                                                // 36
    return true;                                                                                                       // 37
  }                                                                                                                    // 38
});                                                                                                                    // 31
raids.deny({                                                                                                           // 41
  update: function () {                                                                                                // 42
    return true;                                                                                                       // 43
  },                                                                                                                   // 44
  insert: function () {                                                                                                // 46
    return true;                                                                                                       // 47
  }                                                                                                                    // 48
});                                                                                                                    // 41
Meteor.users.deny({                                                                                                    // 51
  update: function () {                                                                                                // 52
    return true;                                                                                                       // 53
  }                                                                                                                    // 54
});                                                                                                                    // 51
userCount.deny({                                                                                                       // 57
  update: function () {                                                                                                // 58
    return true;                                                                                                       // 59
  },                                                                                                                   // 60
  insert: function () {                                                                                                // 62
    return true;                                                                                                       // 63
  }                                                                                                                    // 64
});                                                                                                                    // 57
siteDetails.deny({                                                                                                     // 67
  update: function () {                                                                                                // 68
    return true;                                                                                                       // 69
  },                                                                                                                   // 70
  insert: function () {                                                                                                // 72
    return true;                                                                                                       // 73
  }                                                                                                                    // 74
});                                                                                                                    // 67
counts.deny({                                                                                                          // 78
  update: function () {                                                                                                // 79
    return true;                                                                                                       // 80
  },                                                                                                                   // 81
  insert: function () {                                                                                                // 83
    return true;                                                                                                       // 84
  }                                                                                                                    // 85
});                                                                                                                    // 78
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"globals.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/globals.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//defaults to feed (home)                                                                                              // 1
currentPage = new ReactiveVar("feed"); //gets currentPost                                                              // 2
                                                                                                                       //
currentPost = new ReactiveVar(); //admin page location                                                                 // 5
                                                                                                                       //
adminLoc = new ReactiveVar("dash"); //the news filter                                                                  // 8
                                                                                                                       //
newsFilter = new ReactiveVar('news'); //for application viewing                                                        // 11
                                                                                                                       //
currentApp = new ReactiveVar('currentApp'); //for viewing existing raid                                                // 14
                                                                                                                       //
currentRaid = new ReactiveVar('currentRaid'); //for deleting stuff                                                     // 17
                                                                                                                       //
deleting = new ReactiveVar(''); //for loading image in carousel                                                        // 20
                                                                                                                       //
currentImage = new ReactiveVar('');                                                                                    // 23
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/routes.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
FlowRouter.route('/', {                                                                                                // 1
  name: 'home',                                                                                                        // 2
  subscriptions: function (params, queryParams) {                                                                      // 3
    // using Fast Render                                                                                               // 4
    this.register('posts', Meteor.subscribe('posts'));                                                                 // 5
    this.register('siteDetails', Meteor.subscribe('siteDetails'));                                                     // 6
  },                                                                                                                   // 7
  action: function () {                                                                                                // 8
    BlazeLayout.render('index');                                                                                       // 9
  },                                                                                                                   // 10
  fastRender: true                                                                                                     // 11
});                                                                                                                    // 1
FlowRouter.route('/admin', {                                                                                           // 14
  name: "admin",                                                                                                       // 15
  action: function () {                                                                                                // 16
    if (Meteor.userId()) {                                                                                             // 17
      BlazeLayout.render('admin');                                                                                     // 18
    } else {                                                                                                           // 19
      BlazeLayout.render('signin');                                                                                    // 20
    }                                                                                                                  // 21
  }                                                                                                                    // 22
});                                                                                                                    // 14
FlowRouter.route('/admin-login', {                                                                                     // 25
  name: "login",                                                                                                       // 26
  action: function () {                                                                                                // 27
    BlazeLayout.render('signin');                                                                                      // 28
  }                                                                                                                    // 29
});                                                                                                                    // 25
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fileserver.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/fileserver.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var fs = Npm.require('fs');                                                                                            // 1
                                                                                                                       //
WebApp.connectHandlers.use(function (req, res, next) {                                                                 // 2
    var re = /^\/files\/(.*)$/.exec(req.url);                                                                          // 3
                                                                                                                       //
    if (re !== null) {                                                                                                 // 4
        // Only handle URLs that start with /uploads_url_prefix/*                                                      // 4
        var filePath = process.env.PWD + '/.static~/' + re[1];                                                         // 5
        var data = fs.readFileSync(filePath);                                                                          // 6
        res.writeHead(200, {                                                                                           // 7
            'Content-Type': 'image'                                                                                    // 8
        });                                                                                                            // 7
        res.write(data);                                                                                               // 10
        res.end();                                                                                                     // 11
    } else {                                                                                                           // 12
        // Other urls will have default behaviors                                                                      // 12
        next();                                                                                                        // 13
    }                                                                                                                  // 14
});                                                                                                                    // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publish.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publish("posts", function () {                                                                                  // 1
  //send data newest first to the client                                                                               // 2
  return posts.find({}, {                                                                                              // 3
    sort: {                                                                                                            // 3
      date_created: -1                                                                                                 // 3
    }                                                                                                                  // 3
  });                                                                                                                  // 3
});                                                                                                                    // 4
Meteor.publish("raids", function () {                                                                                  // 6
  return raids.find({});                                                                                               // 7
});                                                                                                                    // 8
Meteor.publish("questions", function () {                                                                              // 10
  return questions.find({});                                                                                           // 11
});                                                                                                                    // 12
Meteor.publish("siteDetails", function () {                                                                            // 14
  return siteDetails.find({});                                                                                         // 15
});                                                                                                                    // 16
Meteor.publish("counts", function () {                                                                                 // 18
  return counts.find({});                                                                                              // 19
});                                                                                                                    // 20
Meteor.publish("apps", function () {                                                                                   // 22
  return apps.find({});                                                                                                // 23
});                                                                                                                    // 24
Meteor.publish('images', function (search, post) {                                                                     // 26
  return posts.find({                                                                                                  // 27
    cataSux: "Boss"                                                                                                    // 27
  });                                                                                                                  // 27
});                                                                                                                    // 28
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/server.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 1
  fs = Npm.require('fs');                                                                                              // 2
}); //checks to see if default site values are set, creates template for later                                         // 3
                                                                                                                       //
var needed = ['title', 'about', 'tabard', 'background', 'favicon', 'recruiting'];                                      // 7
var firstTime = 0;                                                                                                     // 8
                                                                                                                       //
for (var i = 0; i < needed.length; i++) {                                                                              // 9
  if (siteDetails.findOne({                                                                                            // 10
    _id: needed[i]                                                                                                     // 10
  })) {//horray!!                                                                                                      // 10
  } else {                                                                                                             // 12
    //lets create em                                                                                                   // 13
    siteDetails.insert({                                                                                               // 14
      _id: needed[i]                                                                                                   // 14
    });                                                                                                                // 14
    firstTime = 1;                                                                                                     // 15
  }                                                                                                                    // 16
}                                                                                                                      // 17
                                                                                                                       //
if (firstTime == 1) {                                                                                                  // 18
  //wow                                                                                                                // 19
  siteDetails.update({                                                                                                 // 20
    _id: 'recruiting'                                                                                                  // 20
  }, {                                                                                                                 // 20
    $set: {                                                                                                            // 20
      dnB: 'checked',                                                                                                  // 20
      dnU: 'checked',                                                                                                  // 20
      dnF: 'checked',                                                                                                  // 20
      dhH: 'checked',                                                                                                  // 20
      dhV: 'checked',                                                                                                  // 20
      drB: 'checked',                                                                                                  // 20
      drF: 'checked',                                                                                                  // 20
      drR: 'checked',                                                                                                  // 20
      drG: 'checked',                                                                                                  // 20
      huM: 'checked',                                                                                                  // 20
      huS: 'checked',                                                                                                  // 20
      huB: 'checked',                                                                                                  // 20
      maF: 'checked',                                                                                                  // 20
      maFr: 'checked',                                                                                                 // 20
      maA: 'checked',                                                                                                  // 20
      moM: 'checked',                                                                                                  // 20
      moW: 'checked',                                                                                                  // 20
      moB: 'checked',                                                                                                  // 20
      paH: 'checked',                                                                                                  // 20
      paR: 'checked',                                                                                                  // 20
      paP: 'checked',                                                                                                  // 20
      prS: 'checked',                                                                                                  // 20
      prD: 'checked',                                                                                                  // 20
      prH: 'checked',                                                                                                  // 20
      roA: 'checked',                                                                                                  // 20
      roS: 'checked',                                                                                                  // 20
      roC: 'checked',                                                                                                  // 20
      shE: 'checked',                                                                                                  // 20
      shR: 'checked',                                                                                                  // 20
      shEn: 'checked',                                                                                                 // 20
      waA: 'checked',                                                                                                  // 20
      waD: 'checked',                                                                                                  // 20
      waDe: 'checked',                                                                                                 // 20
      warA: 'checked',                                                                                                 // 20
      warF: 'checked',                                                                                                 // 20
      warP: 'checked'                                                                                                  // 20
    }                                                                                                                  // 20
  });                                                                                                                  // 20
  console.log('hi');                                                                                                   // 21
  firstTime = 0;                                                                                                       // 22
  counts.insert({                                                                                                      // 23
    _id: "data",                                                                                                       // 23
    postCount: 0,                                                                                                      // 23
    appCount: 0,                                                                                                       // 23
    raidCount: 0                                                                                                       // 23
  });                                                                                                                  // 23
} //creates initial account                                                                                            // 24
                                                                                                                       //
                                                                                                                       //
Meteor.methods({                                                                                                       // 28
  'accountCheck': function () {                                                                                        // 29
    if (userCount.findOne({                                                                                            // 30
      count: 0                                                                                                         // 30
    })) {                                                                                                              // 30
      return true;                                                                                                     // 31
    } else {                                                                                                           // 32
      return false;                                                                                                    // 33
    }                                                                                                                  // 34
  },                                                                                                                   // 35
  'phraseCheck': function (secret) {                                                                                   // 36
    if (secret == "SnowyTableSanDiegoFifteenTwelve") {                                                                 // 37
      return true;                                                                                                     // 38
    }                                                                                                                  // 39
  },                                                                                                                   // 40
  'createAcc': function (usm, psw) {                                                                                   // 41
    Accounts.createUser({                                                                                              // 42
      username: usm,                                                                                                   // 43
      password: psw                                                                                                    // 44
    });                                                                                                                // 42
    userCount.insert({                                                                                                 // 46
      count: 1                                                                                                         // 46
    });                                                                                                                // 46
    userCount.remove({                                                                                                 // 47
      count: 0                                                                                                         // 47
    });                                                                                                                // 47
  }                                                                                                                    // 48
});                                                                                                                    // 28
Meteor.methods({                                                                                                       // 51
  'post': function (imageData, title, content, cata) {                                                                 // 52
    if (Meteor.user()) {                                                                                               // 53
      // our data URL string from canvas.toDataUrl();                                                                  // 54
      var imageDataUrl = imageData; // declare a regexp to match the non base64 first characters                       // 55
                                                                                                                       //
      var dataUrlRegExp = /^data:image\/\w+;base64,/; // remove the "header" of the data URL via the regexp            // 57
                                                                                                                       //
      var base64Data = imageDataUrl.replace(dataUrlRegExp, ""); // declare a binary buffer to hold decoded base64 data
                                                                                                                       //
      var imageBuffer = new Buffer(base64Data, "base64");                                                              // 61
      var id = ShortId.generate();                                                                                     // 62
      var isoDate = new Date();                                                                                        // 63
      var res = isoDate.toString().split(" ");                                                                         // 64
      var date = res[1] + " " + res[2] + " " + res[3];                                                                 // 65
      var path = process.env["PWD"] + '/.static~/';                                                                    // 66
      var cata = cata;                                                                                                 // 68
                                                                                                                       //
      if (cata.includes("News")) {                                                                                     // 69
        cata = "News";                                                                                                 // 70
      } else if (cata.includes("Boss")) {                                                                              // 71
        cata = "Boss";                                                                                                 // 72
      } else {                                                                                                         // 73
        //if no catagory is supplied, assume it's just news                                                            // 74
        cata = "News";                                                                                                 // 75
      }                                                                                                                // 76
                                                                                                                       //
      posts.insert({                                                                                                   // 77
        _id: id,                                                                                                       // 77
        title: title,                                                                                                  // 77
        content: content,                                                                                              // 77
        imgPath: '/files/' + id + ".jpeg",                                                                             // 77
        date: date,                                                                                                    // 77
        cataSux: cata,                                                                                                 // 77
        date_created: new Date()                                                                                       // 77
      });                                                                                                              // 77
      counts.update({                                                                                                  // 78
        _id: "data"                                                                                                    // 78
      }, {                                                                                                             // 78
        $inc: {                                                                                                        // 78
          postCount: 1                                                                                                 // 78
        }                                                                                                              // 78
      });                                                                                                              // 78
      fs.writeFile(path + id + '.jpeg', imageBuffer, function (err) {                                                  // 79
        if (err) throw err;                                                                                            // 81
        console.log('Done!');                                                                                          // 82
      });                                                                                                              // 83
    }                                                                                                                  // 84
  },                                                                                                                   // 85
  'addRaid': function (title, normS, heroS, mythS, bossName, bossStatN, bossStatH, bossStatM, addCC) {                 // 86
    if (Meteor.user()) {                                                                                               // 87
      //okay, I'm posting each boss and it's stats in an array. I need to break it up to show it, but I'm sure I can do that Client side.
      raids.insert({                                                                                                   // 89
        title: title,                                                                                                  // 89
        normS: normS,                                                                                                  // 89
        heroS: heroS,                                                                                                  // 89
        mythS: mythS,                                                                                                  // 89
        bossName: bossName,                                                                                            // 89
        bossStatN: bossStatN,                                                                                          // 89
        bossStatH: bossStatH,                                                                                          // 89
        bossStatM: bossStatM,                                                                                          // 89
        length: addCC                                                                                                  // 89
      });                                                                                                              // 89
      counts.update({                                                                                                  // 90
        _id: "data"                                                                                                    // 90
      }, {                                                                                                             // 90
        $inc: {                                                                                                        // 90
          raidCount: 1                                                                                                 // 90
        }                                                                                                              // 90
      });                                                                                                              // 90
    }                                                                                                                  // 91
  },                                                                                                                   // 92
  'addQues': function (ques, quesCount) {                                                                              // 93
    if (Meteor.user()) {                                                                                               // 94
      questions.remove({});                                                                                            // 95
      questions.insert({                                                                                               // 96
        ques: ques,                                                                                                    // 96
        quesCount: quesCount                                                                                           // 96
      });                                                                                                              // 96
    }                                                                                                                  // 97
  }                                                                                                                    // 98
});                                                                                                                    // 51
Meteor.methods({                                                                                                       // 101
  'updateSite': function (specStatus, title, about) {                                                                  // 102
    if (Meteor.user()) {                                                                                               // 103
      var spec = ['dnB', 'dnU', 'dnF', 'dhH', 'dhV', 'drB', 'drF', 'drR', 'drG', 'huM', 'huS', 'huB', 'maF', 'maFr', 'maA', 'moM', 'moW', 'moB', 'paH', 'paR', 'paP', 'prS', 'prD', 'prH', 'roA', 'roS', 'roC', 'shE', 'shR', 'shEn', 'waA', 'waD', 'waDe', 'warA', 'warF', 'warP']; //for loop wont work, as I can only assign the value and not the property
                                                                                                                       //
      siteDetails.update({                                                                                             // 107
        _id: 'recruiting'                                                                                              // 107
      }, {                                                                                                             // 107
        $set: {                                                                                                        // 107
          dnB: specStatus[0],                                                                                          // 107
          dnU: specStatus[1],                                                                                          // 107
          dnF: specStatus[2],                                                                                          // 107
          dhH: specStatus[3],                                                                                          // 107
          dhV: specStatus[4],                                                                                          // 107
          drB: specStatus[5],                                                                                          // 107
          drF: specStatus[6],                                                                                          // 107
          drR: specStatus[7],                                                                                          // 107
          drG: specStatus[8],                                                                                          // 107
          huM: specStatus[9],                                                                                          // 107
          huS: specStatus[10],                                                                                         // 107
          huB: specStatus[11],                                                                                         // 107
          maF: specStatus[12],                                                                                         // 107
          maFr: specStatus[13],                                                                                        // 107
          maA: specStatus[14],                                                                                         // 107
          moM: specStatus[15],                                                                                         // 107
          moW: specStatus[16],                                                                                         // 107
          moB: specStatus[17],                                                                                         // 107
          paH: specStatus[18],                                                                                         // 107
          paR: specStatus[19],                                                                                         // 107
          paP: specStatus[20],                                                                                         // 107
          prS: specStatus[21],                                                                                         // 107
          prD: specStatus[22],                                                                                         // 107
          prH: specStatus[23],                                                                                         // 107
          roA: specStatus[24],                                                                                         // 107
          roS: specStatus[25],                                                                                         // 107
          roC: specStatus[26],                                                                                         // 107
          shE: specStatus[27],                                                                                         // 107
          shR: specStatus[28],                                                                                         // 107
          shEn: specStatus[29],                                                                                        // 107
          waA: specStatus[30],                                                                                         // 107
          waD: specStatus[31],                                                                                         // 107
          waDe: specStatus[32],                                                                                        // 107
          warA: specStatus[33],                                                                                        // 107
          warF: specStatus[34],                                                                                        // 107
          warP: specStatus[35]                                                                                         // 107
        }                                                                                                              // 107
      });                                                                                                              // 107
                                                                                                                       //
      if (title != "" && title != undefined && title != null) {                                                        // 110
        siteDetails.update({                                                                                           // 111
          _id: 'title'                                                                                                 // 111
        }, {                                                                                                           // 111
          $set: {                                                                                                      // 111
            title: title                                                                                               // 111
          }                                                                                                            // 111
        });                                                                                                            // 111
      }                                                                                                                // 112
                                                                                                                       //
      if (about != "" && about != undefined && about != null) {                                                        // 113
        siteDetails.update({                                                                                           // 114
          _id: 'about'                                                                                                 // 114
        }, {                                                                                                           // 114
          $set: {                                                                                                      // 114
            about: about                                                                                               // 114
          }                                                                                                            // 114
        });                                                                                                            // 114
      }                                                                                                                // 115
    }                                                                                                                  // 116
  },                                                                                                                   // 117
  'updateRaid': function (title, normS, heroS, mythS, bossName, bossStatN, bossStatH, bossStatM, addCC, target) {      // 118
    if (Meteor.user()) {                                                                                               // 119
      raids.update({                                                                                                   // 120
        _id: target                                                                                                    // 120
      }, {                                                                                                             // 120
        $set: {                                                                                                        // 120
          title: title,                                                                                                // 120
          normS: normS,                                                                                                // 120
          heroS: heroS,                                                                                                // 120
          mythS: mythS,                                                                                                // 120
          bossName: bossName,                                                                                          // 120
          bossStatN: bossStatN,                                                                                        // 120
          bossStatH: bossStatH,                                                                                        // 120
          bossStatM: bossStatM,                                                                                        // 120
          length: addCC                                                                                                // 120
        }                                                                                                              // 120
      });                                                                                                              // 120
    }                                                                                                                  // 121
  },                                                                                                                   // 122
  'updatePost': function (title, content, id) {                                                                        // 123
    if (Meteor.user()) {                                                                                               // 124
      posts.update({                                                                                                   // 125
        _id: id                                                                                                        // 125
      }, {                                                                                                             // 125
        $set: {                                                                                                        // 125
          title: title,                                                                                                // 125
          content: content                                                                                             // 125
        }                                                                                                              // 125
      });                                                                                                              // 125
    }                                                                                                                  // 126
  }                                                                                                                    // 127
});                                                                                                                    // 101
Meteor.methods({                                                                                                       // 130
  'sendApp': function (questions, resps, amt) {                                                                        // 131
    apps.insert({                                                                                                      // 132
      username: resps[0].replace("::", ""),                                                                            // 132
      questions: questions,                                                                                            // 132
      resps: resps,                                                                                                    // 132
      amt: amt                                                                                                         // 132
    });                                                                                                                // 132
    counts.update({                                                                                                    // 133
      _id: "data"                                                                                                      // 133
    }, {                                                                                                               // 133
      $inc: {                                                                                                          // 133
        appCount: 1                                                                                                    // 133
      }                                                                                                                // 133
    });                                                                                                                // 133
  }                                                                                                                    // 134
});                                                                                                                    // 130
Meteor.methods({                                                                                                       // 137
  'deletePost': function (post) {                                                                                      // 138
    if (Meteor.user()) {                                                                                               // 139
      var filePath = process.env["PWD"] + '/.static~/' + post + '.jpeg';                                               // 140
      fs.unlinkSync(filePath);                                                                                         // 141
      posts.remove({                                                                                                   // 142
        _id: post                                                                                                      // 142
      });                                                                                                              // 142
      counts.update({                                                                                                  // 143
        _id: "data"                                                                                                    // 143
      }, {                                                                                                             // 143
        $inc: {                                                                                                        // 143
          postCount: -1                                                                                                // 143
        }                                                                                                              // 143
      });                                                                                                              // 143
    }                                                                                                                  // 144
  },                                                                                                                   // 145
  'deleteApp': function (appId) {                                                                                      // 146
    if (Meteor.user()) {                                                                                               // 147
      apps.remove({                                                                                                    // 148
        _id: appId                                                                                                     // 148
      });                                                                                                              // 148
      counts.update({                                                                                                  // 149
        _id: "data"                                                                                                    // 149
      }, {                                                                                                             // 149
        $inc: {                                                                                                        // 149
          appCount: -1                                                                                                 // 149
        }                                                                                                              // 149
      });                                                                                                              // 149
    }                                                                                                                  // 150
  },                                                                                                                   // 151
  'deleteRaid': function (raidId) {                                                                                    // 152
    if (Meteor.user()) {                                                                                               // 153
      raids.remove({                                                                                                   // 154
        _id: raidId                                                                                                    // 154
      });                                                                                                              // 154
      counts.update({                                                                                                  // 155
        _id: "data"                                                                                                    // 155
      }, {                                                                                                             // 155
        $inc: {                                                                                                        // 155
          raidCount: -1                                                                                                // 155
        }                                                                                                              // 155
      });                                                                                                              // 155
    }                                                                                                                  // 156
  }                                                                                                                    // 157
});                                                                                                                    // 137
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/db.js");
require("./lib/globals.js");
require("./lib/routes.js");
require("./server/fileserver.js");
require("./server/publish.js");
require("./server/server.js");
//# sourceMappingURL=app.js.map
